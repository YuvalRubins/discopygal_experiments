import math
import networkx as nx

from ...solvers_infra import RobotDisc, RobotPolygon, ObstaclePolygon, PathPoint, Path, PathCollection
from ...bindings import FT, Point_2, Ker, Arr_trapezoid_ric_point_location, Arr_overlay_function_traits, \
    Arrangement_2, Polygon_2, Aos2, Curve_2, Ms2, Vertex, Segment_2, Halfedge, Face, TPoint
from ...geometry_utils import collision_detection, bounding_boxes, conversions
from ...solvers_infra.Solver import Solver

LINE0 = Ker.Line_2(Point_2(FT(0), FT(0)), Point_2(FT(0), FT(0)))

class ExactSingle(Solver):
    """
    Exact solution by vertical decomposition for a SINGLE disc/polygon robot.
    Multiple robot motion planning is not supported.
    Also any other type besides disc or polygon robot is unsupported

    :param eps: epsilon for approximated offset
    :type eps: :class:`float`
    """
    def __init__(self, eps, **kwargs):
        super().__init__(**kwargs)
        self.eps = eps

        self.G = None
        self.robot = None
        self.arr = None
        self.pl = None
        self.conn_graph = None
        self.edge_dict = None
        self.collision_detection = None


    @classmethod
    def get_arguments(cls):
        """
        Return a list of arguments and their description, defaults and types.
        Can be used by a GUI to generate fields dynamically.
        Should be overridded by solvers.

        :return: arguments dict
        :rtype: :class:`dict`
        """
        args = {
            'eps': ('epsilon for approximated offset:', 0.0001, float),
        }
        args.update(super().get_arguments())
        return args

    def get_arrangement(self):
        """
        Return an arrangement (if applicable).
        Can be overridded by solvers.

        :return: arrangement
        :rtype: :class:`~discopygal.bindings.Arrangement_2`
        """
        return self.arr

    def _solve(self):
        """
        Based on the start and end locations of each robot, solve the scene
        (i.e. return paths for all the robots)

        :return: path collection of motion planning
        :rtype: :class:`~discopygal.solvers_infra.PathCollection`
        """
        if len(self.scene.robots) != 1:
            raise(Exception('Unsupported number of robots'))
        if type(self.scene.robots[0]) not in [RobotDisc, RobotPolygon]:
            raise(Exception('Only disc/polygon robots are supported'))
        self.robot = self.scene.robots[0]

        if self._bounding_box is None: # If no bounding box, create one
            self._bounding_box = bounding_boxes.calc_scene_bounding_box(self.scene)

        self.arr = self.construct_cspace()
        self.arr = self.vertical_decomposition(self.arr)
        self.conn_graph, self.edge_dict = self.connectivity_graph(self.arr)
        self.collision_detection = collision_detection.ObjectCollisionDetection(self.scene.obstacles, self.robot)

        self.pl = Arr_trapezoid_ric_point_location(self.arr)

        source_idx = self.find_face_index(self.arr, self.robot.start, self.pl)
        target_idx = self.find_face_index(self.arr, self.robot.end, self.pl)

        if source_idx < 0:
            if self.verbose:
                print("Could not find origin face.", file=self.writer)
            return PathCollection()
        if target_idx < 0:
            if self.verbose:
                print("Could not find target face.", file=self.writer)
            return PathCollection()

        #####################################
        # Generate a path from start to end
        #####################################
        if source_idx == target_idx:
            # If we are very close, then linear interpolation is enough
            return PathCollection({self.robot: Path([PathPoint(self.robot.start), PathPoint(self.robot.end)])})

        try:
            g_path = nx.shortest_path(self.conn_graph, source_idx, target_idx)
        except nx.exception.NetworkXNoPath:
            if self.verbose:
                print("Could not find a path from source to dest", file=self.writer)
            return PathCollection()

        # Convert g_path to a linear path for the robot
        path = self.find_valid_path(
            g_path, self.robot.start, self.robot.end,
            self.edge_dict, self.collision_detection)

        return PathCollection({self.robot: path})


    def construct_cspace(self):
        """
        Get the (CGAL Polygonal) obstacles and the radius of the robot,
        and construct the expanded CSPACE arrangement (also with bounding box walls)
        """
        traits = Arr_overlay_function_traits(lambda x, y: x + y)

        # Compute an arrangement for each single Minkowski sum
        arrangements = []
        for obstacle in self.scene.obstacles:
            if type(obstacle) is not ObstaclePolygon:
                continue
            arr = Arrangement_2()
            if isinstance(self.robot, RobotPolygon):
                minus_robot = Polygon_2([Point_2(-p.x(), -p.y()) for p in self.robot.poly.vertices()])
                if minus_robot.is_clockwise_oriented():
                    minus_robot.reverse_orientation()
                if obstacle.poly.is_clockwise_oriented():
                    obstacle.poly.reverse_orientation()
                ms = Ms2.minkowski_sum_2(obstacle.poly, minus_robot)
                Aos2.insert(arr, [Curve_2(edge) for edge in conversions.to_list(ms.outer_boundary().edges())])
                for hole in ms.holes():
                    Aos2.insert(arr, [Curve_2(edge) for edge in hole.edges()])
            elif isinstance(self.robot, RobotDisc):
                ms = Ms2.approximated_offset_2(obstacle.poly, self.robot.radius, self.eps)
                Aos2.insert(arr, conversions.to_list(ms.outer_boundary().curves()))
                for hole in ms.holes():
                    Aos2.insert(arr, conversions.to_list(hole.curves()))
            ubf = arr.unbounded_face()
            ubf.set_data(0)
            invalid_face = next(next(ubf.inner_ccbs())).twin().face()
            invalid_face.set_data(1)
            for ccb in invalid_face.inner_ccbs():
                valid_face = next(ccb).twin().face()
                valid_face.set_data(0)
            arrangements.append(arr)

        # Overlay the arrangement
        initial = Arrangement_2()
        ubf = initial.unbounded_face()
        ubf.set_data(0)
        arrangements.insert(0, initial)
        arr = initial
        for i in range(len(arrangements)-1):
            arr = Arrangement_2()
            Aos2.overlay(arrangements[i], arrangements[i+1], arr, traits)
            arrangements[i+1] = arr

        # Compute the bounding box of the arrangement and add it as edges
        min_x, max_x, min_y, max_y = self._bounding_box
        bb_arr = Aos2.Arrangement_2()
        Aos2.insert(bb_arr, [
            Curve_2(Point_2(min_x, min_y), Point_2(max_x, min_y)),
            Curve_2(Point_2(max_x, min_y), Point_2(max_x, max_y)),
            Curve_2(Point_2(max_x, max_y), Point_2(min_x, max_y)),
            Curve_2(Point_2(min_x, max_y), Point_2(min_x, min_y)),
        ])
        for face in bb_arr.faces():
            if face.is_unbounded():
                face.set_data(1)
            else:
                face.set_data(0)

        cspace = Aos2.Arrangement_2()
        Aos2.overlay(arr, bb_arr, cspace, traits)

        return cspace

    def to_ker_point_2(self, point: Point_2):
        """
        Convert TPoint() to Ker.Point_2()
        """
        x, y = point.x(), point.y()
        # assert (not x.is_extended())
        # assert (not y.is_extended())
        return Ker.Point_2(x.a0(), y.a0())

    def vertical_decomposition(self, arr):
        """
        Take an arrangement and add edges to it that represent the vertical decomposition
        """
        lst = Aos2.decompose(arr)
        vertical_walls = []
        for pair in lst:
            v, objects = pair
            for object in objects:
                v_point = self.to_ker_point_2(v.point())
                if type(object) == Vertex:
                    v_other = self.to_ker_point_2(object.point())
                    wall = Curve_2(Segment_2(v_point, v_other))
                    vertical_walls.append(wall)
                if type(object) == Halfedge:
                    line = Ker.Line_2(self.to_ker_point_2(object.source().point()), self.to_ker_point_2(object.target().point()))
                    y_at_x = line.y_at_x(v_point.x())
                    wall = Curve_2(Segment_2(v_point, Point_2(v_point.x(), y_at_x)))
                    vertical_walls.append(wall)

        # Create an arrangement of vertical walls and overlay it
        walls_arr = Aos2.Arrangement_2()
        Aos2.insert(walls_arr, vertical_walls)
        for face in walls_arr.faces():
            face.set_data(0)

        traits = Arr_overlay_function_traits(lambda x, y: x + y)
        res = Aos2.Arrangement_2()
        Aos2.overlay(arr, walls_arr, res, traits)
        return res

    def connectivity_graph(self, arr):
        """
        Get the connectivity graph from a vertical decomposition arrangement
        """
        conn_graph = nx.Graph()

        # Attach a face to each index
        face_dict = {}
        # For every edge in the graph, also add the common edge
        edge_dict = {}

        idx = 0
        for face in arr.faces():
            if face.is_unbounded() or face.data() > 0:
                face.set_data(-1)
            else:
                face.set_data(idx)
                face_dict[idx] = face
                conn_graph.add_node(idx)
                idx += 1

        unvisited_faces = list(face_dict.keys())

        queue = [unvisited_faces.pop(0)]
        while len(queue) > 0:
            face_idx = queue.pop(0)
            face = face_dict[face_idx]
            for edge in face.outer_ccb():
                adj_face_idx = edge.twin().face().data()
                if adj_face_idx in unvisited_faces:
                    conn_graph.add_edge(face_idx, adj_face_idx)
                    unvisited_faces.remove(adj_face_idx)
                    queue.append(adj_face_idx)
                    # Add to edge dict (both direction)
                    edge_dict[(face_idx, adj_face_idx)] = edge
                    edge_dict[(adj_face_idx, face_idx)] = edge

        return conn_graph, edge_dict

    def find_face_index(self, arr, p, pl):
        """
        Get a point and find the index of the face in the arrangement that has it
        """
        p = TPoint(p.x(), p.y())
        obj = pl.locate(p)
        if type(obj) is Face:
            return obj.data()
        if type(obj) is Halfedge:
            return obj.face().data()
        return -1


    def find_valid_path(self, g_path, source, target, edge_dict, collision_detector):
        """
        Convert a graph path to a valid motion planning path.
        We do that by connecting midpoints of edges we pass - and since the arrangement
        has circle curves, we might need split some edges in half (for exact motion).
        """
        path = []
        path.append(PathPoint(source))
        for i in range(len(g_path)-1):
            # For every traveled edge in the connectivity graph, add its midpoint
            edge = edge_dict[(g_path[i], g_path[i+1])]
            midpoint = Ker.midpoint(self.to_ker_point_2(edge.source().point()), self.to_ker_point_2(edge.target().point()))
            # Check if we can traverse from previous point to current point
            prev_point = path[-1].location
            if not collision_detector.is_edge_valid(Segment_2(prev_point, midpoint)):
                # If we have an intersection, split the path to two parts and slide along the normal
                mid_midpoint = Ker.midpoint(prev_point, midpoint)

                # Compute (unit) normal of the path
                normal = (prev_point.y().to_double() - midpoint.y().to_double(), midpoint.y().to_double() - prev_point.x().to_double())
                norm = math.sqrt(normal[0] * normal[0] + normal[1] * normal[1])
                normal = (normal[0] / norm, normal[1] / norm)

                alpha = self.eps
                flag = True
                new_point = None
                while flag:
                    # Try moing along and against the normal, until at least one of them works
                    pos_point = Point_2(mid_midpoint.x().to_double() + alpha * normal[0], mid_midpoint.y().to_double() + alpha * normal[1])
                    neg_point = Point_2(mid_midpoint.x().to_double() - alpha * normal[0], mid_midpoint.y().to_double() - alpha * normal[1])

                    if collision_detector.is_edge_valid(Segment_2(prev_point, pos_point)) and collision_detector.is_edge_valid(Segment_2(pos_point, midpoint)):
                        new_point = pos_point
                        flag = False
                    elif collision_detector.is_edge_valid(Segment_2(prev_point, neg_point)) and collision_detector.is_edge_valid(Segment_2(neg_point, midpoint)):
                        new_point = neg_point
                        flag = False
                    else:
                        alpha += self.eps
                path.append(PathPoint(new_point))

            path.append(PathPoint(midpoint))
        path.append(PathPoint(target))
        return Path(path)
