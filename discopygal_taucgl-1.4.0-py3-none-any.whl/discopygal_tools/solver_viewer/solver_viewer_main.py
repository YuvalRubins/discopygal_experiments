import os
import sys
import json
import time
import importlib.util
import traceback
import argparse
from enum import Enum
from inspect import isclass
from threading import Thread
import ctypes
from functools import partial

from PyQt5 import QtWidgets, QtCore, QtGui

from discopygal.solvers_infra import Scene, SceneDrawer, PathCollection, PathPoint, RobotDisc
from discopygal.solvers_infra.Solver import Solver
from discopygal.bindings import Point_2
from discopygal.gui.logger import Writer, Logger
from discopygal.gui.gui import GUI
from discopygal.geometry_utils.display_arrangement import display_arrangement
from discopygal.geometry_utils import conversions
from discopygal.solvers_infra.verify_paths import verify_paths
from discopygal.solvers_infra.metrics import Metric_Euclidean
from discopygal.gui.color import str_to_color
from discopygal.solvers import get_available_solvers, get_solver_class, import_default_solvers, import_solver_from_file
from discopygal_tools.scene_designer.grid import Grid
from discopygal_tools.solver_viewer.solver_viewer_gui import Ui_MainWindow, Ui_dialog, Ui_About

__all__ = ["start_gui"]

WINDOW_TITLE = "DiscoPygal Solver Viewer"
DEFAULT_ZOOM = 30
DEFAULT_SPEED = 40
DEFAULT_GRAPH_COLOR = "red"
DEFAULT_PATH_COLOR = "darkGreen"


class MESSAGE_TYPE(Enum):
    INFO = 0,
    ERROR = 1


def pop_message_box(type, title, message):
    ICONS = {
        MESSAGE_TYPE.INFO: QtWidgets.QMessageBox.Icon.Information,
        MESSAGE_TYPE.ERROR: QtWidgets.QMessageBox.Icon.Critical
    }

    msgbox = QtWidgets.QMessageBox(ICONS[type], title, message)
    msgbox.exec()


def import_solver_file(path):
    try:
        cnt = import_solver_from_file(path)
        pop_message_box(MESSAGE_TYPE.INFO,
                        "Import solvers",
                        "Successfully import {} solvers from {}.".format(cnt, path))
    except Exception as e:
        message = f"Exception {e}\n{traceback.format_exc()}"
        print(message)
        pop_message_box(MESSAGE_TYPE.ERROR, "Could not import module", message)


class SolverDialog(Ui_dialog):
    DEFAULT_SOLVER_TEXT = "Select a solver..."

    def __init__(self, gui, dialog):
        super().__init__()
        self.gui = gui  # pointer to parent gui
        self.gui.solver_dialog = self # Set pointer from parent to current
        self.dialog = dialog
        self.setupUi(self.dialog)

        self.update_combo_box()
        self.selectButton.clicked.connect(self.choose_solver)
        self.browseButton.clicked.connect(self.solver_from_file)

    def solver_from_file(self):
        """
        Choose a solver from a file
        """
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self.dialog, 'Load File')
        if path == '':
            return
        import_solver_file(path)
        self.update_combo_box()

    def choose_solver(self):
        if self.DEFAULT_SOLVER_TEXT == self.solverComboBox.currentText():
            return
        self.gui.select_solver_class(self.solverComboBox.currentText())
        self.dialog.close()

    def update_combo_box(self):
        items = [self.DEFAULT_SOLVER_TEXT] + get_available_solvers()
        self.solverComboBox.clear()
        self.solverComboBox.addItems(items)

def updateCoords(graphicsView, event):
    scene_pos = graphicsView.mapToScene(event.pos())
    graphicsView.coords_label.setText(f"X: {scene_pos.x():.2f}, Y: {scene_pos.y():.2f}")
    graphicsView.coords_label.move(5, int(graphicsView.height() - 40))
    graphicsView.coords_label.adjustSize()
    graphicsView.originalMouseEvent(event)


class SolverViewerGUI(Ui_MainWindow, GUI):
    def __init__(self, scene=None, solver=None, solver_file=None):
        super().__init__()
        self.set_program_name(WINDOW_TITLE)

        # Fix initial zoom
        self.zoom = DEFAULT_ZOOM
        self.redraw()

        # Disable scene path edit
        self.scenePathEdit.setEnabled(False)

        self.solver_dialog = None

        # Setup the scene
        self.discopygal_scene = Scene()
        self.scene_drawer = SceneDrawer(self, self.discopygal_scene)
        self.scene_path = ""
        self.actionOpen_Scene.triggered.connect(self.choose_scene)
        self.actionOpenScene.triggered.connect(self.choose_scene)
        self.actionClear.triggered.connect(self.clear)

        # Setup solver
        import_default_solvers()
        self.solver = None
        self.solver_gui_elements = {}
        self.solver_graph = None
        self.solver_arrangement = None
        self.solver_graph_vertices = {} # Graph vertices drawn on gui. Format {point: RDisc}
        self.solver_graph_edges = {} # Graph edges drawn on gui. Format {(point1, point2): RSegment}
        self.actionOpenSolver.triggered.connect(self.open_solver_dialog)
        self.actionOpen_Solver.triggered.connect(self.open_solver_dialog)
        self.actionSolve.triggered.connect(self.solve)
        self.animation_speed = DEFAULT_SPEED
        self.horizontalSlider.setValue(self.animation_speed)

        # Setup concurrency
        self.threadpool = QtCore.QThreadPool()
        self.worker = None
        self.logger = Logger(self.textEdit)
        self.writer = Writer(self.logger)
        self.start_time = None

        # Solution paths and misc data
        self.paths = None
        self.path_vertices = {}  # Path vertices drawn on gui. Format {point: RDisc}
        self.path_edges = {}  # Graph edges drawn on gui. Format {(point1, point2): RSegment}
        self.set_animation_finished_action(self.anim_finished)
        self.bounding_box_edges = {} # Bounding box edges drawn on gui. Format {(point1, point2): RSegment}
        self.connection_point_size = 0.05

        # Setup actions
        self.actionShowPaths.triggered.connect(self.toggle_paths)
        self.actionPlay.triggered.connect(self.toggle_play)
        self.actionStop.triggered.connect(self.action_stop)
        self.actionShowGraph.triggered.connect(self.action_display_graph)
        self.actionShowArrangement.triggered.connect(self.action_display_arrangement)
        self.actionAbout.triggered.connect(self.about_dialog)
        # self.actionQuit.triggered.connect(lambda: sys.exit(0)) # Raises an error of leaked instances
        self.actionVerify.triggered.connect(self.verify_paths)
        self.actionShowBoundingBox.triggered.connect(self.toggle_bounding_box)
        self.horizontalSlider.sliderMoved.connect(self.speed_slider_changed)
        self.horizontalSlider.valueChanged.connect(self.speed_slider_changed)
        self.scrollArea_2.setVisible(False)
        self.showCheckboxes.clicked.connect(self.toggle_show_checkboxes)

        self.graphicsView.originalMouseEvent = self.graphicsView.mouseMoveEvent
        self.graphicsView.mouseMoveEvent = partial(updateCoords, self.graphicsView)
        self.graphicsView.coords_label = QtWidgets.QLabel(self.graphicsView)
        self.graphicsView.coords_label.setStyleSheet("background-color: white; padding: 2px;")
        self.graphicsView.coords_label.setAlignment(QtCore.Qt.AlignCenter)

        self.grid = Grid(self)
        self.actionGrid.triggered.connect(self.toggle_grid)

        # Start gui
        self.mainWindow.show()

        # Set pre-received arguments
        self.set_gui_arguments(scene, solver, solver_file)

    def setupUi(self):
        super().setupUi(self.mainWindow)

    def verify_paths(self):
        """
        Verify paths action
        """
        res, reason = verify_paths(self.discopygal_scene, self.paths)
        if res:
            pop_message_box(MESSAGE_TYPE.INFO, "Verify paths", "Successfully verified paths.")
        else:
            pop_message_box(MESSAGE_TYPE.ERROR, "Verify paths", "Paths are invalid: " + reason)

    def about_dialog(self):
        """
        Open the about dialog
        """
        dialog = QtWidgets.QDialog()
        dialog.ui = Ui_About()
        dialog.ui.setupUi(dialog)
        dialog.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        dialog.setWindowTitle('About')
        dialog.exec_()

    def action_display_arrangement(self):
        """
        Display arrangement, if applicable
        """
        if self.solver_arrangement is None:
            return
        display_arrangement(self.solver_arrangement)

    def action_display_graph(self):
        """
        Display graph, if applicable
        """
        if len(self.solver_graph_vertices) > 0:
            self.clear_graph()
        else:
            self.show_graph()

    def add_visual_edge(self, p: Point_2, q: Point_2,
                              vertex_color: str, edge_color: str, edge_opacity: float,
                              drawn_vertices: dict, drawn_edges: dict):
        x1, y1 = p.x().to_double(), p.y().to_double()
        x2, y2 = q.x().to_double(), q.y().to_double()
        if vertex_color:
            vertex_color = str_to_color(vertex_color)
            if p not in drawn_vertices:
                drawn_vertices[p] = self.add_disc(self.connection_point_size, x1, y1, vertex_color, vertex_color)
            if q not in drawn_vertices:
                drawn_vertices[q] = self.add_disc(self.connection_point_size, x2, y2, vertex_color, vertex_color)

        if edge_color:
            edge_color = str_to_color(edge_color)
            if (p,q) not in drawn_edges or (p,q) not in drawn_edges:
                drawn_edges[(p,q)] = self.add_segment(x1, y1, x2, y2, edge_color, opacity=edge_opacity)

    def show_graph(self):
        """
        Display the solver graph
        """
        if self.solver_graph is None:
            return

        for edge in self.solver_graph.edges:
            p, q = edge
            edge_color = self.solver_graph.get_edge_data(p, q).get('color', DEFAULT_GRAPH_COLOR)
            if type(p) is tuple:
                p = p[0]; q = q[0]

            p = conversions.Point_2_to_Point_d(p)
            q = conversions.Point_2_to_Point_d(q)

            for i in filter(lambda x: self.should_show_robot_graph(x), range(p.dimension() // 2)):
                p_i = Point_2(p[2*i], p[2*i+1])
                q_i = Point_2(q[2*i], q[2*i+1])
                self.add_visual_edge(p_i, q_i, "red", edge_color, 0.5,
                                     self.solver_graph_vertices, self.solver_graph_edges)

    def clear_graph(self):
        """
        If a graph is drawn, clear it
        """
        self.solver_graph_vertices.clear()
        self.solver_graph_edges.clear()
        self.clear_gui()
        self.scene_drawer.draw_scene()

    def toggle_play(self):
        if self.is_queue_playing():
            self.change_action_icon(self.actionPlay, ":/play.png", "Play", "Play animation")
            self.action_pause()
        else:
            self.change_action_icon(self.actionPlay, ":/pause.png", "Pause", "Pause animation")
            self.animate_paths()


    def action_pause(self):
        """
        Pause animation button
        """
        if self.is_queue_playing():
            self.pause_queue()

    def action_stop(self):
        """
        Stop the animation
        """
        self.change_action_icon(self.actionPlay, ":/play.png", "Play", "Play animation")
        if self.is_queue_playing() or self.is_queue_paused():
            self.stop_queue()

        self.terminate_worker()

        # Move robots back to start
        self.scene_drawer.clear_scene()
        self.scene_drawer.draw_scene()

    @staticmethod
    def change_action_icon(action, icon_path, text, tool_tip):
        _translate = QtCore.QCoreApplication.translate
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(icon_path), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        action.setIcon(icon)
        action.setText(_translate("MainWindow", text))
        action.setToolTip(_translate("MainWindow", tool_tip))

    def change_stop_button_color(self, color):
        pixmap = QtGui.QPixmap(":/stop.png")
        mask = pixmap.createMaskFromColor(str_to_color("#333333"), QtCore.Qt.MaskMode.MaskOutColor)
        pixmap.fill(str_to_color(color))
        pixmap.setMask(mask)
        self.actionStop.setIcon(QtGui.QIcon(pixmap))

    def toggle_paths(self):
        """
        Toggle paths button
        """
        if len(self.path_vertices) > 0:
            self.clear_paths()
        else:
            self.draw_paths()

    def calculate_animation_speed(self, ix, iy, x, y, speed):
        dist = Metric_Euclidean.dist(Point_2(ix, iy), Point_2(x, y))
        animation_speed = self.animation_speed * 0.0001 * speed
        return int(dist / animation_speed)

    def anim_finished(self):
        """
        This is called when the animation is finished
        """
        self.change_action_icon(self.actionPlay, ":/play.png", "Play", "Play animation")

    def animate_paths(self):
        """
        Animate the paths (if exists)
        """
        if self.paths is None or len(self.paths.paths) == 0 or self.is_queue_playing():
            return

        # If we are just paused, resume
        if self.is_queue_paused():
            self.play_queue()
            return

        # Otherwise generate the paths for animation
        self.scene_drawer.clear_scene()
        self.scene_drawer.draw_scene()

        path_len = len(list(self.paths.paths.values())[0].points)  # num of edges in paths
        animations = []
        for i in range(path_len-1):
            # All robots move in parallel along their edge
            animation_edges = []
            for robot in self.paths.paths:
                robot_gui = self.scene_drawer.robot_lut[robot][0]
                source = self.paths.paths[robot].points[i]
                target = self.paths.paths[robot].points[i+1]
                speed = source.data.get("speed", 1)
                if 'theta' in source.data:
                    itheta = source.data['theta']
                    theta = target.data['theta']
                    if type(itheta) is not float:
                        itheta = itheta.to_double()
                    if type(theta) is not float:
                        theta = theta.to_double()
                    clockwise = source.data['clockwise']
                ix = source.location.x().to_double()
                iy = source.location.y().to_double()
                x = target.location.x().to_double()
                y = target.location.y().to_double()
                if 'theta' not in source.data:
                    animation_edges.append(
                        self.linear_translation_animation(
                            robot_gui, ix, iy, x, y, self.calculate_animation_speed(ix, iy, x, y, speed)
                        )
                    )
                else:
                    animation_edges.append(
                        self.segment_angle_animation(
                            robot_gui, ix, iy, itheta, x, y, theta, clockwise, self.calculate_animation_speed(ix, iy, x, y, speed)
                        )
                    )
            animations.append(self.parallel_animation(*animation_edges))

        self.queue_animation(*animations)
        self.play_queue()

    def draw_paths(self):
        """
        Draw the paths (if exist)
        """
        if self.paths is None:
            return

        for robot_index, robot in enumerate(self.paths.paths):
            if not self.should_show_robot_graph(robot_index):
                continue
            points = self.paths.paths[robot].points

            # Control if paths will have their robot's color
            color = robot.data['color'] if False else DEFAULT_PATH_COLOR
            for p, q in zip(points, points[1:]):
                self.add_visual_edge(p.location, q.location, color, color, 1,
                                     self.path_vertices, self.path_edges)

    def clear_paths(self):
        """
        Clear the paths if any were drawn
        """
        for vertex in self.path_vertices.values():
            self.scene.removeItem(vertex.disc)
        for edge in self.path_edges.values():
            self.scene.removeItem(edge.line)
        self.path_vertices.clear()
        self.path_edges.clear()

    def get_solver_args(self):
        """
        Extract a dict from the dynamically generated GUI arguments (to pass to the solver)
        """
        args = self.solver.__dict__
        solver_args = self.solver.get_arguments()
        for arg in self.solver_gui_elements:
            if arg.endswith('_label'):
                continue
            _, _, ttype = solver_args[arg]
            args[arg] = ttype(self.solver_gui_elements[arg].text())
        return args

    def solve_thread(self):
        """
        The thread that is run by the "solve" function"
        """
        args = self.get_solver_args()
        self.solver = self.solver.__class__(**args) # Create a new solver object for solving
        self.solver.set_verbose(self.writer)
        try:
            self.solver.load_scene(self.discopygal_scene)
            self.paths = self.solver.solve()
        except Exception as e:
            print("Error in solving scene", file=self.writer)
            print(f"Exception: {e}", file=self.writer)
            traceback.print_exc()
            return
        finally:
            self.solver_done()
            self.solver_graph = self.solver.get_graph()
            self.solver_arrangement = self.solver.get_arrangement()

    def terminate_worker(self):
        if self.worker:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(self.worker.ident, ctypes.py_object(SystemExit))
            self.solver_done()

    def solve(self):
        """
        This method is called by the solve button.
        Run the MP solver in parallel to the app.
        """
        if self.solver is None:
            return
        self.disable_toolbar()
        self.worker = Thread(target=self.solve_thread, daemon=True)
        self.start_time = time.time()
        self.worker.start()

    def disable_toolbar(self):
        """
        Disable icons on the toolbar while running
        """
        for c in self.toolBar.children():
            if isinstance(c, QtWidgets.QToolButton) and c.text() != "Stop":
                c.setEnabled(False)
        self.change_stop_button_color("#c40e23") # red

    def enable_toolbar(self):
        """
        Disable icons on the toolbar while running
        """
        for c in self.toolBar.children():
            if isinstance(c, QtWidgets.QToolButton) and c.text() != "Stop":
                c.setEnabled(True)
        self.change_stop_button_color("#333333")

    def solver_done(self):
        """
        Enable icons on the toolbar after done running
        """
        self.enable_toolbar()
        self.worker = None
        end_time = time.time()
        print("Calculation time took: {}[sec]".format(end_time - self.start_time), file=self.writer)

    def select_solver_class(self, solver_name):
        self.load_solver(get_solver_class(solver_name).init_default_solver())

    def load_solver(self, solver):
        """
        Set the selected solver.
        Also generate dynamically the GUI elements corresponding to the solver's arguments.
        """

        self.solver = solver

        # Clear all elements
        for element in self.solver_gui_elements.values():
            element.setParent(None)
        self.solver_gui_elements.clear()

        # Generate the settings layout
        layout = QtWidgets.QVBoxLayout()
        args = self.solver.get_arguments()
        for arg, (description, default, _) in args.items():
            self.solver_gui_elements[arg + '_label'] = QtWidgets.QLabel(description)
            layout.addWidget(self.solver_gui_elements[arg + '_label'])
            self.solver_gui_elements[arg] = QtWidgets.QLineEdit(str(self.solver.__getattribute__(arg)))
            layout.addWidget(self.solver_gui_elements[arg])
        widget = QtWidgets.QWidget()
        widget.setLayout(layout)

        # Attach layout to scroll widget
        self.scrollArea.setVerticalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scrollArea.setHorizontalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setWidget(widget)
        self.solverName.setText(type(solver).__name__)
        self.solver.on_gui_load(self, layout)

    def update_scene_metadata(self):
        """
        Update the scene's metadata
        """
        if 'version' in self.discopygal_scene.metadata:
            self.versionEdit.setText(self.discopygal_scene.metadata['version'])
        else:
            self.versionEdit.setText('NO VERSION')

        if 'solvers' in self.discopygal_scene.metadata:
            self.solversEdit.setText(self.discopygal_scene.metadata['solvers'])
        else:
            self.solversEdit.setText('NO SOLVERS')

        if 'details' in self.discopygal_scene.metadata:
            self.sceneDetailsEdit.setPlainText(self.discopygal_scene.metadata['details'])
        else:
            self.sceneDetailsEdit.setPlainText('NO DETAILS')

    def open_solver_dialog(self):
        """
        Open the "load solver" dialog
        """
        dialog = QtWidgets.QDialog()
        dialog.ui = SolverDialog(self, dialog)
        dialog.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        dialog.setWindowTitle('Open Solver...')
        dialog.exec_()

    def choose_scene(self):
        """
        Load a scene.
        """
        name, _ = QtWidgets.QFileDialog.getOpenFileName(
            self.mainWindow, 'Load File')
        if name == '':
            return

        self.load_scene(name)

    def load_scene(self, scene):
        self.clear()
        if not isinstance(scene, Scene):
            scene_file = scene
            try:
                scene = Scene.from_file(scene_file)
                self.scene_path = scene_file
                self.scenePathEdit.setText(self.scene_path)
            except FileNotFoundError:
                pop_message_box(MESSAGE_TYPE.ERROR,
                                "Scene file error",
                                f"File {scene_file} not found!")
                return
            except (KeyError, json.decoder.JSONDecodeError) as e:
                pop_message_box(MESSAGE_TYPE.ERROR,
                                "Scene file load failure",
                                f"Failed to load scene {scene_file}\n"
                                f"Error: {e}")
                return

        self.discopygal_scene = scene
        self.scene_drawer.clear_scene()
        self.scene_drawer.scene = self.discopygal_scene
        self.scene_drawer.draw_scene()
        self.update_scene_metadata()

        self.clear_paths()
        if self.paths is not None:
            self.paths.paths.clear()
        self.paths = None
        self.add_robots_graphs_checkboxes()
        if self.discopygal_scene:
            self.connection_point_size = float(min([self.connection_point_size] +
                [robot.radius / 20 for robot in self.discopygal_scene.robots if isinstance(robot, RobotDisc)])
            )

    def clear_gui(self):
        self.stop_queue()
        self.scene_drawer.clear_scene()
        self.solver_graph_vertices.clear()
        self.solver_graph_edges.clear()
        self.path_vertices.clear()
        self.path_edges.clear()
        self.bounding_box_edges.clear()
        self.scene_drawer.gui.scene.clear()

    def clear(self):
        """
        Clear scene, paths, graphs, etc.
        """
        self.clear_gui()
        self.discopygal_scene = Scene()
        self.scene_drawer.scene = self.discopygal_scene
        self.scene_drawer.draw_scene()
        self.scene_path = ""
        if self.paths is not None:
            self.paths.paths.clear()
        self.paths = None
        self.scenePathEdit.setText(self.scene_path)

    def set_gui_arguments(self, scene=None, solver=None, solver_file=None):
        if scene is not None:
            self.load_scene(scene)
        if solver_file is not None:
            import_solver_file(solver_file)
        if solver is not None:
            if isinstance(solver, Solver):
                self.load_solver(solver)
            elif isclass(solver):
                self.load_solver(solver.init_default_solver())
            else:
                try:
                    self.select_solver_class(solver)
                except KeyError:
                    pop_message_box(MESSAGE_TYPE.ERROR,
                                    "Invalid solver",
                                    f"Invalid solver name.\nValid solvers are: {get_available_solvers()}")

    def speed_slider_changed(self):
        old_speed = self.animation_speed
        self.animation_speed = self.horizontalSlider.sliderPosition()
        for i in range(self.sequence.animationCount()):
            if self.sequence.animationAt(i) == self.sequence.currentAnimation():
                current_anim_index = i
                break
        else:
            current_anim_index = 0

        for i in range(current_anim_index, self.sequence.animationCount()):
            for j in range(self.sequence.animationAt(i).animationCount()):
                anim = self.sequence.animationAt(i).animationAt(j)
                anim.setDuration(int(anim.duration() * old_speed / self.animation_speed))

    def toggle_bounding_box(self):
        if self.bounding_box_edges:
            self.clear_bounding_box()
        else:
            self.draw_bounding_box()

    def draw_bounding_box(self):
        if self.solver is None:
            return

        bounding_box_graph = self.solver.get_bounding_box_graph()

        if bounding_box_graph is None:
            return

        for edge in bounding_box_graph.edges:
            p, q = edge
            self.add_visual_edge(p, q, None, "gray", 0.7, None, self.bounding_box_edges)

    def clear_bounding_box(self):
        for edge in self.bounding_box_edges.values():
            self.scene.removeItem(edge.line)

        self.bounding_box_edges.clear()

    def toggle_show_checkboxes(self):
        if self.scrollArea_2.isVisible():
            self.showCheckboxes.setText("Choose Robots")
            self.scrollArea_2.setVisible(False)
        else:
            self.showCheckboxes.setText("Hide")
            self.scrollArea_2.setVisible(True)
            self.scrollArea.setWidgetResizable(True)

    def add_robots_graphs_checkboxes(self):
        layout = QtWidgets.QVBoxLayout()
        robots_show_frame = QtWidgets.QWidget()
        robots_show_frame.setLayout(layout)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(robots_show_frame.sizePolicy().hasHeightForWidth())
        robots_show_frame.setSizePolicy(sizePolicy)
        robots_show_frame.setMaximumSize(QtCore.QSize(16777215, 300))

        self.scrollArea_2.setWidget(robots_show_frame)
        self.robot_checkboxes = []
        for i in range(len(self.discopygal_scene.robots)):
            checkbox = QtWidgets.QCheckBox(f"Robot {i}")
            checkbox.clicked.connect(self.on_checkbox_click)
            checkbox.setCheckState(QtCore.Qt.CheckState.Checked)
            self.robot_checkboxes.append(checkbox)
            layout.addWidget(checkbox)

    def should_show_robot_graph(self, robot_index):
        return self.robot_checkboxes[robot_index].checkState() == QtCore.Qt.CheckState.Checked

    def on_checkbox_click(self):
        is_showing_path = len(self.path_vertices) > 0
        is_showing_graph = len(self.solver_graph_vertices) > 0
        if is_showing_graph:
            self.clear_graph()
            self.show_graph()
        if is_showing_path:
            self.clear_paths()
            self.draw_paths()

    def toggle_grid(self):
        """
        Draw the grid, using the given grid options
        """
        self.grid.size = int(max([self.graphicsView.sceneRect().width(), self.graphicsView.sceneRect().height()]) / 1.5)
        self.grid.size = int(500/self.zoom)
        if self.grid.enabled:
            self.grid.clear_grid()
            self.grid.enabled = False
        else:
            self.grid.draw_grid()
            self.grid.enabled = True

    def show_bottleneck_action(self):
        if "show_bottleneck" in dir(self.solver):
            self.solver.show_bottleneck(self)

    def exit(self):
        self.terminate_worker()
        self.clear()
        sys.exit(0)

def start_gui(scene=None, solver=None, solver_file=None):
    """
    Start solver_viewer tool

    See also :ref:`Solver Viewer - From script <solver_viewer_script>`

    :param scene: scene to upload
    :type scene: :class:`~discopygal.solvers_infra.Scene`

    :param solver: solver to upload.
         May be a solver object (object of a class that inherits from :class:`~discopygal.solvers_infra.Solver.Solver`),
         class that inherits from :class:`~discopygal.solvers_infra.Solver.Solver` or a name of a solver's class.

    :type solver: :class:`~discopygal.solvers_infra.Solver.Solver` or :class:`class` or :class:`str`
    """
    app = QtWidgets.QApplication(sys.argv)

    # Set css style sheet
    stream = QtCore.QFile(":/style.qss")
    stream.open(QtCore.QIODevice.ReadOnly)
    app.setStyleSheet(QtCore.QTextStream(stream).readAll())

    gui = SolverViewerGUI(scene, solver, solver_file)
    app.exec_()


def main():
    parser = argparse.ArgumentParser(description='Solve a 2D scene')
    parser.add_argument('-sc', '--scene', help="Path to json scene file", type=str)
    parser.add_argument('-sl', '--solver', help="Name of solver to use", type=str)
    parser.add_argument('-sf', '--solver-file', help="Path of solver file to upload", type=str)
    args = parser.parse_args()
    start_gui(args.scene, args.solver, args.solver_file)


if __name__ == "__main__":
    main()
