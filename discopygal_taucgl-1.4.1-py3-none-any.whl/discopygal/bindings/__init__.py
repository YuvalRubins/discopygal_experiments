"""
Currently the docs yeild ugly C++ class implementation.
In the meantime, here is a clean docstring that documents the relevant variables:

* CGAL Modules

 - :class:`Ker`: CGAL Kernel module
 - Ms2: CGAL 2D Minkowski Sums module
 - Aos2: CGAL 2D Arrangements module
 - Pol2: CGAL 2D Polygons module
 - SS: CGAL Spatial Search module
 - PP2: CGAL 2D Polygon Partitioning module
 - Bso2: CGAL Boolean Set Operations module

* CGAL Kernel Objects

 - Point_d: CGAL Point_d object
 - Point_2: CGAL Point_2 object
 - FT: CGAL Field Type (FT) object
 - Gmpq: CGAL Gmpq object
 - Segment_2: CGAL Segment_2 object
 - Circle_2: CGAL Circle_2 object
 - Vector_2: CGAL Vector_2 object

* CGAL Spatial Search

 - Euclidean_distance: CGAL Euclediean distance function
 - K_neighbor_search: CGAL K_neighbor_search
 - Kd_tree: CGAL Kd_tree
 - Fuzzy_sphere: CGAL Fuzzy sphere

* CGAL Transformations

 - Aff_transformation_2: CGAL Aff_transformation_2
 - Rotation: CGAL Rotation
 - Direction_2: CGAL Direction_2

* CGAL Arrangements

 - Arrangement_2: CGAL 2D Arrangement
 - Face: CGAL Arrangement Face handle
 - Halfedge: CGAL Arrangement Halfedge handle
 - Vertex: CGAL Arrangement Vertex handle
 - Arr_trapezoid_ric_point_location: CGAL Arrangement trapezoid ric point location
 - Arr_overlay_function_traits: CGAL Arrangement face overlay traits
 - X_monotone_curve_2: CGAL X_monotone_curve_2 object
 - Curve_2: CGAL Curve_2 object
 - TPoint: CGAL Aos2 Point_2

* CGAL 2D Polygons

 - Polygon_2: CGAL Polygon_2
 - Polygon_set_2: CGAL Polygon_set_2
 - Polygon_with_holes_2: CGAL Polygon_with_holes_2
"""

import CGALPY as CGALPY

#: CGAL Kernel module
Ker = CGALPY.Ker
#: CGAL 2D Minkowski Sums module
Ms2 = CGALPY.Ms2
#: CGAL 2D Arrangements module
Aos2 = CGALPY.Aos2
#: CGAL 2D Polygons module
Pol2 = CGALPY.Pol2
#: CGAL Spatial Search module
Ss = CGALPY.Ss
#: CGAL 2D Polygon Partitioning module
# PP2 = CGALPY.PP2
#: CGAL Boolean Set Operations module
Bso2 = CGALPY.Bso2
#: CGAL Point_d object
Point_d = Ss.Point_d
#: CGAL Euclediean distance function
Euclidean_distance = Ss.Euclidean_distance
#: CGAL K_neighbor_search
K_neighbor_search = Ss.K_neighbor_search
#: CGAL Kd_tree
Kd_tree = Ss.Kd_tree
#: CGAL Fuzzy sphere
Fuzzy_sphere = Ss.Fuzzy_sphere

#: CGAL Point_2 object
Point_2 = Ker.Point_2
Result = CGALPY.Result

Result = CGALPY.Result

#: CGAL Field Type (FT) object
class FT(Ker.FT):
    def __init__(self, value):
        # If given value to cast is string, first cast it to float (can't go directly from string to FT)
        if isinstance(value, str):
            value = float(value)
        super(FT, self).__init__(value)

    def __float__(self):
        return self.to_double()

    def __int__(self):
        return int(self.to_double())

    def __radd__(self, other):
        return self + other

    def __rmul__(self, other):
        return self * other

    def __rtruediv__(self, other):
        return FT(other) / self


operations = ["__add__", "__sub__", "__mul__", "__truediv__"]


def create_method(op_name):
    def method(self, other):
        return FT(getattr(super(FT, self), op_name)(other))
    return method


def create_imethod(op_name):
    def imethod(self, other):
        self = FT(getattr(super(FT, self), op_name)(other))
        return self
    return imethod


for op in operations:
    setattr(FT, op, create_method(op))
    iop = list(op)
    iop.insert(2, "i")
    iop = "".join(iop)
    setattr(FT, iop, create_imethod(iop))

#: CGAL Gmpq object
Gmpq = Ker.Gmpq

#: CGAL Segment_2 object
class Segment_2(Ker.Segment_2):
    def __hash__(self):
        return hash(Point_d(4, list(map(lambda x: x.to_double(), [self.point(0).x(), self.point(1).y(), self.point(1).x(), self.point(1).y()]))))

#: CGAL Circle_2 object
Circle_2 = Ker.Circle_2
#: CGAL Vector_2 object
Vector_2 = Ker.Vector_2

#: CGAL Aff_transformation_2
Aff_transformation_2 = Ker.Aff_transformation_2
#: CGAL Rotation
Rotation = CGALPY.Rotation
#: CGAL Direction_2
Direction_2 = Ker.Direction_2

#: CGAL 2D Arrangement
Arrangement_2 = Aos2.Arrangement_2
#: CGAL Arrangement Face handle
Face = Aos2.Arrangement_2.Face
#: CGAL Arrangement Halfedge handle
Halfedge = Aos2.Arrangement_2.Halfedge
#: CGAL Arrangement Vertex handle
Vertex = Aos2.Arrangement_2.Vertex

#: CGAL Arrangement trapezoid ric point location
# Arr_trapezoid_ric_point_location = Aos2.Arr_trapezoid_ric_point_location
Arr_trapezoid_ric_point_location = Aos2.Arr_walk_along_line_point_location # TEMPORARY hack, will be fixed in next CGAL version
#: CGAL Arrangement face overlay traits
Arr_overlay_function_traits = Aos2.Arr_overlay_function_traits

#: CGAL X_monotone_curve_2 object
X_monotone_curve_2 = Aos2.Arr_circle_segment_traits_2.X_monotone_curve_2
#: CGAL Curve_2 object
Curve_2 = Aos2.Arr_circle_segment_traits_2.Curve_2
#: CGAL Aos2 Point_2
TPoint = Aos2.Arr_circle_segment_traits_2.Point_2

#: CGAL Polygon_2
Polygon_2 = Pol2.Polygon_2
#: CGAL Polygon_set_2
# Polygon_set_2 = Bso2.Polygon_set_2
#: CGAL Polygon_with_holes_2
Polygon_with_holes_2 = Pol2.Polygon_with_holes_2
