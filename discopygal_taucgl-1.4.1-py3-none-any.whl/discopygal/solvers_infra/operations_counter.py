from time import process_time
from functools import wraps
from contextlib import contextmanager


class OperationsCounter:
    basic_operations_call_counts = {}
    time_to_increment_ratios = {}
    should_count = False

    @classmethod
    def clear(cls):
        cls.basic_operations_call_counts.clear()
        cls.time_to_increment_ratios.clear()

    @classmethod
    def _count_operation(cls, operation_name, increment, time_took):
        cls.basic_operations_call_counts[operation_name] = cls.basic_operations_call_counts.get(operation_name, 0) + increment
        if operation_name not in cls.time_to_increment_ratios:
            cls.time_to_increment_ratios[operation_name] = []

        if increment != 0:
            cls.time_to_increment_ratios[operation_name].append(time_took / increment)

    @classmethod
    def count_calls(cls, get_increment=None):
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                if not cls.should_count:
                    return func(*args, **kwargs)

                start_time = process_time()
                return_value = func(*args, **kwargs)
                time_took = process_time() - start_time

                # Calculate increment based on function parameters
                increment = get_increment(*args, **kwargs) if get_increment else 1
                cls._count_operation(func.__qualname__, increment, time_took)
                return return_value
            return wrapper
        return decorator

    @classmethod
    @contextmanager
    def count_call_context(cls, name, increment=1):
        start_time = process_time()
        yield
        time_took = process_time() - start_time

        if cls.should_count:
            cls._count_operation(name, increment, time_took)

