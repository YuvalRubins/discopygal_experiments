import networkx as nx

from ...solvers_infra import PathPoint, Path, PathCollection
from ...solvers_infra.samplers import SamplerWithAngle
from ...bindings import FT, Segment_2, Point_2, Point_d
from .prm import PRM
from ...geometry_utils import collision_detection

class BasicRodPRM(PRM):
    """
    The basic implementation of a Probabilistic Road Map (PRM) solver, modified for rod robot.
    Supports single-robot motion planning.

    Points are tuples of (:class:`~discopygal.bindings.Point_2`, :class:`~discopygal.bindings.FT`) of position and angle, representing SE(2).

    :param num_landmarks: number of landmarks to sample
    :type num_landmarks: :class:`int`
    :param k: number of nearest neighbors to connect
    :type k: :class:`int`
    :param nearest_neighbors: a nearest neighbors algorithm. if None then use sklearn implementation
    :type nearest_neighbors: :class:`~discopygal.solvers_infra.nearest_neighbors.NearestNeighbors` or :class:`None`
    :param metric: a metric for weighing edges, can be different then the nearest_neighbors metric!
        If None then use euclidean metric
    :type metric: :class:`~discopygal.solvers_infra.metrics.Metric` or :class:`None`
    :param sampler: sampling algorithm/method. if None then use uniform sampling
    :type sampler: :class:`~discopygal.solvers_infra.samplers.Sampler`
    """
    def __init__(self, **kwargs):
        if "sampler" not in kwargs:
            kwargs["sampler"] = SamplerWithAngle()
        super().__init__(**kwargs)

    def collision_free(self, p, q, clockwise):
        """
        Get two points in the configuration space and decide if they can be connected
        """
        # Check validity of each edge seperately
        for robot in self.scene.robots:
            xy_edge = Segment_2(p[0], q[0])
            if not self.collision_detection[robot].is_edge_valid((xy_edge, FT(p[1]), FT(q[1])), clockwise):
                return False
            break # Only one robot is supported
        return True

    def sample_free(self):
        """
        Sample a free random point
        """
        sample = self.sampler.sample()
        robot = self.scene.robots[0]
        while not self.collision_detection[robot].is_point_valid(sample):
            sample = self.sampler.sample()
        return sample

    def point2vec3(self, point):
        """
        Convert a point (xy, theta) to a 3D vector
        """
        return Point_d(3, [point[0].x().to_double(), point[0].y().to_double(), point[1].to_double()])

    def build_roadmap(self):

        ################
        # Build the PRM
        ################
        roadmap = nx.DiGraph()
        nearest_neighbors = self.nearest_neighbors_class()

        # Add start & end points
        self.start = self.scene.robots[0].start
        self.end = self.scene.robots[0].end
        self.collision_detection = {
            robot: collision_detection.ObjectCollisionDetection(self.scene.obstacles, robot) for robot in self.scene.robots
        }
        roadmap.add_node(self.start)
        roadmap.add_node(self.end)

        # Add valid points
        for i in range(self.num_landmarks):
            p_rand = self.sample_free()
            roadmap.add_node(p_rand)
            if i % 100 == 0:
                self.log(f'added {i} landmarks in PRM')

        nearest_neighbors.fit(list(map(self.point2vec3, roadmap.nodes)))

        # Connect all points to their k nearest neighbors
        last_nodes = list(roadmap.nodes)
        for cnt, point in enumerate(last_nodes):
            neighbors = nearest_neighbors.k_nearest(self.point2vec3(point), self.k_nn+1)
            for neighbor in neighbors:
                neighbor = (Point_2(neighbor[0], neighbor[1]), neighbor[2])
                for clockwise in [True, False]:
                    if self.collision_free(point, neighbor, clockwise):
                        weight = self.metric.dist(point[0], neighbor[0]).to_double()
                        roadmap.add_edge(point, neighbor, weight=weight, clockwise=clockwise)
                        roadmap.add_edge(neighbor, point, weight=weight, clockwise=(not clockwise))

            if cnt % 100 == 0:
                self.log(f'connected {cnt} landmarks to their nearest neighbors')

        return roadmap

    def search_path_on_roadmap(self):
        """
        Based on the start and end locations of each robot, solve the scene
        (i.e. return paths for all the robots)

        :return: path collection of motion planning
        :rtype: :class:`~discopygal.solvers_infra.PathCollection`
        """
        if not nx.algorithms.has_path(self.roadmap, self.start, self.end):
            return PathCollection()

        # Convert from a sequence of Point_d points to PathCollection
        tensor_path = nx.algorithms.shortest_path(self.roadmap, self.start, self.end, weight='weight')
        path_collection = PathCollection()
        for _, robot in enumerate(self.scene.robots):
            points = []
            for i, point in enumerate(tensor_path):
                if point != self.end:
                    clockwise = self.roadmap.get_edge_data(tensor_path[i], tensor_path[i+1])["clockwise"]
                points.append(PathPoint(point[0], data={'theta': point[1], 'clockwise': clockwise}))
            path = Path(points, self.metric)
            path_collection.add_robot_path(robot, path)

        return path_collection
