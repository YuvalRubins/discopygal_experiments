import networkx as nx
from itertools import combinations
from tqdm import tqdm

from discopygal.solvers_infra import Scene
from discopygal.solvers_infra import PathPoint, Path, PathCollection

from discopygal.bindings import Point_2, Segment_2, FT
from discopygal.geometry_utils import collision_detection, conversions
from discopygal.solvers_infra.Solver import Solver
from discopygal.solvers.exact.exact_single import ExactSingle

from .path_combiners_factory import PathCombinerMode, PathCombinerFactory
from .metric_utils import l2_dist, path_makespan_d
from .path_utils import combined_point_to_tensor_point


class RevolvingAreas(Solver):
    def __init__(
        self,
        shortcut_paths,
        mode,
        sub_mode,
        depth,
        max_simultaneous_robots,
        min_distance,
        pairing_k,
        num_landmarks,
        k,
        epsilon,
        allow_backtracking,
        bounding_margin_width_factor=Solver.NO_BOUNDING_BOX,
        **kwargs
    ):
        super().__init__(bounding_margin_width_factor)
        self.num_landmarks = num_landmarks
        self.k = k
        self.shortcut_paths = eval(shortcut_paths)
        self.epsilon = epsilon
        self.mode = mode
        self.sub_mode = sub_mode
        self.depth = depth
        self.max_simultaneous_robots = max_simultaneous_robots
        self.min_distance = min_distance
        self.pairing_k = pairing_k
        self.allow_backtracking = eval(allow_backtracking)

        self.roadmap = None
        self.path_per_robot = {}
        self.collision_detection = {}

    @classmethod
    def get_arguments(cls):
        """
        Return a list of arguments and their description, defaults and types.
        Can be used by a GUI to generate fields dynamically.
        Should be overridded by solvers.

        :return: arguments dict
        :rtype: :class:`dict`
        """
        return {
            "shortcut_paths": ("Shortcut robot paths before combining", "True", str),
            "mode": (
                "Mode of combining paths",
                PathCombinerMode.REVOLVING_AREAS.value,
                str,
            ),
            "sub_mode": (
                "Sub mode for combining paths",
                PathCombinerMode.OBSTACLES2.value,
                str,
            ),
            "depth": ("Depth for combining paths", 1, int),
            "pairing_k": ("K for path pairings", -1, int),
            "max_simultaneous_robots": ("Maximum simultaneous robots allowed", -1, int),
            "min_distance": ("Minimum distance between moving robots", 12, float),
            "num_landmarks": ("Number of Landmarks:", 1000, int),
            "k": ("K for nearest neighbors:", 15, int),
            "epsilon": ("epislon used for refinement", 1, float),
            "allow_backtracking": ("Allow backtracking:", "True", str),
            "bounding_margin_width_factor": (
                "Margin width factor (for bounding box):",
                Solver.NO_BOUNDING_BOX,
                FT,
            ),
        }

    @staticmethod
    def from_arguments(d):
        """
        Get a dictionary of arguments and return a solver.
        Should be overridded by solvers.

        :param d: arguments dict
        :type d: :class:`dict`
        """
        return RevolvingAreas(
            shortcut_paths=d["shortcut_paths"],
            mode=d["mode"],
            sub_mode=d["sub_mode"],
            depth=d["depth"],
            max_simultaneous_robots=d["max_simultaneous_robots"],
            min_distance=d["min_distance"],
            pairing_k=d["pairing_k"],
            num_landmarks=d["num_landmarks"],
            k=d["k"],
            epsilon=d["epsilon"],
            allow_backtracking=d["allow_backtracking"],
            bounding_margin_width_factor=FT(d["bounding_margin_width_factor"]),
        )

    def get_graph(self):
        """
        Return a graph (if applicable).
        Can be overridded by solvers.

        :return: graph whose vertices are Point_2 or Point_d
        :rtype: :class:`networkx.Graph` or :class:`None`
        """
        return self.roadmap

    def collision_free(self, p, q):
        """
        Get two points in the configuration space and decide if they can be connected
        """
        p_list = conversions.Point_d_to_Point_2_list(p)
        q_list = conversions.Point_d_to_Point_2_list(q)

        # Check validity of each edge seperately
        for i, robot in enumerate(self.scene.robots):
            edge = Segment_2(p_list[i], q_list[i])
            if not self.collision_detection[robot].is_edge_valid(edge):
                if self.verbose:
                    print(f"Path invalid for robot {i}.", file=self.writer)
                return False

        # Check validity of coordinated robot motion
        for i, robot1 in enumerate(self.scene.robots):
            for j, robot2 in enumerate(self.scene.robots):
                if j <= i:
                    continue
                edge1 = Segment_2(p_list[i], q_list[i])
                edge2 = Segment_2(p_list[j], q_list[j])
                if collision_detection.collide_two_robots(robot1, edge1, robot2, edge2):
                    if self.verbose:
                        print(
                            f"Path invalid since robots {i} and {j} collide.",
                            file=self.writer,
                        )
                    return False

        return True

    def shortcut_robot_path(self, robot_idx, robot_path):
        robot = self.scene.robots[robot_idx]
        graph = nx.Graph()
        for i, j in combinations(range(len(robot_path)), r=2):
            if self.collision_detection[robot].is_edge_valid(
                Segment_2(robot_path[i], robot_path[j])
            ):
                graph.add_edge(
                    robot_path[i],
                    robot_path[j],
                    weight=l2_dist(robot_path[i], robot_path[j]),
                )

        shortcut_robot_path = nx.algorithms.shortest_path(
            graph, robot_path[0], robot_path[-1], weight="weight"
        )
        return shortcut_robot_path

    def get_robot_shortest_path(self, robot_idx, shortcut_path):
        EPSILON = 0.0001
        scene_dict = self.scene.to_dict()
        scene_dict["robots"] = [scene_dict["robots"][robot_idx]]

        robot_solver = ExactSingle(
            eps=EPSILON,
            bounding_margin_width_factor=self.bounding_margin_width_factor,
        )
        robot_solver.load_scene(Scene.from_dict(scene_dict))
        path_collection = robot_solver.solve()
        if len(path_collection.paths) == 0:
            return None

        path = list(path_collection.paths.values())[0]
        tensor_path = [point.location for point in path.points]
        if shortcut_path:
            tensor_path = self.shortcut_robot_path(
                robot_idx=robot_idx, robot_path=tensor_path
            )
        return tensor_path

    def load_scene(self, scene: Scene):
        """
        Load a scene into the solver.
        Also build the roadmap.

        :param scene: scene to load
        :type scene: :class:`~discopygal.solvers_infra.Scene`
        """
        super().load_scene(scene)

        # Build collision detection for each robot
        for robot in scene.robots:
            self.collision_detection[robot] = (
                collision_detection.ObjectCollisionDetection(scene.obstacles, robot)
            )

        self.roadmap = nx.Graph()

        for robot_idx, robot in tqdm(
            enumerate(scene.robots),
            desc="Finding shortest paths",
            total=len(scene.robots),
        ):
            robot_path = self.get_robot_shortest_path(
                robot_idx=robot_idx, shortcut_path=self.shortcut_paths
            )
            if robot_path is None:
                if self.verbose:
                    print(f"no path found for {robot_idx = }.", file=self.writer)
                continue

            self.path_per_robot[robot] = robot_path
            self.roadmap.add_node(robot.start)
            for src, dst in zip(robot_path, robot_path[1:]):
                self.roadmap.add_node(dst)
                self.roadmap.add_edge(src, dst)

        self.path_combiner_factory = PathCombinerFactory(
            obstacles=[obstacle.poly for obstacle in self.scene.obstacles],
            num_landmarks=self.num_landmarks,
            k=self.k,
            epsilon=self.epsilon,
            allow_backtracking=self.allow_backtracking,
        )

    def _solve(self, return_tensor_path=False):
        """
        Based on the start and end locations of each robot, solve the scene
        (i.e. return paths for all the robots)

        :return: path collection of motion planning
        :rtype: :class:`~discopygal.solvers_infra.PathCollection`
        """
        for robot_idx, robot_path in enumerate(self.path_per_robot.values()):
            if robot_path is None:
                if self.verbose:
                    print(
                        f"No path found since no path was found for {robot_idx = }.",
                        file=self.writer,
                    )
                return PathCollection()

        # Convert from a sequence of Point_d points to PathCollection
        path_combiner = self.path_combiner_factory.create_path_combiner(
            PathCombinerMode(self.mode),
            robots=self.scene.robots,
            sub_mode=PathCombinerMode(self.sub_mode),
            depth=self.depth,
            pairing_k=self.pairing_k,
            max_simultaneous_robots=self.max_simultaneous_robots,
            min_distance=self.min_distance,
        )

        original_paths = list(self.path_per_robot.values())
        tensor_path = path_combiner.combine_paths(original_paths)
        if tensor_path is None:
            print(f"No path found since couldn't combine paths.", file=self.writer)
            return PathCollection()

        # Correction because of floating point calculation errors.
        original_start_point = [original_path[0] for original_path in original_paths]
        original_end_point = [original_path[-1] for original_path in original_paths]
        tensor_path = (
            [combined_point_to_tensor_point(original_start_point)]
            + tensor_path
            + [combined_point_to_tensor_point(original_end_point)]
        )

        if return_tensor_path:
            return tensor_path

        if self.verbose:
            print(
                f"The makespan of the path is: {path_makespan_d(dpath=tensor_path, verbose=True)}",
                file=self.writer,
            )

        if self.verbose:
            print("Creating path collection", file=self.writer)
        path_collection = PathCollection()
        for i, robot in enumerate(self.scene.robots):
            points = []
            for point in tensor_path:
                points.append(PathPoint(Point_2(point[2 * i], point[2 * i + 1])))
            path = Path(points)
            path_collection.add_robot_path(robot, path)

        return path_collection
