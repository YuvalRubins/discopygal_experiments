import os
import sys
import importlib
from inspect import isclass

from discopygal.solvers_infra.Solver import Solver


def try_import(module, names):
    try:
        module_obj = importlib.import_module(module)
        for name in names:
            globals()[name] = getattr(module_obj, name)
    except ImportError:
        pass
        # if 'RevolvingAreas' not in names:  # It is common to fail to import RevolvingAreas since it requires installing external package (RA)
        #     print(f"Warning: Can't import {names}. ({e})")


DEFAULT_SOLVER_CLASSES = [
    ('discopygal.solvers.rrt', ['RRT', 'RRT_star', 'dRRT', 'BiRRT', 'LBT_RRT', 'dRRT_star']),
    ('discopygal.solvers.prm', ['PRM', 'BasicRodPRM']),
    ('discopygal.solvers.prm.prm2', ['PRM2', 'PRM3']),
    ('discopygal.solvers.exact', ['ExactSingle']),
    ('discopygal.solvers.staggered_grid', ['StaggeredGrid', 'dRRTStaggeredGrid', 'dRRTStarStaggeredGrid', 'StaggeredGridMinPath']),
    ('discopygal.solvers.revolving_areas', ['RevolvingAreas']),
    ('discopygal.solvers.hgraphs', ['HGraph_PRM', 'HGraph_RRT']),
    ('discopygal.solvers.revolving_areas.revolving_areas_solver', ['RevolvingAreas']),
    ('discopygal.solvers.bottleneck_tree.frechet_matching', ['FrechetMatching']),
]


def import_default_solvers():
    """
    Import all default solver classes
    """
    for module, name in DEFAULT_SOLVER_CLASSES:
        try_import(module, name)


def import_solver_from_file(path):
    sys.path.append(os.path.dirname(path))
    module_name = os.path.basename(path).rstrip(".py")
    if module_name in sys.modules:
        module = sys.modules[module_name]
        importlib.reload(module)
    else:
        module = importlib.import_module(module_name)
    cnt = 0
    for obj_name in dir(module):
        obj = getattr(module, obj_name)
        if isclass(obj) and issubclass(obj, Solver) and obj_name != "Solver":
            globals()[obj_name] = obj
            cnt += 1
    return cnt


def get_available_solvers():
    """
    Return a list of all available solvers' names
    """
    solver_list = []
    for obj in globals():
        if isclass(globals()[obj]) and issubclass(globals()[obj], Solver) and globals()[obj] is not Solver:
            solver_list.append(obj)
    return solver_list


def get_solver_class(solver_class_name: str):
    """
    Return the class of the solver class name given.
    It solver class name doesn't exist return None.
    """
    # print(get_available_solvers())
    if solver_class_name in get_available_solvers():
        return globals().get(solver_class_name)
