from ...solvers_infra.nearest_neighbors import NearestNeighbors, NearestNeighbors_sklearn
from ..rrt import RRT


class BiRRT(RRT):
    """
    Implementation of the BiRRT algorithm.
    We grow two trees - one rooted at start, the other at the end. Every once in a while
    (n_join) try to extend both trees toward the same sample.
    Supports multi-robot motion planning, though might be inefficient for more than
    two-three robots.

    :param num_landmarks: number of landmarks to sample
    :type num_landmarks: :class:`int`
    :param eta: maximum distance when steering
    :type eta: :class:`~discopygal.bindings.FT`
    :param n_join: period of iterations when trying to grow the trees towards the same sample
    :type n_join: :class:`int`
    :param nearest_neighbors_start: a nearest neighbors algorithm for the tree grown from start. if None then use sklearn implementation
    :type nearest_neighbors_start: :class:`~discopygal.solvers_infra.nearest_neighbors.NearestNeighbors` or :class:`None`
    :param nearest_neighbors_end: a nearest neighbors algorithm for the tree grown from end. if None then use sklearn implementation
    :type nearest_neighbors_end: :class:`~discopygal.solvers_infra.nearest_neighbors.NearestNeighbors` or :class:`None`
    :param metric: a metric for weighing edges, can be different then the nearest_neighbors metric!
        If None then use euclidean metric
    :type metric: :class:`~discopygal.solvers_infra.metrics.Metric` or :class:`None`
    :param sampler: sampling algorithm/method. if None then use uniform sampling
    :type sampler: :class:`~discopygal.solvers_infra.samplers.Sampler`
    """
    def __init__(self, n_join, nearest_neighbors_start_class=None, nearest_neighbors_end_class=None, **kwargs):
        super().__init__(**kwargs)
        self.n_join = n_join
        self.nearest_neighbors_start_class: NearestNeighbors = nearest_neighbors_start_class or NearestNeighbors_sklearn
        self.nearest_neighbors_end_class: NearestNeighbors = nearest_neighbors_end_class or NearestNeighbors_sklearn

    @classmethod
    def get_arguments(cls):
        """
        Return a list of arguments and their description, defaults and types.
        Can be used by a GUI to generate fields dynamically.
        Should be overridded by solvers.

        :return: arguments dict
        :rtype: :class:`dict`
        """
        args = {
            'n_join': ('Expand simultaneously every:', 10, int),
        }
        args.update(super().get_arguments())
        return args

    def build_roadmap(self):
        ################
        # Build the RRT
        ################
        roadmap = self.init_roadmap()
        roadmap_start = self.init_roadmap(nearest_neighbors_class=self.nearest_neighbors_start_class)
        roadmap_end = self.init_roadmap(nearest_neighbors_class=self.nearest_neighbors_end_class)

        curr_tree = roadmap_start
        prev_tree = roadmap_end

        # Add start & end points (but only the start to the graph)
        roadmap_start.add_point(self.start)
        roadmap_end.add_point(self.end)

        for cnt in range(self.num_landmarks):
            p_rand = curr_tree.sample_free_point()
            p_near = curr_tree.nearest_neighbors.k_nearest(p_rand, 1)[0]
            p_new = self.steer(p_near, p_rand, self.eta)

            if curr_tree.add_edge(p_near, p_new):
                curr_tree, prev_tree = prev_tree, curr_tree

            # try expanding both trees
            if cnt % self.n_join == 0:
                p_rand = roadmap.sample_free_point()
                p_near_start = roadmap_start.nearest_neighbors.k_nearest(p_rand, 1)[0]
                p_near_end = roadmap_end.nearest_neighbors.k_nearest(p_rand, 1)[0]
                p_new_start = self.steer(p_near_start, p_rand, self.eta)
                p_new_end = self.steer(p_near_end, p_rand, self.eta)

                if roadmap.is_edge_valid(p_near_start, p_new_start) and roadmap.is_edge_valid(p_near_end, p_new_end):
                    roadmap_start.add_edge(p_near_start, p_new_start, check_if_valid=False)
                    roadmap_end.add_edge(p_near_end, p_new_end, check_if_valid=False)

            if cnt % 100 == 0 and self.verbose:
                print('added', cnt, 'landmarks in RRT', file=self.writer)

        # Try connecting both trees
        for p, q in roadmap_start.edges:
            roadmap.add_edge(p, q)
        for p, q in roadmap_end.edges:
            roadmap.add_edge(p, q)
        min_d = None
        p_start = None
        p_end = None
        for p in roadmap_start.points:
            q = roadmap_end.nearest_neighbors.k_nearest(p, 1)[0]
            if min_d is None or self.metric.dist(p, q) < min_d:
                min_d = self.metric.dist(p, q)
                p_start = p
                p_end = q

        roadmap.add_edge(p_start, p_end)

        return roadmap
