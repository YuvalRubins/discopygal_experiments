import random

from discopygal.solvers.rrt.drrt import dRRT
from discopygal.geometry_utils import conversions
from discopygal.solvers_infra.operations_counter import count_operation


class dRRT_star(dRRT):
    def __init__(self, num_expands, random_sample_counter, **kwargs):
        self.num_expands = num_expands
        self.random_sample_counter = random_sample_counter
        super().__init__(**kwargs)

    @classmethod
    def get_arguments(cls):
        args = super().get_arguments()
        args.update({
            'num_expands': ('Number of expand iterations:', 10, int),
            'num_landmarks': ('Number of Landmarks (in dRRT*):', 50, int),
            'prm_num_landmarks': ('Number of Landmarks (in PRM):', 200, int),
            'random_sample_counter': ('Sample random node rate (iterations):', 30, int),
        })
        return args

    def search_tensor_roadmap(self):
        """
        Load a scene into the solver.
        Also build the tensor roadmap.

        :param scene: scene to load
        :type scene: :class:`~discopygal.solver.Scene`
        """
        tensor_roadmap = self.tensor_roadmap
        v_last = tensor_roadmap.start
        tensor_roadmap.T.add_point(tensor_roadmap.start, cost=0)
        end = tensor_roadmap.end
        best_path_length = float("inf")

        # Add the given amount of landmarks to the RRT
        for i in range(self.num_expands):
            self.log(f"Expansion iteration {i}")
            cnt = 0
            while cnt <= self.num_landmarks:
                if self.random_sample_counter != 0 and (i * self.num_expands + cnt) % self.random_sample_counter == 0:
                    v_last = None
                v_last = self.expand_drrt_star(v_last, best_path_length)

                cnt += 1
                if cnt % 100 == 0:
                    self.log(f'added {cnt} landmarks in dRRT*')

            # Finally try to connect to the end point
            neighbors = tensor_roadmap.T.nearest_neighbors.k_nearest(end, self.k_nn+1)
            for neighbor in neighbors:
                if neighbor != end:
                    tensor_roadmap.try_connecting(end, neighbor)

            best_path_length = self.tensor_roadmap.cost(self.end)
            self.log(f"Best current length: {best_path_length}")

    def expand_drrt_star(self, v_last, best_path_length):
        tensor_roadmap = self.tensor_roadmap
        if v_last is None:
            # q_rand <-- RANDOM_SAMPLE()
            q_rand = tensor_roadmap.T.sample_free_point()

            # v_near <-- NEAREST_NEIGHBOR(T, q_rand)
            v_near = tensor_roadmap.nearest_tensor_vertex(q_rand)
        else:
            q_rand = tensor_roadmap.end
            v_near = v_last

        # v_new <-- I_d(v_near, q_rand)
        v_new = self.informed_expansion(v_near, q_rand)

        # N <-- Adj(v_new, G) ∩ T
        N = []
        tensor_roadmap_nodes = set(tensor_roadmap.T.points)
        count_operation("set_intersection", min(len(tensor_roadmap_nodes), len(tensor_roadmap.get_neighbors_in_tensor_product(v_new))))
        for tensor_point in tensor_roadmap_nodes.intersection(tensor_roadmap.get_neighbors_in_tensor_product(v_new)):
            if tensor_roadmap.T.is_edge_valid(v_new, tensor_point):
                N.append(tensor_point)

        # v_best <-- argmin(cost(v)) + cost(v, v_new) for v in N
        if len(N) != 0:
            v_best = min(N, key=lambda v: tensor_roadmap.cost(v) + tensor_roadmap.cost(v, v_new))
        else:
            return None

        if tensor_roadmap.cost(v_near, v_new) + tensor_roadmap.cost(v_near) > best_path_length:
            return None

        if not tensor_roadmap.T.graph.has_node(v_new) or \
           tensor_roadmap.cost(v_new) > tensor_roadmap.cost(v_best) + tensor_roadmap.cost(v_best, v_new):
            tensor_roadmap.connect_to_roadmap(v_new, v_best)

        for v in N:
            if v != v_best and tensor_roadmap.cost(v_new) + tensor_roadmap.cost(v_new, v) < tensor_roadmap.cost(v):
                tensor_roadmap.connect_to_roadmap(v, v_new)

        if tensor_roadmap.heuristic_measure(v_new) < tensor_roadmap.heuristic_measure(v_best):
            return v_new
        else:
            return None

    def informed_expansion(self, tensor_vertex, tensor_point):
        """
        Returns best new vertex to expand
        :param tensor_vertex: vertex on tensor roadmap to start from (v_near)
        :param tensor_point: point to expand towards (q_rand)
        :return: best new vertex on roadmap
        """
        new_vertex = []
        end_points = conversions.Point_d_to_Point_k_list(self.tensor_roadmap.end, 2)
        vertex_points = conversions.Point_d_to_Point_k_list(tensor_vertex, 2)
        for i, sampled_point in enumerate(conversions.Point_d_to_Point_k_list(tensor_point, 2)):
            roadmap = self.tensor_roadmap.roadmaps[self.tensor_roadmap.robots[i]]
            neighbors = list(roadmap.graph[vertex_points[i]])
            if sampled_point == end_points[i]:  # q_rand[i] == T[i]
                # v_new[i] = argmin(Adj(v_near[i]), H)
                # H is the heuristic measure: distance from point to target
                new_vertex.append(min(neighbors, key=lambda x: self.tensor_roadmap.heuristic_measure_for_single_robot(x, self.tensor_roadmap.robots[i])))
            else:
                # v_new[i] = random(Adj(v_near[i]))
                new_vertex.append(random.choice(neighbors))

        return conversions.Point_k_list_to_Point_d(new_vertex)
