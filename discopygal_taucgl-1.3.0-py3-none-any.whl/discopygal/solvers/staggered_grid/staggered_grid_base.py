import random
from math import sqrt, ceil

from discopygal.bindings import FT, Ss, Point_2, Segment_2, Point_d
from discopygal.solvers_infra import RobotDisc
from discopygal.solvers_infra.tensor_solver.tensor_solver import TensorSolver
from discopygal.geometry_utils import conversions

def cords_to_points_2(cords_x, cords_y):
    res = [Point_d(2, [FT(x), FT(y)]) for x in cords_x for y in cords_y]
    return res


class StaggeredGridBase(TensorSolver):
    """
    Abstract base staggered grid class
    """
    def __init__(self, eps, delta, **kwargs):
        super().__init__(**kwargs)
        # self.nearest_neighbors = NeighborsFinder()

        self.eps = eps
        self.delta = delta  # Clearance after the environment is shrunken to [0,1]^2
        self.is_multi_robot = True
        self.sample_method = "staggered_grid"
        self.grid = None
        self.radius = 0
        self.sources = None
        self.destinations = None
        self.set_parameters()

    @classmethod
    def get_arguments(cls):
        """
        Return a list of arguments and their description, defaults and types.
        Can be used by a GUI to generate fields dynamically.
        Should be overridded by solvers.

        :return: arguments dict
        :rtype: :class:`dict`
        """
        args = {
            'eps': ('Epsilon:', 9999, int),
            'delta': ('Delta:', 0.04, float),
        }
        args.update(super().get_arguments())
        return args

    def set_parameters(self):
        alpha = self.eps / sqrt(1 + self.eps * self.eps)
        y = self.eps/(2*(2+self.eps))
        self.edge_len = 1 - 2 * self.delta
        if self.is_multi_robot:
            # These may change as we modify bounds in the paper
            self.ball_radius = y * self.delta
            # self.connection_radius = Ker.FT(self.delta)*(Ker.FT(1+self.eps)/Ker.FT(2+self.eps))
            self.connection_radius = FT(self.delta)*(FT(1+self.eps)/FT(2+self.eps))*FT(1.0001)
            # self.connection_radius = Ker.FT(self.delta*1.001)
        else:
            self.ball_radius = alpha * self.delta
            self.connection_radius = FT(2*(alpha+sqrt(1-alpha**2))*self.delta)*FT(1.0001)
        unrounded_balls_per_dim = self.edge_len / (2 * self.ball_radius)
        print("unrounded number of balls:", unrounded_balls_per_dim ** 2 + (unrounded_balls_per_dim + 1) ** 2)
        self.balls_per_dim = ceil(unrounded_balls_per_dim)
        self.num_of_sample_points = self.balls_per_dim ** 2 + (self.balls_per_dim + 1) ** 2
        print("real number of balls:", self.num_of_sample_points)
        self.grid_points_per_dim = ceil(sqrt(self.num_of_sample_points))
        print("real number of grid points:", self.grid_points_per_dim**2)
        print(f"Ball radius: {self.ball_radius}")

    def build_robot_roadmap(self, _):
        if self.grid is None:
            self.grid = self.build_grid()
        return self.grid

    def build_grid(self):
        # TODO: set correct size also for other robot types
        radii = set([robot.radius.to_double() if isinstance(robot, RobotDisc) else 1 for robot in self.scene.robots])
        if len(radii) == 0:
            self.log("Error: must have at least one robot")
        elif len(radii) > 1:
            self.log("Error: this only works when all robots are of the same radii")
        self.radius = FT(list(radii)[0])

        self.grid = self.init_roadmap(self.scene, self.metric, self.nearest_neighbors_class, robots=[self.scene.robots[0]])

        if self._bounding_box.min_x != self._bounding_box.min_y or self._bounding_box.max_x != self._bounding_box.max_y:
            self.log("Error: Must be used on square scenes")

        self.max = max(self._bounding_box.max_x, self._bounding_box.max_y)
        self.min = min(self._bounding_box.min_x, self._bounding_box.min_y)
        self.sources = conversions.Point_d_to_Point_k_list(self.start, 2)
        self.destinations = conversions.Point_d_to_Point_k_list(self.end, 2)

        milestones = []
        for start_p in self.sources:
            milestones.append(start_p)
        for destination_p in self.destinations:
            milestones.append(destination_p)
        milestones += self.generate_milestones()

        self.make_graph(milestones)
        self.log(f"Vertices amount per robot:{len(self.grid.points)}")
        self.log(f"Edges amount per robot: {len(self.grid.edges)}")
        return self.grid

    def generate_milestones(self):
        def conv(num):
            return (self.max-self.min)*num+self.min

        res = []
        if self.sample_method == "staggered_grid":
            i = 0
            half_points_diff = (self.edge_len / self.balls_per_dim) / 2
            l1_cords = [conv(self.delta + (2 * i - 1) * half_points_diff) for i in range(1, self.balls_per_dim + 1)]
            l2_cords = [conv(self.delta + (2 * i) * half_points_diff) for i in range(self.balls_per_dim + 1)]
            l1 = cords_to_points_2(l1_cords, l1_cords)
            l2 = cords_to_points_2(l2_cords, l2_cords)
            all_points = l1+l2
            for point in all_points:
                if self.grid.is_point_valid(point) and \
                   self._bounding_box.min_x <= point[0] <= self._bounding_box.max_x and \
                   self._bounding_box.min_y <= point[1] <= self._bounding_box.max_y:
                    res.append(point)
                    i += 1
            return res

        if self.sample_method == "grid":
            i = 0
            points_diff = (self.edge_len / (self.grid_points_per_dim-1))
            cords = [conv(self.delta + i * points_diff) for i in range(self.grid_points_per_dim)]
            points = cords_to_points_2(cords, cords)
            for point in points:
                if self.grid.is_point_valid(point):
                    res.append(point)
                    i += 1
            return res

        if self.sample_method == "random":
            i = 0
            points = [Ss.Point_d(2, [FT(random.uniform(self.min+self.delta, self.max-self.delta)),
                                     FT(random.uniform(self.min+self.delta, self.max-self.delta))]) for _ in range(self.num_of_sample_points)]
            for point in points:
                if self.grid.is_point_valid(point):
                    res.append(point)
                    i += 1
            return res

        raise ValueError("Invalid configuration")

    def make_graph(self, milestones):
        self.grid.nearest_neighbors.max_cache = len(milestones)  # Fit points to nn only at the end
        for milestone in milestones:
            self.grid.add_point(milestone)

        for milestone in milestones:
            nearest = self.grid.nearest_neighbors.nearest_in_radius(milestone, self.connection_radius*FT(self.max-self.min))
            for neighbor in nearest:
                self.grid.add_edge(milestone, neighbor)
