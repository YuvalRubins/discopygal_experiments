import itertools
import scipy.special
import random

from discopygal.geometry_utils import conversions
from discopygal.solvers_infra import Scene
from discopygal.solvers_infra.SamplingSolver import SamplingSolver
from discopygal.bindings import Point_2, FT
from discopygal.solvers.prm import PRM
from discopygal.solvers.rrt import RRT


class HGraph(SamplingSolver):
    """
    A generic HGraph Solver. Receives a solver class which is the specific solver that is used to construct each path
    and for the local connector.

    :param solver_class: The specific solver class to use for the HGraph algorithm (to construct the paths and for the local connector).
    :type solver_class: :class:`~discopygal.solvers_infra.Solver.Solver`

    :param num_paths: The number of solutions (paths) to construct
    :type scene: :class:`int`

    :param neighborhood_distance: The radius of the local neighborhood to seek and connect optional bridges.
    :type neighborhood_distance: :class:`~discopygal.bindings.FT`

    """
    def __init__(self, solver_class, num_paths, neighborhood_distance, **kwargs):
        super().__init__(**kwargs)
        self.num_paths = num_paths
        for k, v in kwargs.items():
            self.__setattr__(k, v)
        self.original_solvers = [solver_class.init_solver(**kwargs) for _ in range(self.num_paths)]
        self.local_solver = solver_class.init_solver(**kwargs)
        self.neighborhood_distance = neighborhood_distance

    # TODO: implement All-Pairs H-Graph and Edit-Distance H-Graph
    def get_potential_bridges(self, path1, path2):
        """
        Return all pairs of points between two paths that are close enough to connect a bridge between them.

        :param path1: First path
        :type path1: [:class:`~discopygal.bindings.Point_d`]

        :param path2: Second path
        :type path2: [:class:`~discopygal.bindings.Point_d`]

        """
        bridges = []
        for v1, v2 in itertools.product(path1, path2):
            if v1 != v2 and self.metric.dist(v1, v2) < self.neighborhood_distance:
                bridges.append((v1, v2))
        return bridges

    def local_connector(self, v1, v2, roadmap):
        """
        Use :token:`solver_class` to locally connect to points v1 and v2, on roadmap

        :param v1: First point
        :type v1: :class:`~discopygal.bindings.Point_d`

        :param v2: Second point
        :type v2: :class:`~discopygal.bindings.Point_d`

        :param roadmap: The roadmap to add the edges of the local path
        :type v2: :class:`nx.Graph`
        """
        local_starts = conversions.Point_d_to_Point_2_list(v1)
        local_ends = conversions.Point_d_to_Point_2_list(v2)
        local_scene = Scene(self.scene.obstacles)
        for i, robot in enumerate(self.scene.robots):
            new_robot = type(robot).from_dict(robot.to_dict())
            new_robot.start = Point_2(*local_starts[i*2: i*2+1])
            new_robot.end = Point_2(*local_ends[i*2: i*2+1])
            local_scene.add_robot(new_robot)

        local_multi_path = self.local_solver.solve(local_scene)
        if local_multi_path is not None and not local_multi_path.is_empty():
            local_path = []
            for multi_point in zip(*[p.get_points() for p in local_multi_path.paths.values()]):
                local_path.append(conversions.Point_2_list_to_Point_d(multi_point))

            for i in range(len(local_path) - 1):
                roadmap.add_edge(local_path[i], local_path[i + 1])

    def build_roadmap(self):
        roadmap = self.init_roadmap()

        paths = []
        for i, solver in enumerate(self.original_solvers):
            path_color = f"RGB " + ','.join(map(str, random.choices(range(256), k=3)))
            self.log(f"Running solver {i+1}")
            multi_path = solver.solve(self.scene)
            if multi_path is not None and not multi_path.is_empty():
                path = []
                for multi_point in zip(*[p.get_points() for p in multi_path.paths.values()]):
                    path.append(conversions.Point_2_list_to_Point_d(multi_point))

                paths.append(path)
                for i in range(len(path) - 1):
                    roadmap.add_edge(path[i], path[i + 1], color=path_color)

        if len(paths) == 0:
            self.log("All solvers failed to find a path")
            return roadmap

        cnt = 0
        self.log(f"connecting {int(scipy.special.binom(len(paths), 2))} combinations")
        for path1, path2 in itertools.combinations(paths, 2):
            self.log(f"combination number {cnt}")
            cnt += 1
            for v1, v2 in self.get_potential_bridges(path1, path2):
                if not roadmap.add_edge(v1, v2):
                    self.local_connector(v1, v2, roadmap)

        return roadmap

    @classmethod
    def get_arguments(cls):
        args = super().get_arguments()
        args.update({
            'num_paths': ('Number of paths:', 10, int),
            'neighborhood_distance': ('Neighborhood radius to connect bridges:', 5, FT),
        })
        return args


class MetaHGraphSolver(HGraph):
    """
    A meta class to create specific HGraph solvers (HGraph solver based on specific solver class)
    """
    def __init__(self, **kwargs):
        super().__init__(self.solver_class, **kwargs)

    @classmethod
    def get_arguments(cls):
        args = super().get_arguments()
        args.update(cls.solver_class.get_arguments())
        return args

    @staticmethod
    def make_hgraph_solver_class(solver_class):
        """
        | Create a specific HGraph solver class from given solver_class.
        | Name of the class will be: HGraph_<solver_class_name>

        :param solver_class: The solver class to make a HGraph solver based on it
        :type v2: :class:`~discopygal.solvers_infra.Solver.Solver`

        :return: The new created solver class
        :rtype: :class:`HGraph`
        """
        return type("HGraph_" + solver_class.__name__, (MetaHGraphSolver,), {"solver_class": solver_class})


HGraph_PRM = MetaHGraphSolver.make_hgraph_solver_class(PRM)
HGraph_RRT = MetaHGraphSolver.make_hgraph_solver_class(RRT)
