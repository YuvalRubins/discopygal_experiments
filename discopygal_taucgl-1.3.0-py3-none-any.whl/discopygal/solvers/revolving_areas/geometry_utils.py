from typing import Optional, Tuple
import math

from discopygal.bindings import Segment_2, Point_2, Vector_2, FT
from discopygal.bindings import Ker

Line_2 = Ker.Line_2  # Missing in discopygal bindings init.

from .metric_utils import l2_dist


EPSILON = 1e-10


def get_line_coefs(line: Line_2) -> Tuple[float, float, float]:
    return line.a().to_double(), line.b().to_double(), line.c().to_double()


def get_point_coors(point: Point_2) -> Tuple[float, float]:
    return point.x().to_double(), point.y().to_double()


def transpose_line(line: Line_2) -> Line_2:
    a, b, c = get_line_coefs(line=line)
    return Line_2(b, a, c)


def transpose_point(point: Point_2) -> Point_2:
    x, y = get_point_coors(point=point)
    return Point_2(y, x)


def point_on_segment(segment: Segment_2, point: Point_2) -> bool:
    """NOTE: Function assumes point is collinear with segment!"""
    source = segment.source()
    target = segment.target()

    x_between = (
        min(source.x(), target.x()) - EPSILON
        <= point.x()
        <= max(source.x(), target.x()) + EPSILON
    )
    y_between = (
        min(source.y(), target.y()) - EPSILON
        <= point.y()
        <= max(source.y(), target.y()) + EPSILON
    )

    return x_between and y_between


def intersect_lines(line1: Line_2, line2: Line_2) -> Optional[Point_2]:
    a1, b1, c1 = get_line_coefs(line=line1)
    a2, b2, c2 = get_line_coefs(line=line2)

    den = a1 * b2 - a2 * b1
    if abs(den) < EPSILON:
        return None

    x_num = b1 * c2 - b2 * c1
    y_num = a2 * c1 - a1 * c2

    return Point_2(x_num / den, y_num / den)


def intersect_segments(segment1: Segment_2, segment2: Segment_2) -> Optional[Point_2]:
    if segment1.source() == segment1.target() or segment2.source() == segment2.target():
        return None

    line_intersection = intersect_lines(
        line1=segment1.supporting_line(), line2=segment2.supporting_line()
    )
    if not line_intersection:
        return None

    if not (
        point_on_segment(segment1, line_intersection)
        and point_on_segment(segment2, line_intersection)
    ):
        return None

    return line_intersection


def intersect_line_circle(
    line: Line_2, center: Point_2, radius: FT
) -> Tuple[Optional[Point_2], Optional[Point_2]]:
    a, b, c = get_line_coefs(line=line)
    if a == 0:
        transposed_line = transpose_line(line=line)
        transposed_center = transpose_point(point=center)
        transpose_inter1, transpose_inter2 = intersect_line_circle(
            line=transposed_line, center=transposed_center, radius=radius
        )
        inter1 = transpose_point(point=transpose_inter1) if transpose_inter1 else None
        inter2 = transpose_point(point=transpose_inter2) if transpose_inter2 else None
        return inter1, inter2

    x, y = get_point_coors(point=center)
    r = radius.to_double()

    a_squared = a * a
    b_squared = b * b
    c_squared = c * c
    x_squared = x * x
    y_squared = y * y
    r_squared = r * r

    a_tag = 1 + b_squared / a_squared
    b_tag = 2 * b * c / a_squared + 2 * x * b / a - 2 * y
    c_tag = c_squared / a_squared + x_squared + y_squared + 2 * x * c / a - r_squared

    D = b_tag * b_tag - 4 * a_tag * c_tag
    if D < -EPSILON:
        return None, None

    # `abs` in case it is between -EPSILON and 0.
    sqrt_D = math.sqrt(abs(D))
    y_first = (-b_tag + sqrt_D) / (2 * a_tag)
    x_first = (-c - b * y_first) / a
    inter1 = Point_2(x_first, y_first)
    if abs(D) < EPSILON:
        return inter1, None

    y_second = (-b_tag - sqrt_D) / (2 * a_tag)
    x_second = (-c - b * y_second) / a
    inter2 = Point_2(x_second, y_second)

    return inter1, inter2


def intersect_segment_circle(
    segment: Segment_2, center: Point_2, radius: FT
) -> Tuple[Optional[Point_2], Optional[Point_2]]:
    if segment.source() == segment.target():
        return None, None

    inter1, inter2 = intersect_line_circle(
        line=segment.supporting_line(), center=center, radius=radius
    )

    if inter1 is None or not point_on_segment(segment, inter1):
        inter1 = None

    if inter2 is None or not point_on_segment(segment, inter2):
        inter2 = None

    return inter1, inter2


def relative_pos_on_segment(segment: Segment_2, point: Point_2):
    assert point_on_segment(segment, point), "Given point not on segment."

    start = segment.source()
    end = segment.target()

    x_diff = (end.x() - start.x()).to_double()
    y_diff = (end.y() - start.y()).to_double()

    if abs(x_diff) < EPSILON and abs(y_diff) < EPSILON:
        return 0

    if abs(x_diff) > EPSILON:
        t = (point.x() - start.x()).to_double() / x_diff
    elif abs(y_diff) > EPSILON:
        t = (point.y() - start.y()).to_double() / y_diff
    else:
        raise ValueError("Received segment of length 0.")

    return t


def translate_point(point: Point_2, translation_vec: Tuple[float, float]):
    x_diff, y_diff = translation_vec
    return Point_2(point.x() + x_diff, point.y() + y_diff)


def translate_segment(segment: Segment_2, translation_vec: Tuple[float, float]):
    source = segment.source()
    target = segment.target()
    return Segment_2(
        translate_point(source, translation_vec),
        translate_point(target, translation_vec),
    )


def is_right(p1: Point_2, p2: Point_2, p3: Point_2) -> bool:
    val = (p2.y() - p1.y()) * (p3.x() - p2.x()) - (p2.x() - p1.x()) * (p3.y() - p2.y())

    return val > 0


def is_point_between_segments(
    point: Point_2, segment1: Segment_2, segment2: Segment_2
) -> bool:
    if (
        segment1.source() == segment1.target()
        and segment2.source() == segment2.target()
    ):
        return False

    segment1_source = segment1.source()
    segment1_target = segment1.target()

    segment2_source = segment2.source()
    segment2_target = segment2.target()

    turns = [
        is_right(segment1_source, segment1_target, point),
        is_right(segment1_target, segment2_target, point),
        is_right(segment2_target, segment2_source, point),
        is_right(segment2_source, segment1_source, point),
    ]

    return all(turns) or not any(turns)


def is_point_in_circle(point: Point_2, center: Point_2, radius: float):
    return l2_dist(point, center) <= radius


def is_point_in_inflated_segment(
    point: Point_2,
    inflated_segment: Segment_2,
    moved_inflated_segment1: Segment_2,
    moved_infalted_segment2: Segment_2,
    inflate_value: float,
):
    inflated_source = inflated_segment.source()
    inflated_target = inflated_segment.target()

    return (
        is_point_between_segments(
            point=point,
            segment1=moved_inflated_segment1,
            segment2=moved_infalted_segment2,
        )
        or is_point_in_circle(point=point, center=inflated_source, radius=inflate_value)
        or is_point_in_circle(point=point, center=inflated_target, radius=inflate_value)
    )


def extreme_relative_pos_on_segment(segment: Segment_2, *points: Optional[Point_2]):
    min_relative_pos = 1
    max_relative_pos = 0
    for point in points:
        if point is None:
            continue

        relative_pos = relative_pos_on_segment(segment, point)
        min_relative_pos = min(min_relative_pos, relative_pos)
        max_relative_pos = max(max_relative_pos, relative_pos)

    if min_relative_pos > max_relative_pos:
        return None, None

    return min_relative_pos, max_relative_pos


def intersect_segment_inflated_segment(
    segment: Segment_2, inflated_segment: Segment_2, inflate_value: float
) -> Optional[Tuple[float, float]]:
    line = inflated_segment.supporting_line()
    x_coef, y_coef, _ = get_line_coefs(line=line)
    norm = math.sqrt(x_coef**2 + y_coef**2)
    scale_value = inflate_value
    if norm != 0:
        scale_value /= norm
    translation_vec = (scale_value * x_coef, scale_value * y_coef)
    minus_translation_vec = tuple(-v for v in translation_vec)

    inter_segment1 = translate_segment(inflated_segment, translation_vec)
    inter_segment2 = translate_segment(inflated_segment, minus_translation_vec)

    inter1 = intersect_segments(segment, inter_segment1)
    inter2 = intersect_segments(segment, inter_segment2)

    if inter1 and inter2:
        return extreme_relative_pos_on_segment(segment, inter1, inter2)

    inflated_source = inflated_segment.source()
    inflated_target = inflated_segment.target()

    source_inter1, source_inter2 = intersect_segment_circle(
        segment=segment, center=inflated_source, radius=FT(inflate_value)
    )
    target_inter1, target_inter2 = intersect_segment_circle(
        segment=segment, center=inflated_target, radius=FT(inflate_value)
    )

    source = segment.source()
    target = segment.target()

    source_inside = None
    if is_point_in_inflated_segment(
        source,
        inflated_segment=inflated_segment,
        moved_inflated_segment1=inter_segment1,
        moved_infalted_segment2=inter_segment2,
        inflate_value=inflate_value,
    ):
        source_inside = source

    target_inside = None
    if is_point_in_inflated_segment(
        target,
        inflated_segment=inflated_segment,
        moved_inflated_segment1=inter_segment1,
        moved_infalted_segment2=inter_segment2,
        inflate_value=inflate_value,
    ):
        target_inside = target

    return extreme_relative_pos_on_segment(
        segment,
        inter1,
        inter2,
        source_inter1,
        source_inter2,
        target_inter1,
        target_inter2,
        source_inside,
        target_inside,
    )


def dot(vector1: Vector_2, vector2: Vector_2):
    return (vector1.x() * vector2.x() + vector1.y() * vector2.y()).to_double()


def segment_point_distance(segment: Segment_2, point: Point_2):
    segment_vector = segment.to_vector()
    point_vector = Vector_2(segment.source(), point)

    # Find proportion and normalize.
    t = dot(point_vector, segment_vector)
    squared_length = segment_vector.squared_length().to_double()
    if squared_length != 0:
        t /= squared_length
    # `t` is between 0 and 1.
    t = min(max(t, 0), 1)

    closest_point = segment.source() + t * segment_vector
    return l2_dist(point, closest_point)


def segments_distance(segment1: Segment_2, segment2: Segment_2):
    if intersect_segments(segment1, segment2) is not None:
        return 0

    return min(
        segment_point_distance(segment=segment1, point=segment2.source()),
        segment_point_distance(segment=segment1, point=segment2.target()),
        segment_point_distance(segment=segment2, point=segment1.source()),
        segment_point_distance(segment=segment2, point=segment1.target()),
    )
