from typing import List, Optional

from discopygal.solvers_infra import RobotDisc

from discopygal.bindings import Polygon_2

import discopygal.solvers.revolving_areas.path_combiners as path_combiners
from .path_combiner_mode import PathCombinerMode


class PathCombinerFactory:
    def __init__(
        self,
        obstacles: List[Polygon_2],
        num_landmarks: int,
        k: int,
        epsilon: float,
        allow_backtracking: bool,
    ):
        self.obstacles = obstacles
        self.num_landmarks = num_landmarks
        self.k = k
        self.epsilon = epsilon
        self.allow_backtracking = allow_backtracking

    def create_path_combiner(
        self,
        mode: PathCombinerMode,
        robots: List[RobotDisc],
        sub_mode: Optional[PathCombinerMode] = None,
        depth: int = 1,
        max_simultaneous_robots: int = -1,
        min_distance: float = 0,
        pairing_k: int = -1,
    ):
        if mode == PathCombinerMode.SEQUENTIAL:
            return path_combiners.SequentialPathCombiner(robots)
        elif mode == PathCombinerMode.REVOLVING_AREAS:
            return path_combiners.RevolvingAreasPathCombiner(robots, self.obstacles)
        elif mode == PathCombinerMode.PRM:
            return path_combiners.PRMPathCombiner(
                robots,
                num_landmarks=self.num_landmarks,
                k=self.k,
                min_distance=min_distance,
                allow_backtracking=self.allow_backtracking,
            )
        elif mode == PathCombinerMode.REFINEMENT:
            return path_combiners.RefinementPathCombiner(
                robots,
                min_distance=min_distance,
                epsilon=self.epsilon,
                allow_backtracking=self.allow_backtracking,
            )
        elif mode == PathCombinerMode.OBSTACLES2:
            return path_combiners.Obstacles2PathCombiner(
                robots,
                min_distance=min_distance,
                allow_backtracking=self.allow_backtracking,
            )
        elif mode == PathCombinerMode.PAIRS:
            assert sub_mode != PathCombinerMode.PAIRS, "`sub_mode` cannot be PAIRS."
            return path_combiners.PairsPathCombiner(
                robots,
                min_distance=min_distance,
                path_combiner_factory=self,
                path_combiner_mode=sub_mode,
                depth=depth,
                pairing_k=pairing_k,
                max_simultaneous_robots=max_simultaneous_robots,
            )
        else:
            raise ValueError(f"Mode '{mode}' is not supported.")
