import time

import tqdm
import pandas as pd

class Experiment_CompareFunctions(object):
    """
    Class that allows running comparison experiments on two given functions.
    The functions should have the same signature.
    This also allows exporting results to various formats.

    :param f1: list of functions
    :type f1: function
    :param experiment_args: dict that pairs experiment name with arguments to pass to each function
    :type experiment_args: dict<str, list>
    """
    def __init__(self, fs, experiment_args):
        self.fs = fs
        self.experiment_args = experiment_args
        self.results = {}

    def export_time(self, time_metric, path, names):
        """
        Export the times to a readable csv.
        User needs to supply a list of names for each function (which will be in the headers),
        export a table of runtimes.
        """
        d = {name: [] for name in names}
        d['experiment'] = []
        for experiment in self.experiment_args:
            d['experiment'].append(experiment)
            for i in range(len(self.fs)):
                d[names[i]].append(self.results[experiment][time_metric + '_f%d' % i])
        df = pd.DataFrame(d)
        if path.endswith('.csv'):
            df.to_csv(path, index=False)
        else:
            df.to_excel(path, index=False)



    def run_function(self, f_idx, args):
        """
        Run self.f1 with given args.
        Return the runtime and the result.
        """
        f = self.fs[f_idx]
        start_time = time.time()
        res = f(*args)
        end_time = time.time()
        return {
            'elapsed_time': end_time - start_time,
            'res': res
        }
        
    def run_experiment(self, n_times=1):
        """
        Run the experiment for n times. We store the average, max and min times
        as well as the *last* experiment result
        """
        self.results = {}
        print("running experiments...")
        for experiment in tqdm.tqdm(self.experiment_args):
            avg_times = [0 for _ in range(len(self.fs))]
            min_times = [None for _ in range(len(self.fs))]
            max_times = [None for _ in range(len(self.fs))]
            results = [None for _ in range(len(self.fs))]

            self.results[experiment] = {}
            for i in range(len(self.fs)):
                for _ in tqdm.tqdm(range(n_times)):
                    run_f = self.run_function(i, self.experiment_args[experiment])

                    avg_times[i] += run_f['elapsed_time'] / n_times
                    if min_times[i] is None or run_f['elapsed_time'] < min_times[i]:
                        min_times[i] = run_f['elapsed_time']
                    if max_times[i] is None or run_f['elapsed_time'] > max_times[i]:
                        max_times[i] = run_f['elapsed_time']
                    
                    results[i] = run_f['res']
                
                # Log the current experiment results
                self.results[experiment]['avg_time_f%d' % i] = avg_times[i]
                self.results[experiment]['min_time_f%d' % i] = min_times[i]
                self.results[experiment]['max_time_f%d' % i] = max_times[i]
                self.results[experiment]['res_f%d' % i] = results[i]