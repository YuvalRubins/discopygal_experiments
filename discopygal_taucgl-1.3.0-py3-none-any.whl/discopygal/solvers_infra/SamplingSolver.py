import abc
import math
import networkx as nx

from . import PathPoint, Path, PathCollection, Scene
from .samplers import Sampler, Sampler_Uniform
from .metrics import Metric, Metric_Euclidean, Metric_SumDist
from .nearest_neighbors import NearestNeighbors, NearestNeighbors_sklearn
from ..bindings import Segment_2, Point_2
from ..geometry_utils import collision_detection, conversions
from .Solver import Solver
from .operations_counter import count_calls
from .roadmap import Roadmap


def dijkstra_complexity(v, e):
    return round(e + v * math.log2(v))


@count_calls(lambda graph, _, __: dijkstra_complexity(len(graph.nodes), len(graph.edges)))
def has_path(graph, start, end):
    return nx.algorithms.has_path(graph, start, end)


@count_calls(lambda graph, _, __: dijkstra_complexity(len(graph.nodes), len(graph.edges)))
def shortest_path(graph, start, end, weight="weight"):
    return nx.algorithms.shortest_path(graph, start, end, weight=weight)


@count_calls(lambda graph, _, __: dijkstra_complexity(len(graph.nodes), len(graph.edges)))
def shortest_path_length(graph, start, end, weight="weight"):
    return nx.algorithms.shortest_path_length(graph, start, end, weight=weight)


class SamplingSolver(Solver):
    """
    A Base Solver class for sampled based solvers (builds a roadmap from sampled points and searches on it).

    :param nearest_neighbors: a nearest neighbors algorithm. if None then use sklearn implementation
    :type nearest_neighbors: :class:`~discopygal.solvers_infra.nearest_neighbors.NearestNeighbors` or :class:`None`
    :param metric: a metric for weighing edges, can be different then the nearest_neighbors metric!
        If None then use euclidean metric
    :type metric: :class:`~discopygal.solvers_infra.metrics.Metric` or :class:`None`
    :param sampler: sampling algorithm/method. if None then use uniform sampling
    :type sampler: :class:`~discopygal.solvers_infra.samplers.Sampler`
    """
    def __init__(self, nearest_neighbors_class=None, metric=None, sampler=None, **kwargs):
        super().__init__(**kwargs)

        self.nearest_neighbors_class: NearestNeighbors = nearest_neighbors_class or NearestNeighbors_sklearn
        self.metric: Metric = metric or Metric_SumDist
        self.sampler: Sampler = sampler or Sampler_Uniform()

        self.roadmap = None
        self.start = None
        self.end = None

    def get_graph(self):
        """
        Return a graph (if applicable).
        Can be overridded by solvers.

        :return: graph whose vertices are :class:`~discopygal.bindings.Point_2` or :class:`~discopygal.bindings.Point_d`
        :rtype: :class:`networkx.Graph` or :class:`None`
        """
        return self.roadmap.graph

    def init_roadmap(self, scene=None, metric=None, nearest_neighbors_class=None, sampler=None, robots=None, is_directed=False):
        """
        A wrapper function to easily initialize a new empty roadmap with the given attributes or, if not given,
        with the solvers attributes

        :return: Newly created roadmap
        :rtype: :class:`~discopygal.solvers_infra.roadmap.Roadmap`
        """
        return Roadmap(scene or self.scene,
                       metric or self.metric,
                       nearest_neighbors_class or self.nearest_neighbors_class,
                       sampler or self.sampler,
                       robots,
                       is_directed=is_directed)

    @abc.abstractmethod
    def build_roadmap(self):
        """
        Constructs the roadmap of points in the configuration space which a path will be searched on to find a solution.
        Every sampling solver should implement how to build the roadmap.

        :return: The built roadmap. Each node represents a point in configuration space (dimension = 2*robots_num)
        :rtype: :class:`~discopygal.solvers_infra.roadmap.Roadmap`
        """
        raise NotImplementedError()

    def load_scene(self, scene: Scene):
        """
        Load a scene into the solver.
        Also build the roadmap.

        :param scene: scene to load
        :type scene: :class:`~discopygal.solvers_infra.Scene`

        :return: The built roadmap.
        :rtype: :class:`~discopygal.solvers_infra.roadmap.Roadmap`
        """
        super().load_scene(scene)
        self.sampler.set_scene(scene, self._bounding_box)

        self.start = conversions.Point_2_list_to_Point_d([robot.start for robot in scene.robots])
        self.end = conversions.Point_2_list_to_Point_d([robot.end for robot in scene.robots])
        self.roadmap = self.build_roadmap()
        return self.roadmap

    def search_path_on_roadmap(self):
        """
        After already constructed a roadmap, plan a path for each robot
        (i.e. return paths for all the robots)
        If failed to find a path for each robot return an empty :class:`~discopygal.solvers_infra.PathCollection` (:code:`PathCollection()`)

        The search method of the basic class :class:`SamplingSolver` is simply finding the shortest path according to the weights of the edges
        (the weight attribute should be called :code:`weight`)

        :return: Path collection of motion planning (path for each robot)
        :rtype: :class:`~discopygal.solvers_infra.PathCollection`
        """
        assert self.roadmap
        if not has_path(self.roadmap.graph, self.start, self.end):
            return PathCollection()

        # Convert from a sequence of Point_d points to PathCollection
        tensor_path = shortest_path(self.roadmap.graph, self.start, self.end)
        self.log(f'Path length on roadmap: {Path.path_from_points(tensor_path).calculate_length(self.metric)}')
        path_collection = PathCollection(metric=self.metric)
        for i, robot in enumerate(self.scene.robots):
            points = []
            for point in tensor_path:
                points.append(PathPoint(Point_2(point[2*i], point[2*i+1])))
            path = Path(points)
            path_collection.add_robot_path(robot, path)

        return path_collection

    def _solve(self):
        return self.search_path_on_roadmap()
