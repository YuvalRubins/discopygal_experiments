from functools import wraps

basic_operations_call_counts = {}


def count_operation(operation_name, increment):
    basic_operations_call_counts[operation_name] = basic_operations_call_counts.get(operation_name, 0) + increment


def count_calls(get_increment=None):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Calculate increment based on function parameters
            increment = get_increment(*args, **kwargs) if get_increment else 1
            count_operation(func.__qualname__, increment)
            return func(*args, **kwargs)
        return wrapper
    return decorator
