from functools import wraps

basic_operations_call_counts = {}


def count_calls(get_increment=None):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Calculate increment based on function parameters
            increment = get_increment(*args, **kwargs) if get_increment else 1
            basic_operations_call_counts[func.__qualname__] = basic_operations_call_counts.get(func.__qualname__, 0) + increment
            return func(*args, **kwargs)
        return wrapper
    return decorator
