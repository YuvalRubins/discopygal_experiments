import math

import sklearn.metrics

from ..bindings import Point_d, Point_2, FT, Ss
from ..geometry_utils import conversions
from ..solvers_infra.operations_counter import OperationsCounter


class MetricNotImplemented(Exception):
    pass


class Metric(object):
    """
    Representation of a metric for nearest neighbor search.
    Should support all kernels/methods for nearest neighbors
    (like CGAL and sklearn).
    """ 
    def __init__(self):
        pass

    @staticmethod
    def dist(p, q):
        """
        Return the distance between two points

        :param p: first point
        :type p: :class:`~discopygal.bindings.Point_2` or :class:`~discopygal.bindings.Point_d`
        :param q: second point
        :type q: :class:`~discopygal.bindings.Point_2` or :class:`~discopygal.bindings.Point_d`

        :return: distance between p and q
        :rtype: :class:`~discopygal.bindings.FT`
        """
        if type(p) is Point_2 and type(q) is Point_2:
            return FT(0)
        elif type(p) is Point_d and type(q) is Point_d:
            return FT(0)
        else:
            raise MetricNotImplemented('p,q should be Point_2 or Point_d')

    @staticmethod
    def CGALPY_impl():
        """
        Return the metric as a CGAL metric object (of the spatial search module)
        """
        raise MetricNotImplemented('CGAL')

    @staticmethod
    def sklearn_impl():
        """
        Return the metric as sklearn metric object 
        """
        raise MetricNotImplemented('sklearn')


class Metric_Euclidean(Metric):
    """
    Implementation of the Euclidean metric for nearest neighbors search
    """
    @staticmethod
    @OperationsCounter.count_calls(lambda p, q: p.dimension())
    def dist(p, q):
        """
        Return the distance between two points

        :param p: first point
        :type p: :class:`~discopygal.bindings.Point_2` or :class:`~discopygal.bindings.Point_d`
        :param q: second point
        :type q: :class:`~discopygal.bindings.Point_2` or :class:`~discopygal.bindings.Point_d`

        :return: distance between p and q
        :rtype: :class:`~discopygal.bindings.FT`
        """
        if type(p) is Point_2 and type(q) is Point_2:
            d = (p.x() - q.x())*(p.x() - q.x()) + (p.y() - q.y())*(p.y() - q.y())
            d = math.sqrt(d.to_double())
            return FT(d)
        elif type(p) is Point_d and type(q) is Point_d and p.dimension() == q.dimension():
            d = FT(0)
            for i in range(p.dimension()):
                d += (p[i] - q[i]) * (p[i] - q[i])
            d = math.sqrt(d.to_double())
            return FT(d)
        else:
            raise MetricNotImplemented('p,q should be Point_2 or Point_d')

    @staticmethod
    def CGALPY_impl():
        """
        Return the metric as a CGAL metric object (of the spatial search module)
        """
        return Ss.Euclidean_distance()
    
    @staticmethod
    def sklearn_impl():
        """
        Return the metric as sklearn metric object 
        """
        return sklearn.metrics.DistanceMetric.get_metric('euclidean')

class Metric_SumDist(Metric):
    """
    Implementation of metric of sum of distances between each pair of points
    Suppose p,q are 2*d dimensional points, then there are d 2-D points in each of them,
    so return the sum of the d distances between each pair of points
    """
    @OperationsCounter.count_calls(lambda p, q: p.dimension())
    @staticmethod
    def dist(p, q):
        """
        Return the distance between two points

        :param p: first point
        :type p: :class:`~discopygal.bindings.Point_2` or :class:`~discopygal.bindings.Point_d`
        :param q: second point
        :type q: :class:`~discopygal.bindings.Point_2` or :class:`~discopygal.bindings.Point_d`

        :return: distance between p and q
        :rtype: :class:`~discopygal.bindings.FT`
        """
        if type(p) is Point_2:
            p = [p]
        elif type(p) is Point_d:
            p = conversions.Point_d_to_Point_2_list(p)
        else:
            raise MetricNotImplemented('p,q should be Point_2 or Point_d')


        if type(q) is Point_2:
            q = [q]
        elif type(q) is Point_d:
            q = conversions.Point_d_to_Point_2_list(q)
        else:
            raise MetricNotImplemented('p,q should be Point_2 or Point_d')

        assert len(p) == len(q)
        return sum(Metric_Euclidean.dist(pi, qi) for pi, qi in zip(p, q))
