import networkx as nx
from typing import List

from ..geometry_utils import collision_detection, conversions
from ..bindings import Segment_2
from ..solvers_infra import Scene, Metric, Robot
from ..solvers_infra.samplers import Sampler
from ..solvers_infra.nearest_neighbors import NearestNeighbors, NearestNeighborsCached
from ..solvers_infra.metrics import Metric_Euclidean
from ..solvers_infra.operations_counter import count_calls


class Roadmap(object):
    """
    | A class that represents a roadmap, which has the roadmap graph (points and edges between them) and
    | also includes collision detection that ables to check valid points and edges, ability to add points and edges.

    | All points in roadmap graph are from type :class:`~discopygal.bindings.Point_d`
    | This means they are all :class:`~discopygal.bindings.Point_d` where d is: (dimension of a single robot point) * (number of robots)

    :param scene: the scene of the roadmap
    :type scene: :class:`~discopygal.solvers_infra.Scene`
    :param metric: Metric to use
    :type metric: :class:`~discopygal.solvers_infra.metric.Metric`
    :param nearest_neighbors_class: a nearest neighbors algorithm. Pass a class, not an object! A new nearest_neighbors instance will be created.
    :type nearest_neighbors_class: :class:`~discopygal.solvers_infra.nearest_neighbors.NearestNeighbors` or :class:`None`
    :param sampler: sampling algorithm/method.
    :type sampler: :class:`~discopygal.solvers_infra.samplers.Sampler`
    :param robots: robots for which we built the roadmap for
    :type robot: :class:List[`~discopygal.solvers_infra.Robot`]
    :param is_directed: Is the roadmap graph directed or not
    :type robot: :class:`bool`
    """
    def __init__(self, scene: Scene, metric: Metric, nearest_neighbors_class: NearestNeighbors, sampler: Sampler = None, robots: List[Robot] = None, is_directed: bool = False):
        self.robots = robots or scene.robots
        self.sampler = sampler
        self.metric = metric

        # Build collision detection for each robot
        self.collision_detection = {
            robot: collision_detection.ObjectCollisionDetection(scene.obstacles, robot) for robot in self.robots
        }

        self.nearest_neighbors = nearest_neighbors_class(Metric_Euclidean)
        if not isinstance(self.nearest_neighbors, NearestNeighborsCached):
            self.nearest_neighbors = NearestNeighborsCached(self.nearest_neighbors)

        if is_directed:
            self.graph = nx.DiGraph()
        else:
            self.graph = nx.Graph()

    def is_point_valid(self, point):
        """
        Is a given point valid on roadmap (no collisions)

        :param point: point to check
        :type point: :class:`~discopygal.bindings.Point_d`

        :return: True/False
        :rtype: :class:`bool`
        """
        for i, p in enumerate(conversions.Point_d_to_Point_2_list(point)):
            if not self.collision_detection[self.robots[i]].is_point_valid(p):
                return False
        return True

    def add_point(self, point, check_if_valid=True, **extra_args_for_point):
        """
        Try to add a point to the roadmap.
        If point is invalid - return None.

        :param point: point to add
        :type point: :class:`~discopygal.bindings.Point_d` or :class:`~discopygal.bindings.Point_2`
        :param check_if_valid: check if point is valid before adding it
        :type check_if_valid: :class:`bool`
        :param extra_args_for_point: extra data added to the node of the point (can be accessed by self.points[<point>][<key>])
        :type extra_args_for_point: :class:`dict`

        :return: the given point if point was added successfully, otherwise returns None on failure.
        :rtype: :class:`~discopygal.bindings.Point_d`
        """
        point = conversions.Point_2_to_Point_d(point)

        if self.graph.has_node(point):
            return point

        if check_if_valid and not self.is_point_valid(point):
            return None

        self.graph.add_node(point, **extra_args_for_point)
        self.nearest_neighbors.add_point(point)
        return point

    def sample_free_point(self):
        """
        Sample a free random point in configuration space
        Dimension is 2*robots_num

        :return: Sampled free point
        :rtype: :class:`~discopygal.bindings.Point_d`
        """
        p_rand = []
        for i, _ in enumerate(self.robots):
            sample = self.sampler.sample()
            while not self.collision_detection[self.robots[i]].is_point_valid(sample):
                sample = self.sampler.sample()
            p_rand.append(sample)
        p_rand = conversions.Point_2_list_to_Point_d(p_rand)
        return p_rand

    def add_sampled_point(self):
        """
        Sample a random point and try to add it to the roadmap.
        On success return the added point, otherwise return None.

        :return: The added point
        :rtype: :class:`~discopygal.bindings.Point_d`
        """
        point = self.sample_free_point()
        return self.add_point(point, check_if_valid=False)

    def is_edge_valid(self, p, q):
        """
        Get two points in the configuration space and decide if they can be connected -
        i.e. all continuous points from the the source to the dest are collision free.

        :param p: Start point
        :type p: :class:`~discopygal.bindings.Point_d`
        :param q: End point
        :type q: :class:`~discopygal.bindings.Point_d`

        :return: Can they be connected
        :rtype: :class:`bool`
        """
        if p == q:
            return False

        p_list = conversions.Point_d_to_Point_2_list(p)
        q_list = conversions.Point_d_to_Point_2_list(q)

        # Check validity of each edge separately
        for i, robot in enumerate(self.robots):
            edge = Segment_2(p_list[i], q_list[i])
            if not self.collision_detection[robot].is_edge_valid(edge):
                return False

        # Check validity of coordinated robot motion
        for i, robot1 in enumerate(self.robots):
            for j, robot2 in enumerate(self.robots):
                if j <= i:
                    continue
                edge1 = Segment_2(p_list[i], q_list[i])
                edge2 = Segment_2(p_list[j], q_list[j])
                if collision_detection.collide_two_robots(robot1, edge1, robot2, edge2):
                    return False

        return True

    def add_edge(self, p, q, check_if_valid=True, weight=None, **extra_args_for_edge):
        """
        Get two vertices p, q and try to connect them.
        If we cannot connect them - return False.

        :param p: first point
        :type p: :class:`~discopygal.bindings.Point_d`
        :param q: second point
        :type q: :class:`~discopygal.bindings.Point_d`
        :param check_if_valid: check if edge is valid before adding it
        :type check_if_valid: :class:`bool`
        :param weight: Weight of the edge (if given None the weight will be the distance according to the metric)
        :type weight: :class:`float`
        :param extra_args_for_edge: extra data added to the edge (can be accessed by self.edges[p, q][<key>])
        :type extra_args_for_edge: :class:`dict`

        :return: True if edge was added successfully
        :rtype: :class:`bool`
        """
        p = conversions.Point_2_to_Point_d(p)
        q = conversions.Point_2_to_Point_d(q)

        if check_if_valid:
            if not self.is_edge_valid(p, q) or \
               (not self.graph.has_node(p) and not self.is_point_valid(p)) or \
               (not self.graph.has_node(q) and not self.is_point_valid(q)):
                return False

        if not self.graph.has_node(q):
            self.add_point(p, check_if_valid=False)
        if not self.graph.has_node(q):
            self.add_point(q, check_if_valid=False)

        self.graph.add_edge(p, q, weight=(weight or self.metric.dist(p, q).to_double()), **extra_args_for_edge)
        return True

    @property
    def points(self):
        """
        Return a list of all landmarks (points) in the roadmap

        :return: list of landmarks
        :rtype: List[<:class:`~discopygal.bindings.Point_d`>]
        """
        return self.graph.nodes

    @property
    def edges(self):
        """
        Return a list of all edges in the roadmap

        :return: list of edges
        """
        return self.graph.edges
