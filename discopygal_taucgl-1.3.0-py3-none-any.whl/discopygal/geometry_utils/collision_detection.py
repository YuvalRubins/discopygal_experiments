import math
from functools import lru_cache

from discopygal.geometry_utils.conversions import to_list
from discopygal.solvers_infra import Obstacle, ObstacleDisc, ObstaclePolygon, Robot, RobotDisc, RobotPolygon, RobotRod
from discopygal.solvers_infra.operations_counter import count_calls

from ..bindings import *
from . import transform

EPS = 0.001

class ObjectCollisionDetection(object):
    """
    A class object that handles collision detection of a single object with obstacles.
    The collision detector builds a CGAL arrangement representing the scene and allows to
    (quickly) query the arrangement for collisions.

    :param obstacles: list of obstacles
    :type obstacles: list<:class:`~discopygal.solvers_infra.Obstacle`>
    :param robot: robot for building the collision detection
    :type robot: :class:`~discopygal.solvers_infra.Robot`
    :param offset: offset for rod edge collision detection
    :type offset: :class:`~discopygal.bindings.FT`
    """
    def __init__(self, obstaclces, robot, offset=FT(0.05)):
        self.obstacles = obstaclces
        self.robot = robot

        self.cspace = None
        self.point_location = None
        self.build_cspace()

        # Specific ad-hoc behaviour for rod robot
        self.offset = offset
        if type(self.robot) is RobotRod:
            self.is_point_valid = self.is_point_valid_rod
            self.is_edge_valid = self.is_edge_valid_rod

    @count_calls()
    def is_point_valid(self, point):
        """
        Check if a point is valid (i.e. not colliding with anything).

        :param point: point to check
        :type point: :class:`~discopygal.bindings.Point_2`

        :return: False if point lies in the interior of an obstacle
        :rtype: :class:`bool`
        """
        point = TPoint(point.x(), point.y()) # convert to traits point
        obj = self.point_location.locate(point)
        if type(obj) is Face:
            if obj.data() > 0:
                return False
        return True

    def is_point_valid_rod(self, point):
        """
        Check if (rod) point and rotation are valid (i.e., not colliding with anything).

        :param point: point to check: (point, angle)
        :type point: :class: (`~discopygal.bindings.Point_2`, `~discopygal.bindings.FT`)

        :return: False if point lies in the interior of an obstacle
        :rtype: :class:`bool`
        """
        # Convert rod to Segment_2
        r0 = Vector_2(self.robot.length, FT(0))
        p = point[0]
        at = Aff_transformation_2(Rotation(), FT(math.sin(point[1].to_double())),
                                        FT(math.cos(point[1].to_double())), FT(1))
        p0  = p + at.transform(r0)
        segment = Segment_2(p, p0)

        # Zone the rod withing obstacles (which are unexpanded)
        res = Aos2.zone(self.cspace, X_monotone_curve_2(segment.source(), segment.target()), self.point_location)
        for obj in res:
            if type(obj) == Face:
                if obj.data() > 0:
                    return False
        return True


    @count_calls()
    @lru_cache(maxsize=None)
    def is_edge_valid(self, edge):
        """
        Check if a edge (start point with angle to end point with angle) is valid (i.e. not colliding with anything).

        :param edge: edge to check
        :type edge: :class:`~discopygal.bindings.Segment_2`

        :return: False if edge intersects with the interior of an obstacle
        :rtype: :class:`bool`
        """
        if edge.is_degenerate():
            return True
        res = Aos2.zone(self.cspace, X_monotone_curve_2(edge.source(), edge.target()), self.point_location)
        for obj in res:
            if type(obj) == Face:
                if obj.data() > 0:
                    return False
        return True

    def is_edge_valid_rod(self, edge, clockwise):
        """
        Check if a edge is valid (i.e. not colliding with anything).

        :param edge: edge to check, as an 2D edge segment, and pair of angles start to end.
                    The structure is: (segment, start_angle, end_angle)
        :type edge: (:class:`~discopygal.bindings.Segment_2`, :class:`~discopygal.bindings.FT`, :class:`~discopygal.bindings.FT`)

        :param clockwise: is the motion from start to end is clockwise or not
        :type clockwise: :class:`bool`

        :return: False if edge intersects with the interior of an obstacle
        :rtype: :class:`bool`
        """
        x1 = edge[0].source().x().to_double()
        y1 = edge[0].source().y().to_double()
        a1 = edge[1].to_double()

        x2 = edge[0].target().x().to_double()
        y2 = edge[0].target().y().to_double()
        a2 = edge[2].to_double()

        if (not clockwise and a2 < a1):
            a1 = a1 - 2 * math.pi
        if (clockwise and a2 > a1):
            a1 = a1 + 2 * math.pi

        dx = x2 - x1
        dy = y2 - y1
        da = abs(a2 - a1)

        sample_count = int(
            (math.sqrt(dx ** 2 + dy ** 2) + da * (self.robot.length.to_double() + self.offset.to_double())) / (
                2 * self.offset.to_double()) + 1)

        for i in range(sample_count + 1):
            alpha = (sample_count - i) / sample_count
            beta = i / sample_count
            x = alpha * x1 + beta * x2
            y = alpha * y1 + beta * y2
            a = alpha * a1 + beta * a2
            point = (Point_2(FT(x), FT(y)), FT(a))
            if not self.is_point_valid_rod(point):
                return False
        return True

    def build_cspace(self):
        """
        Build the Cspace arrangement
        """
        self.cspace = Arrangement_2()
        ubf = self.cspace.unbounded_face()
        ubf.set_data(0)
        if len(self.obstacles) == 0:
            # If not obstacles then the cmap is empty
            self.point_location = Arr_trapezoid_ric_point_location(self.cspace)
            return

        # Overlay single object arrangements
        traits = Arr_overlay_function_traits(lambda x, y: x+y)
        arrangements = [self.cspace]
        for obstacle in self.obstacles:
            arr_obstacle = self.expanded_obstacle_arrangement(obstacle)
            arrangements.append(arr_obstacle)

        for i in range(len(arrangements) - 1):
            res = Arrangement_2()
            Aos2.overlay(arrangements[i], arrangements[i+1], res, traits)
            # Aos2.overlay(arrangements[i], arrangements[i+1], res)
            self.clean_redundant_halfedges(res)
            arrangements[i+1] = res

        self.cspace = arrangements[-1]

        # Also build the point location
        self.point_location = Arr_trapezoid_ric_point_location(self.cspace)


    def clean_redundant_halfedges(self, arr):
        """
        Given an arrangement, clear any halfedge that its both incident faces are nonfree.

        :param arr: arrangement to clean
        :type arr: :class:`~discopygal.bindings.Arrangement_2`
        """
        halfedges_to_remove = []
        for halfedge in arr.edges():
            if halfedge.face().data() > 0 and halfedge.twin().face().data() > 0:
                halfedges_to_remove.append(halfedge)
        for halfedge in halfedges_to_remove:
            Aos2.remove_edge(arr, halfedge)



    def expanded_obstacle_arrangement(self, obstacle):
        """
        Given a robot shape and the current obstacle, generate an arrangement
        that contains the (single) expanded obstacle

        :param obstacle: obstacle to expand
        :type obstacle: :class:`~discopygal.solvers_infra.Obstacle`

        :return: arrangement with expanded obstacle
        :rtype: :class:`~discopygal.bindings.Arrangement_2`
        """
        arr = Arrangement_2()

        if type(self.robot) is RobotDisc:
            # Handle the disc robot case
            if type(obstacle) is ObstaclePolygon:
                ms = Ms2.approximated_offset_2(obstacle.poly, FT(self.robot.radius), EPS)
                curves_iter = ms.outer_boundary().curves()
                curves = list([curve for curve in curves_iter])
                Aos2.insert(arr, curves)
            elif type(obstacle) is ObstacleDisc:
                expanded_radius = obstacle.radius + self.robot.radius
                circle = Circle_2(obstacle.location, expanded_radius*expanded_radius, Ker.CLOCKWISE)
                Aos2.insert(arr, Curve_2(circle))

        elif type(self.robot) is RobotPolygon:
            minus_robot = Polygon_2(
                [Point_2(-p.x(), -p.y()) for p in self.robot.poly.vertices()]
            )
            if minus_robot.is_clockwise_oriented():
                minus_robot.reverse_orientation()
            if type(obstacle) is ObstaclePolygon:
                if obstacle.poly.is_clockwise_oriented():
                    obstacle.poly.reverse_orientation()
                ms = Ms2.minkowski_sum_2(obstacle.poly, minus_robot)
                Aos2.insert(arr, [Curve_2(edge) for edge in to_list(ms.outer_boundary().edges())])
                for hole in ms.holes():
                    Aos2.insert(arr, [Curve_2(edge) for edge in hole.edges()])

            if type(obstacle) is ObstacleDisc:
                # Shift the minus robot to the disc location and then expand
                minus_robot = transform.offset_polygon(minus_robot, obstacle.location)
                ms = Ms2.approximated_offset_2(minus_robot, obstacle.radius, EPS)
                curves_iter = ms.outer_boundary().curves()
                curves = list([curve for curve in curves_iter])
                Aos2.insert(arr, curves)

        elif type(self.robot) is RobotRod:
            if type(obstacle) is ObstaclePolygon:
                curves = list([Curve_2(edge) for edge in obstacle.poly.edges()])
                Aos2.insert(arr, curves)
            elif type(obstacle) is ObstacleDisc:
                circle = Circle_2(obstacle.location, obstacle.radius*obstacle.radius, Ker.CLOCKWISE)
                Aos2.insert(arr, Curve_2(circle))

        # Set unbounded face and holes as free, and the polygon as occupied
        ubf = arr.unbounded_face()
        ubf.set_data(0)
        invalid_face = next(next(ubf.inner_ccbs())).twin().face()
        invalid_face.set_data(1)
        for ccb in invalid_face.inner_ccbs():
            # Set holes as free
            valid_face = next(ccb).twin().face()
            valid_face.set_data(0)
        return arr


@count_calls()
def collide_two_robots(robot1, edge1, robot2, edge2):
    """
    Get two robots and an edge of their movement, and check if at any point
    during their movement they intersect

    :param robot1: first robot
    :type robot1: :class:`~discopygal.solvers_infra.Robot`
    :param edge1: first robot edge motion
    :type edge1: :class:`~discopygal.bindings.Segment_2`
    :param robot2: second robot
    :type robot2: :class:`~discopygal.solvers_infra.Robot`
    :param edge2: second robot edge motion
    :type edge2: :class:`~discopygal.bindings.Segment_2`

    :return: True if robots collide during motion
    :rtype: bool
    """
    if type(robot1) is RobotRod or type(robot2) is RobotRod:
        raise Exception("Rod robot not yet implemented")

    # Without loss of generality, assume robot 1 is expanded and lies in the origin
    # and that robot 2 is a point and the only one that is moving
    arr = Arrangement_2()

    if type(robot1) is RobotDisc and type(robot2) is RobotDisc:
        ms_radius = robot1.radius + robot2.radius
        ms_radius_squared = ms_radius * ms_radius
        circle = Circle_2(Point_2(FT(0), FT(0)), ms_radius_squared, Ker.CLOCKWISE)
        Aos2.insert(arr, Curve_2(circle))
    elif type(robot1) is RobotPolygon and type(robot2) is RobotPolygon:
        minus_robot2 = Polygon_2(
            [Point_2(-p.x(), -p.y()) for p in robot2.poly.vertices()]
        )

        if minus_robot2.is_clockwise_oriented():
            minus_robot2.reverse_orientation()
        if robot1.poly.is_clockwise_oriented():
            robot1.poly.reverse_orientation()
        ms = Ms2.minkowski_sum_2(robot1.poly, minus_robot2)
        Aos2.insert(arr, [Curve_2(edge) for edge in to_list(ms.outer_boundary().edges())])
        for hole in ms.holes():
            Aos2.insert(arr, [Curve_2(edge) for edge in hole.edges()])
    elif type(robot1) is RobotPolygon and type(robot2) is RobotDisc:
        ms = Ms2.approximated_offset_2(robot1.poly, robot2.radius, EPS)
        curves_iter = ms.outer_boundary().curves()
        curves = list([curve for curve in curves_iter])
        Aos2.insert(arr, curves)
    elif type(robot1) is RobotDisc and type(robot2) is RobotPolygon:
        ms = Ms2.approximated_offset_2(robot2.poly, robot1.radius, EPS)
        curves_iter = ms.outer_boundary().curves()
        curves = list([curve for curve in curves_iter])
        Aos2.insert(arr, curves)
    else:
        raise Exception("Not implemented")


    # Subtract robot1's motion from the motion of robot2
    edge_start = Point_2(
        edge2.source().x() - edge1.source().x(),
        edge2.source().y() - edge1.source().y()
    )
    edge_end = Point_2(
        edge2.target().x() - edge1.target().x(),
        edge2.target().y() - edge1.target().y()
    )
    edge = X_monotone_curve_2(edge_start, edge_end)

    point_location = Arr_trapezoid_ric_point_location(arr)

    if edge.source() != edge.target():
        res = Aos2.zone(arr, edge, point_location)
        for obj in res:
            if type(obj) == Face:
                if not obj.is_unbounded():
                    # If we intersect with the interior of a face
                    return True
        return False
    else:
        ##################
        # Edge case - both robot don't move but they already intersect!
        ##################

        point = TPoint(edge.source().x(), edge.source().y())
        obj = point_location.locate(point)
        if type(obj) is Face:
            if not obj.is_unbounded():
                # Only if we intersect with the interior of the robot
                return True
        return False


def collide_disc_with_polygon(center, r, polygon):
    """
    Collide (center ,r) disc with CGAL polygon

    :param center: center of the disc to intersect
    :type center: :class:`~discopygal.bindings.Point_2`
    :param r: radius of disc to intersect
    :type r: :class:`~discopygal.bindings.FT`
    :param polygon: polygon to intersect with
    :type polygon: :class:`~discopygal.bindings.Polygon_2`

    :return: :attr:`True` if disc and polygon intersect
    :rtype: :class:`bool`
    """
    # Expand the polygon in the radius and convert to arrangement
    minkowski_sum = Ms2.approximated_offset_2(polygon, FT(r), EPS)
    arr = Arrangement_2()
    curves_iter = minkowski_sum.outer_boundary().curves()
    curves = list([curve for curve in curves_iter])
    Aos2.insert(arr, curves)

    # Set unbounded face and holes as free, and the polygon as occupied
    ubf = arr.unbounded_face()
    ubf.set_data(0)
    invalid_face = next(next(ubf.inner_ccbs())).twin().face()
    invalid_face.set_data(1)
    for ccb in invalid_face.inner_ccbs():
        # Set holes as free
        valid_face = next(ccb).twin().face()
        valid_face.set_data(0)
    point_location = Arr_trapezoid_ric_point_location(arr)

    # Check if the point is free
    point = TPoint(center.x(), center.y()) # convert to Aos2 point (instead of kernel)
    obj = point_location.locate(point)
    if type(obj) is Face:
        if obj.data() > 0:
            return True
        return False

    # If we intersect with something other than a face then we intersect, hence True
    return True


def collide_disc_with_disc(center1, r1, center2, r2):
    """
    Collide (center ,r) disc with (center ,r) disc

    :param center1: center of the first disc to intersect
    :type center1: :class:`~discopygal.bindings.Point_2`
    :param r1: radius of first disc to intersect
    :type r1: :class:`~discopygal.bindings.FT`
    :param center2: center of the second disc to intersect
    :type center2: :class:`~discopygal.bindings.Point_2`
    :param r2: radius of second disc to intersect
    :type r2: :class:`~discopygal.bindings.FT`

    :return: :attr:`True` if discs intersect
    :rtype: :class:`bool`
    """
    # Build arrangement containins the (expanded) disc
    arr = Arrangement_2()
    expanded_radius = r1 + r2
    circle = Circle_2(center1, expanded_radius*expanded_radius, Ker.CLOCKWISE)
    Aos2.insert(arr, Curve_2(circle))
    point_location = Arr_trapezoid_ric_point_location(arr)

    # Check if the point is free
    point = TPoint(center2.x(), center2.y()) # convert to Aos2 point (instead of kernel)
    obj = point_location.locate(point)
    if type(obj) is Face:
        if not obj.is_unbounded():
            return True
        return False

    # If we intersect with something other than a face then we intersect, hence True
    return True


def collide_disc_with_rod(center, r, x, y, a, length):
    """
    Collide (center, r) disc with (x, y, a, length) rod

    :param center: center of the disc to intersect
    :type center: :class:`Ker.Point_2`
    :param r: radius of disc to intersect
    :type r: :class:`~discopygal.bindings.FT`
    :param x: x of rod
    :type x: :class:`~discopygal.bindings.FT`
    :param y: y of rod
    :type y: :class:`~discopygal.bindings.FT`
    :param a: angle of rod
    :type a: :class:`~discopygal.bindings.FT`
    :param length: length of rod
    :type length: :class:`~discopygal.bindings.FT`

    :return: :attr:`True` if disc and segment intersect
    :rtype: :class:`bool`
    """
    # Build arrangement containins the disc
    arr = Arrangement_2()
    circle = Circle_2(center, r*r, Ker.CLOCKWISE)
    Aos2.insert(arr, Curve_2(circle))
    point_location = Arr_trapezoid_ric_point_location(arr)

    # Convert rod to Segment_2
    r0 = Vector_2(length, FT(0))
    p = Point_2(x, y)
    at = Aff_transformation_2(Rotation(), FT(math.sin(a.to_double())),
                                    FT(math.cos(a.to_double())), FT(1))
    p0  = p + at.transform(r0)
    segment = Segment_2(p, p0)

    # Check if segment intersects circle
    res = Aos2.zone(arr, X_monotone_curve_2(segment.source(), segment.target()), point_location)
    for obj in res:
        if type(obj) == Face:
            if not obj.is_unbounded():
                return True
        else:
            # If we intersect with something other than a face then we intersect, hence True
            return True
    return False