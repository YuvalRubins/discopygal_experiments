import math
from collections import namedtuple

from ..bindings import FT, Vector_2, Aff_transformation_2, Rotation
from .transform import offset_polygon
from ..solvers_infra import Scene, RobotDisc, RobotPolygon, RobotRod, ObstacleDisc, ObstaclePolygon

BoundingBox = namedtuple("BoundingBox", "min_x max_x min_y max_y")

def calc_scene_bounding_box(scene: Scene):
    """
    Get a DiscoPygal scene and compute its bounding box.
    The bounding box is computed as the smallest axis-aligned box
    that contains all the obstacles and robots.

    :param scene: scene
    :type scene: :class:`~discopygal.solvers_infra.Scene`

    :return: min_x, max_x, min_y, max_y [bounds of the scene]
    :rtype: (:class:`~discopygal.bindings.FT`, :class:`~discopygal.bindings.FT`, :class:`~discopygal.bindings.FT`, :class:`~discopygal.bindings.FT`)
    """
    X = []
    Y = []

    for obstacle in scene.obstacles:
        if type(obstacle) is ObstaclePolygon:
            for point in obstacle.poly.vertices():
                X.append(point.x())
                Y.append(point.y())
        elif type(obstacle) is ObstacleDisc:
            X.append(obstacle.location.x() - obstacle.radius)
            X.append(obstacle.location.x() + obstacle.radius)
            Y.append(obstacle.location.y() - obstacle.radius)
            Y.append(obstacle.location.y() + obstacle.radius)

    for robot in scene.robots:
        if type(robot) is RobotPolygon:
            poly1 = offset_polygon(robot.poly, robot.start)
            poly2 = offset_polygon(robot.poly, robot.end)
            for point in poly1.vertices():
                X.append(point.x())
                Y.append(point.y())
            for point in poly2.vertices():
                X.append(point.x())
                Y.append(point.y())
        elif type(robot) is RobotDisc:
            X.append(robot.start.x() - robot.radius)
            X.append(robot.start.x() + robot.radius)
            Y.append(robot.start.y() - robot.radius)
            Y.append(robot.start.y() + robot.radius)
            X.append(robot.end.x() - robot.radius)
            X.append(robot.end.x() + robot.radius)
            Y.append(robot.end.y() - robot.radius)
            Y.append(robot.end.y() + robot.radius)
        elif type(robot) is RobotRod:
            # Add both endpoints of start rod
            r0 = Vector_2(robot.length, FT(0))
            p = robot.start[0]
            at = Aff_transformation_2(Rotation(), FT((math.sin(robot.start[1].to_double()))),
                                            FT((math.cos(robot.start[1].to_double()))), FT(1))
            p0  = p + at.transform(r0)
            X.append(p.x())
            X.append(p0.x())
            Y.append(p.y())
            Y.append(p0.y())
            # Add both endpoints of end rod
            r0 = Vector_2(robot.length, FT(0))
            p = robot.end[0]
            at = Aff_transformation_2(Rotation(), FT((math.sin(robot.end[1].to_double()))),
                                            FT((math.cos(robot.end[1].to_double()))), FT(1))
            p0  = p + at.transform(r0)
            X.append(p.x())
            X.append(p0.x())
            Y.append(p.y())
            Y.append(p0.y())

    min_x = min(X)
    max_x = max(X)
    min_y = min(Y)
    max_y = max(Y)

    return BoundingBox(min_x, max_x, min_y, max_y)
