from ..bindings import FT, Point_2, Point_d, Segment_2, Polygon_2
from ..solvers_infra.operations_counter import count_calls

def Polygon_2_to_array_of_points(poly):
    """
    Convert a CGAL Polygon_2 to list of points

    :param poly: polygon to convert
    :type poly: :class:`~discopygal.bindings.Polygon_2`

    :return: list of tuples of (x,y) points
    :rtype: list<(:class:`float`, :class:`float`)>
    """
    return [(p.x().to_double(), p.y().to_double()) for p in poly.vertices()]


def array_of_points_to_Polygon_2(poly):
    """
    Convert a list of points to a CGAL Polygon_2

    :param poly: list of points to convert
    :type poly: list<(:class:`float, :class:`float`)>

    :return: CGAL polygon
    :rtype: :class:~discopygal.bindings.Polygon_2`
    """
    points = []
    for p in poly:
        new_p = Point_2(p[0], p[1])
        if new_p not in points:
            points.append(new_p)
    poly = Polygon_2(points)
    if poly.is_clockwise_oriented(): poly.reverse_orientation()
    return poly


def float_to_FT(f):
    """
    Convert python float value to CGAL Field Type (FT)

    :param f: float to convert
    :type f: :class:`float`

    :return: CGAL FT
    :rtype: :class:`~discopygal.bindings.FT`
    """
    return FT(f)


def FT_to_float(f):
    """
    Convert CGAL Field Type (FT) to python float

    :param f: float to convert
    :type f: :class:`~discopygal.bindings.FT`

    :return: python float
    :rtype: :class:`float`
    """
    return f.to_double()


def xy_to_Point_2(x, y):
    """
    Convert (x,y) values to CGAL Point_2

    :param x: x value
    :type x: :class:`float`
    :param y: y value
    :type y: :class:`float`

    :return: CGAL Point_2 point from (x,y)
    :rtype: :class:`~discopygal.bindings.Point_2`
    """
    return Point_2(FT(x), FT(y))


def Point_2_to_xy(point):
    """
    Convert CGAL Point_2 to (x,y) values

    :param point: point to convert
    :type point: :class:`~discopygal.bindings.Point_2`

    :return: x, y values of point
    :rtype: (:class:`float`, :class:`float`)
    """
    return point.x().to_double(), point.y().to_double()

@count_calls(lambda point_d: point_d.dimension() // 2)
def Point_d_to_Point_2_list(point_d):
    """
    | Convert a high-dimensional Point_d to a list of Point_2's
    | (We assume that d%2==0)

    :param point_d: point to convert
    :type point_d: :class:`~discopygal.bindings.Point_d`

    :return: list of Point_2's
    :type: list<:class:`~discopygal.bindings.Point_2`>
    """
    d = point_d.dimension()
    assert(d % 2 == 0)
    res = []
    for i in range(d//2):
        res.append(Point_2(point_d[2*i], point_d[2*i+1]))
    return res


@count_calls(lambda point_2_list: len(point_2_list))
def Point_2_list_to_Point_d(point_2_list):
    """
    Convert a list of Point_2's to a high-dimensional Point_d

    :param point_2_list: list of Point_2's
    :type point_2_list: list<:class:`~discopygal.bindings.Point_2`>

    :return: high dimensional point
    :rtype: :class:`~discopygal.bindings.Point_d`
    """
    d = 2 * len(point_2_list)
    coords = []
    for point in point_2_list:
        if type(point) == tuple:
            point = point[0]
        coords.append(point.x().to_double())
        coords.append(point.y().to_double())
    return Point_d(d, coords)


@count_calls(lambda point_d, k: point_d.dimension() // k)
def Point_d_to_Point_k_list(point_d, k):
    """
    | Convert a high-dimensional Point_d to a list of Point_k's
    | (We assume that d%k==0)

    :param point_d: point to convert
    :type point_d: :class:`~discopygal.bindings.Point_d`

    :param k: dimension of each point in the list
    :type k: :class:`int`

    :return: list of Point_k's
    :type: list<:class:`~discopygal.bindings.Point_d`>
    """
    d = point_d.dimension()
    assert(d % k == 0)
    res = []
    for i in range(d//k):
        res.append(Point_d(k, list(point_d.cartesians())[i*k: i*k + k]))
    return res


@count_calls(lambda point_k_list: len(point_k_list))
def Point_k_list_to_Point_d(point_k_list):
    """
    Convert a list of Point_k's to a single high-dimensional Point_d (sum of all dimensions)

    :param point_k_list: list of Point_d's
    :type point_k_list: list<:class:`~discopygal.bindings.Point_d`>

    :return: high dimensional point
    :rtype: :class:`~discopygal.bindings.Point_d`
    """
    coords = []
    for point in point_k_list:
        if type(point) == tuple:
            point = point[0]
        coords.extend(list(point.cartesians()))
    return Point_d(len(coords), coords)


@count_calls()
def Point_2_to_Point_d(point: Point_2):
    if isinstance(point, Point_d):
        return point
    return Point_d(2, [point[0].to_double(), point[1].to_double()])


@count_calls()
def Point_d_to_Point_2(point: Point_d):
    if isinstance(point, Point_2):
        return point
    return Point_2(point[0], point[1])


def to_list(iterator):
    l = []
    while True:
        try:
            l.append(next(iterator))
        except StopIteration:
            break
    return l

def create_segment_2(p, q):
    p = Point_d_to_Point_2(p)
    q = Point_d_to_Point_2(q)
    return Segment_2(p, q)
