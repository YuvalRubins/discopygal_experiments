from ..bindings import *

def offset_polygon(polygon, offset):
    """
    Offset a CGAL Polygon_2 with a given CGAL Point_2 x,y offset

    :param polygon: polygon to offset
    :type polygon: :class:`~discopygal.bindings.Polygon_2`
    :param offset: offset amount
    :type offset: :class:`~discopygal.bindings.Point_2`

    :return: new offseted polygon
    :rtype: :class:`~discopygal.bindings.Polygon_2`
    """
    new_points = []
    for point in polygon.vertices():
        new_points.append(Point_2(point.x() + offset.x(), point.y() + offset.y()))
    return Polygon_2(new_points)