import os
import sys
import time
import itertools
from collections import namedtuple
import pandas as pd
import threading
import ctypes
from datetime import datetime


from discopygal.solvers_infra import Scene, PathCollection
from discopygal.solvers_infra.verify_paths import verify_paths

RESULTS_DIR_PREFIX = "results__"
DEFAULT_TIME_LIMIT = None  # No time limit
DEFAULT_REPETITIONS = 10

#: A type that defines a scenario - All the info required to run a solver on a scene.
#:
#: .. py:attribute:: solver_class
#:    :no-index:
#:
#:    | Solver class to use.
#:    | Required parameter
#:
#: .. py:attribute:: scene_path
#:    :no-index:
#:
#:    | Path to json scene file to use.
#:    | Required parameter
#:
#: .. py:attribute:: parameters
#:    :no-index:
#:
#:    | Parameters to pass to solver as dict: {<parameter_name>: <parameter_value>}.
#:    | For parameters that won't be explicitly specified, their default value as defined in the solver will be used.
#:    | Optional - default is {}, e.g. the default args of the solver
#:
#: .. py:attribute:: time_limit
#:    :no-index:
#:
#:    | Max time to allow the solver to run (in seconds).
#:    | If solver exceeds this time it stops and regarded as it failed.
#:    | Optional - default is None - e.g. no time limit
#:
#: .. py:attribute:: repetitions
#:    :no-index:
#:
#:    | Number of times to repeat this scenario.
#:    | Results of the scenario are average of all there repetitions.
#:    | Optional - default is 10.
Scenario = namedtuple("Scenario", ["solver_class", "scene_path", "parameters", "time_limit", "repetitions"],
                      defaults=[{}, DEFAULT_TIME_LIMIT, DEFAULT_REPETITIONS])


class TimeoutException(Exception):
    pass


def get_latest_dir(root_dir):
    def check_format(name):
        if name.startswith(RESULTS_DIR_PREFIX):
            try:
                datetime.strptime(name[len(RESULTS_DIR_PREFIX):], '%d_%m_%y__%H_%M_%S')
                return True
            except ValueError:
                pass
        return False

    files_names = [f[len(RESULTS_DIR_PREFIX):] for f in os.listdir(root_dir) if check_format(f)]
    files_names.sort(key=lambda x: datetime.strptime(x, '%d_%m_%y__%H_%M_%S'), reverse=True)
    return f"{root_dir}/{RESULTS_DIR_PREFIX}{files_names[0]}"


def kill_thread(thread):
    ctypes.pythonapi.PyThreadState_SetAsyncExc(thread.ident, ctypes.py_object(SystemExit))


def run_with_time_limit(timeout, func, *args, **kwargs):
    result = [None, None]

    def thread_target():
        result[0], result[1] = func(*args, **kwargs)

    timeout = timeout or float("inf")
    solver_thread = threading.Thread(target=thread_target, daemon=True)
    solver_thread.start()
    start_time = time.time()
    try:
        while time.time() - start_time < timeout:
            if not solver_thread.is_alive():
                break
            time.sleep(1)
        else:
            raise TimeoutException()

    except (KeyboardInterrupt, TimeoutException):
        kill_thread(solver_thread)
        raise

    kill_thread(solver_thread)

    return result[0], result[1], time.time() - start_time


def run_solver(solver, scene):
    try:
        paths = solver.solve(scene)
    except Exception:
        paths = PathCollection()
    return paths, solver


def run_single_scenario(scenario: Scenario):
    solver = scenario.solver_class.init_solver(**scenario.parameters)
    scene = Scene.from_file(scenario.scene_path)
    try:
        if scenario.time_limit:
            path_collection, solver, calc_time = run_with_time_limit(scenario.time_limit, run_solver, solver, scene)
        else:
            start_time = time.time()
            path_collection, solver = run_solver(solver, scene)
            calc_time = time.time() - start_time
    except TimeoutException:
        path_collection = PathCollection()
        calc_time = float("inf")

    result, reason = verify_paths(scene, path_collection)
    if not path_collection.is_empty():
        assert result
        assert reason == ""

    return path_collection, solver, calc_time


def repeat_scenario(scenario, result_handlers):
    scenario_results = pd.DataFrame(columns=result_handlers.keys())
    print()
    for i in range(scenario.repetitions):
        print("\033[F" + "." * i)
        paths, solver, calc_time = run_single_scenario(scenario)
        result_handlers["calc_time"] = lambda _, __: calc_time  # Set correct handler for calc time
        scenario_results.loc[len(scenario_results)] = [
            float(handler(paths, solver)) for handler in result_handlers.values()
        ]

        del paths
        del solver

    return scenario_results


def run_scenarios(scenarios, results_root_path, extra_result_handlers=None, resume_latest=False):
    """
    Run given scenarios and outputs the results to given file as csv

    :parameter scenarios: List of scenarios to run
    :type scenarios: [:class:`Scenario`]

    :parameter results_root_path: Output root dir for the results
    :type results_root_path: :class:`str`

    :parameter extra_result_handlers: | More custom handlers that can run on the result of each solution and perform further calculations.
                                      | A dict of {"<field_name>": handler} where handler is a function that receives the path_collection and solver object and returns a number.
    :type results_root_path: :class:`dict`

    :parameter resume_latest: | Resume the last experiment in result_root_path (according to the date in the name of the dir).
                              | All parameters (scenarios, extra_result_handlers) must be the same as the original experiment.
                              | If no experiments in result_root_path this parameter is ignored.
    :type resume_latest: :class:`bool`
    """
    result_handlers = {"total_path_length": lambda paths, _: paths.get_paths_length_sum() if not paths.is_empty() else float("Nan"),
                       "makespan": lambda paths, _: paths.get_make_span() if not paths.is_empty() else float("Nan"),
                       "calc_time": None}
    if extra_result_handlers:
        result_handlers.update(extra_result_handlers)

    results = pd.DataFrame(columns=[
            "scenario_index",
            # input
            "solver_class", "parameters", "full_parameters", "scene_path", "time_limit", "repetitions",
            # output
            "successful_repetitions"] + \
            list(map(lambda x: "_".join(x),
                     itertools.product(result_handlers.keys(), ["avg", "std"])))
            )

    print(f"Running {len(scenarios)} scenarios, {sum(scenario.repetitions for scenario in scenarios)} experiments")

    if resume_latest and os.path.exists(results_root_path):
        results_path = get_latest_dir(results_root_path)
        results = pd.read_csv(results_path + "/results.csv")
        start_index = len(results)
        scenarios = scenarios[start_index:]
        print(f"Resuming from scenario: {start_index}")
    else:
        start_index = 0
        results_path = f"{results_root_path}/{RESULTS_DIR_PREFIX}{datetime.now().strftime('%d_%m_%y__%H_%M_%S')}"
        os.makedirs(results_path)
    print(f"Results at path: {results_path}")

    for i, scenario in enumerate(scenarios):
        scenario_index = i + start_index
        print(f"Running scenario {scenario_index}: {scenario.solver_class.__name__}({scenario.parameters}) on {scenario.scene_path} ")
        scenario_results = repeat_scenario(scenario, result_handlers)
        scenario_results.to_csv(f"{results_path}/scenario_{scenario_index}.csv")

        results.loc[len(results)] = [scenario_index,

                                     # input
                                     scenario.solver_class.__name__,
                                     scenario.parameters,
                                     scenario.solver_class.init_solver(**scenario.parameters).return_arguments(),
                                     scenario.scene_path,
                                     scenario.time_limit,
                                     scenario.repetitions,

                                     # output (results)
                                     scenario_results["total_path_length"].count()] + \
                                    [scenario_results[name].mean() if i == "avg" else
                                     scenario_results[name].std() for
                                     name, i in itertools.product(result_handlers.keys(), ["avg", "std"])]

        print(f"\nScenario {scenario_index} results: total_path_length={results.loc[scenario_index, 'total_path_length_avg']:.4f} \
calc_time={results.loc[scenario_index, 'calc_time_avg']:.4f}")
        results.to_csv(f"{results_path}/results.csv", index=False)
