import os
import sys
import shutil
import importlib
import pandas as pd
from discopygal.experiments.scenarios_runner import run_scenarios, get_latest_dir

USAGE_MESSAGE = """
Usage:
For running full new experiment:    <result_root_dir>, <scenarios_file>
For resuming last full experiment:  <result_root_dir>, <scenarios_file>, resume
For running single chunk:           <result_root_dir>, <scenarios_file>, <number_of_chunks>, <chunk_number>
For merging all chunk results:      <result_root_dir>, <scenarios_file>, <number_of_chunks>, end
"""


# Args: result_root_dir, scenarios_file,                                # To run all scenarios in new experiment
# Args: result_root_dir, scenarios_file, resume                         # To resume last experiment (all scenarios)
# Args: result_root_dir, scenarios_file,                                # To resume from latest
# Args: result_root_dir, scenarios_file, number_of_chunks, chunk_number # To run chunk
# Args: result_root_dir, scenarios_file, number_of_chunks, end          # To create final dir


def main():
    args = sys.argv[1:]
    if not 2 <= len(args) <= 4:
        print(USAGE_MESSAGE)
        sys.exit(1)

    results_root_dir = args[0]
    scenarios_file = args[1]

    # Load scenarios
    sys.path.append(os.path.dirname(scenarios_file))
    scenarios_module_name = os.path.basename(scenarios_file).rstrip(".py")
    scenarios_module = importlib.import_module(scenarios_module_name)
    scenarios = getattr(scenarios_module, "SCENARIOS")
    extra_result_handlers = getattr(scenarios_module, "RESULT_HANDLERS", None)

    # Run full experiment
    if len(args) < 4:
        resume_latest = (len(args) == 3 and args[2] == "resume")
        print(f"Running full experiment from {scenarios_file} ({resume_latest=})")
        run_scenarios(scenarios, results_root_dir, extra_result_handlers, resume_latest)
    else:
        number_of_chunks = int(args[2])
        scenarios_per_chunk = int(len(scenarios) / number_of_chunks)
        assert scenarios_per_chunk > 0

        # Run single chunk
        if args[3] != "end":
            chunk = int(args[3])
            assert chunk < number_of_chunks
            print(f"Running {chunk=}, scenarios: {chunk * scenarios_per_chunk} to {(chunk+1) * scenarios_per_chunk - 1 } from file: {scenarios_file}")
            run_scenarios(scenarios[chunk * scenarios_per_chunk: (chunk+1) * scenarios_per_chunk], f"{results_root_dir}/chunk_{chunk}", extra_result_handlers)
            return

        # Merge all results at end
        print(f"Merging all results from {results_root_dir}")
        all_results_path = f"{results_root_dir}/all"
        chunk_dirs = os.listdir(results_root_dir)
        os.mkdir(all_results_path)

        results_per_chunk = []
        for chunk_name in chunk_dirs:
            assert chunk_name.startswith("chunk_")
            chunk_index = int(chunk_name.split('_')[1])
            chunk_dir = get_latest_dir(f"{results_root_dir}/{chunk_name}")
            print(f"Copying from {chunk_dir}")

            chunk_index_offset = scenarios_per_chunk * chunk_index
            chunk_results = pd.read_csv(f"{chunk_dir}/results.csv")
            chunk_results["scenario_index"] += chunk_index_offset
            results_per_chunk.append(chunk_results)
            for scenario_file in os.listdir(chunk_dir):
                if scenario_file.startswith("scenario_"):
                    scenario_index = int(scenario_file.split('.')[0].split('_')[1])
                    shutil.copy(f"{chunk_dir}/{scenario_file}", f"{all_results_path}/scenario_{chunk_index_offset + scenario_index}.csv")

        all_results = pd.concat(results_per_chunk)
        all_results = all_results.sort_values(by=["scenario_index"])
        all_results.to_csv(f"{all_results_path}/results.csv", index=False)


if __name__ == "__main__":
    main()
