import json
import numpy as np
import pandas as pd
from PyQt5 import QtCore

from ..gui import color
from ..geometry_utils import conversions
from ..bindings import FT
from ..solvers_infra.metrics import Metric, Metric_Euclidean

DEFAULT_ROBOT_COLOR_NAME = 'blue'
DEFAULT_OBSTACLE_COLOR = color.PREDEFINED_COLORS['lightGray']
DEFAULT_ROBOT_COLOR = color.PREDEFINED_COLORS[DEFAULT_ROBOT_COLOR_NAME]
DEFAULT_SELECT_COLOR = color.PREDEFINED_COLORS['green']
DEFAULT_SELECT_LINE_COLOR = color.PREDEFINED_COLORS['darkGreen']


def load_object_from_dict(d):
    """
    Load a seriallized object from a dict
    In order for this to work, the dict should have a "__class__" property,
    which is equal to the exact python name of the class

    :param d: dict describing an object
    :type d: :class:`dict`

    :return: the serialized object
    :rtype: :class:`object`
    """
    klass = globals()[d['__class__']]
    obj = klass.from_dict(d)
    return obj



class Robot(object):
    """
    Abstact class that represents the notion of a robot in a scene.
    Reference point is always the origin of the given geometry.

    :param start: The start location of the robot, as a CGAL point (unless stated otherwise)
    :type start: :class:`~discopygal.bindings.Point_2`
    :param end: The end location of the robot, as a CGAL point (unless stated otherwise)
    :type end: :class:`~discopygal.bindings.Point_2`
    :param data: Any metadata appended to the robot (could be None)
    :type data: :class:`object`
    """
    def __init__(self, start, end, data=None):
        self.start = start
        self.end = end
        self.data = data or {}

        if 'color' not in self.data or not self.data['color']:
            self.data['color'] = DEFAULT_ROBOT_COLOR_NAME

    def to_dict(self):
        """
        Convert current object to json dict

        :return: dict representing json export
        :rtype: :class:`dict`
        """
        return {
            '__class__': 'Robot',
            'start': conversions.Point_2_to_xy(self.start),
            'end': conversions.Point_2_to_xy(self.end),
            'data': self.data
        }

    @staticmethod
    def from_dict(d):
        """
        Load json dict to object

        :param d: dict representing json export
        :type d: :class:`dict`
        """
        return Robot(
            start=conversions.xy_to_Point_2(*d['start']),
            end = conversions.xy_to_Point_2(*d['end']),
            data = d['data']
        )


class RobotDisc(Robot):
    """
    A disc robot. Its geometry is defined by its radius.

    :param radius: The radius of the disc robot, as a CGAL field type
    :type radius: :class:`~discopygal.bindings.FT`
    :param start: The start location of the robot, as a CGAL point
    :type start: :class:`~discopygal.bindings.Point_2`
    :param end: The end location of the robot, as a CGAL point
    :type end: :class:`~discopygal.bindings.Point_2`
    :param data: Any metadata appended to the robot (could be None)
    :type data: :class:`object`
    """
    def __init__(self, radius, start, end, data=None):
        super().__init__(start, end, data)
        self.radius = radius

    def to_dict(self):
        """
        Convert current object to json dict

        :return: dict representing json export
        :rtype: :class:`dict`
        """
        return {
            '__class__': 'RobotDisc',
            'radius': conversions.FT_to_float(self.radius),
            'start': conversions.Point_2_to_xy(self.start),
            'end': conversions.Point_2_to_xy(self.end),
            'data': self.data
        }

    @staticmethod
    def from_dict(d):
        """
        Load json dict to object

        :param d: dict representing json export
        :type d: :class:`dict`
        """
        return RobotDisc(
            radius = conversions.float_to_FT(d['radius']),
            start = conversions.xy_to_Point_2(*d['start']),
            end = conversions.xy_to_Point_2(*d['end']),
            data = d['data']
        )


class RobotPolygon(Robot):
    """
    A polygonal robot. Its geometry is given as a CGAL 2D polygon.

    :param poly: The geometry of the robot, as a CGAL 2D Polygon
    :type poly: :class:`~discopygal.bindings.Polygon2`
    :param start: The start location of the robot, as a CGAL point
    :type start: :class:`~discopygal.bindings.Point_2`
    :param end: The end location of the robot, as a CGAL point
    :type end: :class:`~discopygal.bindings.Point_2`
    :param data: Any metadata appended to the robot (could be None)
    :type data: :class:`object`
    """
    def __init__(self, poly, start, end, data=None):
        super().__init__(start, end, data)
        self.poly = poly

    def to_dict(self):
        """
        Convert current object to json dict

        :return: dict representing json export
        :rtype: :class:`dict`
        """
        return {
            '__class__': 'RobotPolygon',
            'poly': conversions.Polygon_2_to_array_of_points(self.poly),
            'start': conversions.Point_2_to_xy(self.start),
            'end': conversions.Point_2_to_xy(self.end),
            'data': self.data
        }

    @staticmethod
    def from_dict(d):
        """
        Load json dict to object

        :param d: dict representing json export
        :type d: :class:`dict`
        """
        return RobotPolygon(
            poly = conversions.array_of_points_to_Polygon_2(d['poly']),
            start = conversions.xy_to_Point_2(*d['start']),
            end = conversions.xy_to_Point_2(*d['end']),
            data = d['data']
        )


class RobotRod(Robot):
    """
    A rod robot. Its geometry is defined by its length.

    :param length: The length of the rod, as a CGAL field type
    :type length: :class:`~discopygal.bindings.FT`
    :param start: The start location and angle of the robot, as a tuple of CGAL point and angle
    :type start: (:class:`~discopygal.bindings.Point_2`, :class:`~discopygal.bindings.FT`)
    :param end: The end location and angle of the robot, as a tuple of CGAL point and angle
    :type end: (:class:`~discopygal.bindings.Point_2`, :class:`~discopygal.bindings.FT`)
    :param data: Any metadata appended to the robot (could be None)
    :type data: :class:`object`
    """
    def __init__(self, length, start, end, data=None):
        super().__init__(start, end, data)
        self.length = length

    def to_dict(self):
        """
        Convert current object to json dict

        :return: dict representing json export
        :rtype: :class:`dict`
        """
        return {
            '__class__': 'RobotRod',
            'length': conversions.FT_to_float(self.length),
            'start': (conversions.Point_2_to_xy(self.start[0]), conversions.FT_to_float(self.start[1])),
            'end': (conversions.Point_2_to_xy(self.end[0]), conversions.FT_to_float(self.end[1])),
            'data': self.data
        }

    @staticmethod
    def from_dict(d):
        """
        Load json dict to object

        :param d: dict representing json export
        :type d: :class:`dict`
        """
        return RobotRod(
            length = conversions.float_to_FT(d['length']),
            start = (conversions.xy_to_Point_2(*d['start'][0]), conversions.float_to_FT(d['start'][1])),
            end = (conversions.xy_to_Point_2(*d['end'][0]), conversions.float_to_FT(d['end'][1])),
            data = d['data']
        )


class Obstacle(object):
    """
    Abstract class that represents the notion of an obstacle in the scene.
    The obstacle has some geometry.

    :param data: Any metadata appended to the obstacle (could be None)
    :type data: :class:`object`
    """
    def __init__(self, data):
        self.data = data or {}

    def to_dict(self):
        """
        Convert current object to json dict

        :return: dict representing json export
        :rtype: :class:`dict`
        """
        return {
            '__class__': 'Obstacle',
            'data': self.data
        }

    @staticmethod
    def from_dict(d):
        """
        Load json dict to object

        :param d: dict representing json export
        :type d: :class:`dict`
        """
        return Obstacle(
            data = d['data']
        )



class ObstacleDisc(Obstacle):
    """
    Disc obstacle in the scene. Its geometry is given as a location and radius.

    :param location: Disc obstacle location point, as a CGAL point
    :type location: :class:`~discopygal.bindings.Point_2`
    :param radius: Disc radius, as a CGAL field type
    :type radius: :class:`~discopygal.bindings.FT`
    """
    def __init__(self, location, radius, data=None):
        super().__init__(data)
        self.location = location
        self.radius = radius

    def to_dict(self):
        """
        Convert current object to json dict

        :return: dict representing json export
        :rtype: :class:`dict`
        """
        return {
            '__class__': 'ObstacleDisc',
            'location': conversions.Point_2_to_xy(self.location),
            'radius': conversions.FT_to_float(self.radius),
            'data': self.data
        }

    @staticmethod
    def from_dict(d):
        """
        Load json dict to object

        :param d: dict representing json export
        :type d: :class:`dict`
        """
        return ObstacleDisc(
            location = conversions.xy_to_Point_2(*d['location']),
            radius = conversions.float_to_FT(d['radius']),
            data = d['data']
        )


class ObstaclePolygon(Obstacle):
    """
    Polygon obstacle in the scene. Its geometry is given as a polygon.

    :param poly: Polygon obstacle geometry, as a CGAL polygon
    :type poly: :class:`~discopygal.bindings.Polygon2`
    """
    def __init__(self, poly, data=None):
        super().__init__(data)
        self.poly = poly

    def to_dict(self):
        """
        Convert current object to json dict

        :return: dict representing json export
        :rtype: :class:`dict`
        """
        return {
            '__class__': 'ObstaclePolygon',
            'poly': conversions.Polygon_2_to_array_of_points(self.poly),
            'data': self.data
        }

    @staticmethod
    def from_dict(d):
        """
        Load json dict to object

        :param d: dict representing json export
        :type d: :class:`dict`
        """
        return ObstaclePolygon(
            poly = conversions.array_of_points_to_Polygon_2(d['poly']),
            data = d['data']
        )


class Scene(object):
    """
    The notion of "scene" in DiscoPygal, which is the setting where we conduct motion planning.
    A scene has robots that can move inside it, and obstacles.
    Also the scene can have any metadata, saved as a dictionary.

    :param obstacles: list of obstacles
    :type obstacles: list<:class:`Obstacle`>
    :param robots: list of robots
    :type robots: list<:class:`Robot`>
    :param metadata: dict with metadata on the scene
    :type metadata: :class:`dict`
    """
    def __init__(self, obstacles=None, robots=None, metadata=None):
        self.obstacles = obstacles or []
        self.robots = robots or []
        self.metadata = metadata or {}

    def clear(self):
        self.robots.clear()
        self.obstacles.clear()

    def add_robot(self, robot):
        """
        Add a robot to the scene

        :param robot: Robot to add
        :type robot: :class:`Robot`
        """
        if robot not in self.robots:
            self.robots.append(robot)

    def remove_robot(self, robot):
        """
        Remove a robot from the scene

        :param robot: Robot to remove
        :type robot: :class:`Robot`
        """
        if robot in self.robots:
            self.robots.remove(robot)

    def add_obstacle(self, obstacle):
        """
        Add a obstacle to the scene

        :param obstacle: obstacle to add
        :type obstacle: :class:`Obstacle`
        """
        if obstacle not in self.obstacles:
            self.obstacles.append(obstacle)

    def remove_obstacle(self, obstacle):
        """
        Remove a obstacle from the scene

        :param obstacle: obstacle to remove
        :type obstacle: :class:`Obstacle`
        """
        if obstacle in self.obstacles:
            self.obstacles.remove(obstacle)

    def create_single_robot_scene(self, robot):
        """
        Create from the current a scene a new scene containing only the given robot.
        This means it creates a scene with the original obstacles and only the given robot

        :param robot: The only robot to set in the scene
        :type robot: :class:`~discopygal.solvers_infra.Robot`

        :return: The new created scene
        :rtype: :class:`~discopygal.solvers_infra.Scene`
        """
        new_robot = type(robot).from_dict(robot.to_dict())
        return Scene(obstacles=self.obstacles, robots=[new_robot])

    def to_dict(self):
        """
        Convert current object to json dict

        :return: dict representing json export
        :rtype: :class:`dict`
        """
        return {
            '__class__': 'Scene',
            'obstacles': [obstacle.to_dict() for obstacle in self.obstacles],
            'robots': [robot.to_dict() for robot in self.robots],
            'metadata': self.metadata
        }

    @staticmethod
    def from_dict(d):
        """
        Load json dict to object

        :param d: dict representing json export
        :type d: :class:`dict`

        :return: A scene object build from the given dict
        :rtype: :class:`Scene`
        """
        return Scene(
            obstacles=[load_object_from_dict(obstacle) for obstacle in d['obstacles']],
            robots=[load_object_from_dict(robot) for robot in d['robots']],
            metadata=d['metadata']
        )

    @staticmethod
    def from_file(scene_path):
        """
        Load scene from json file

        :param scene_path: Path to scene json file
        :type scene_path: :class:`str`

        :return: A scene object build from the given file
        :rtype: :class:`Scene`
        """
        with open(scene_path, 'r') as fp:
            scene = Scene.from_dict(json.load(fp))
        return scene

    def calc_max_robot_size(self):
        """
        Return the size of the largest robot in the scene
        For RobotDisc the is it's diameter
        For RobotRod the size is it's length
        """
        robots_sizes = []
        for robot in self.robots:
            if type(robot) is RobotDisc:
                robots_sizes.append(robot.radius * 2)
            elif type(robot) is RobotRod:
                robots_sizes.append(robot.length)
            elif type(robot) is RobotPolygon:
                # TODO: calc also size for RobotPolygon
                return FT(0)

        return max(robots_sizes)


class PathPoint(object):
    """
    A single point in the path (of some robot).
    Has a 2D location and additional data

    :param location: location of point
    :type location: :class:`~discopygal.bindings.Point_2`
    :param data: attached data to point
    :type data: :class:`dict`
    """
    def __init__(self, location, data=None):
        self.location = location
        self.data = data or {}

class Path(object):
    """
    Representation of the path a single robot does

    :param points: points along the path
    :type points: list<:class:`PathPoint`>
    """
    def __init__(self, points):
        self.points = points

    def calculate_length(self, metric: Metric):
        """
        Return the total length of the path (sum of length between each two points)

        :param metric: The metric to use for calculating the distance between two points
        :type metric: :class:`Metric`

        :return: The length of the path
        :rtype: :class:`FT`
        """
        length = FT(0)
        for i in range(len(self.points) - 1):
            length += metric.dist(self.points[i].location, self.points[i+1].location)
        return length

    @staticmethod
    def path_from_points(points):
        """
        Create a :class:`Path` object from points as :class:`~discopygal.bindings.Point_2` or :class:`~discopygal.bindings.Point_d` (not as :class:`PathPoint`)
        Converts each point to :class:`PathPoint` (with default constructor)

        :param points: List of points
        :type points: list<:class:`Point_2` or :class:`Point_d`>

        :return: :class:`Path` object
        :rtype: :class:`Path`
        """
        path_points = [PathPoint(point) for point in points]
        return Path(path_points)

    def get_points(self):
        return [point.location for point in self.points]


class PathCollection(object):
    """
    Collection of the paths of all the robots in the scene.
    This is the objects that is returned by a solver.

    :param paths: collection of paths
    :type paths: dict<:class:`Robot`, :class:`Path`>
    """
    def __init__(self, paths=None, metric=Metric_Euclidean):
        self.paths = paths or {}
        self.metric = metric

    def is_empty(self):
        return self.paths == {}

    def add_robot_path(self, robot, path):
        """
        Add a robot's path to the collection

        :param robot: the robot we add
        :type robot: :class:`Robot`
        :param path: robot's path
        :type path: :class:`Path`
        """
        self.paths[robot] = path

    def get_path_length(self, robot):
        if self.is_empty():
            return float("inf")

        return self.paths[robot].calculate_length(self.metric)

    def get_paths_length_sum(self):
        if self.is_empty():
            return float("inf")
        return sum([self.get_path_length(robot) for robot in self.paths.keys()])

    def get_make_span(self):
        if self.is_empty():
            return float("inf")

        path_points = np.array([path.get_points() for path in self.paths.values()])
        path_points = pd.DataFrame(data=path_points.T)
        dists = pd.DataFrame(columns=range(path_points.shape[1]))
        for i in range(path_points.shape[0] - 1):
            for j in range(path_points.shape[1]):
                dists.loc[i, j] = self.metric.dist(path_points.loc[i,j], path_points.loc[i+1,j])
        return sum(dists.max(axis=1))


class SceneDrawer(object):
    """
    Object for lookup tables and drawing scene objects

    :param gui: the given gui
    :type gui: :class:`discopygal.gui.gui.GUI`
    :param scene: the given scene to draw
    :type scene: :class:`Scene`
    """
    def __init__(self, gui, scene):
        self.gui = gui
        self.scene = scene

        self.obstacle_lut = {}
        self.robot_lut = {}

    def draw_scene(self):
        """
        Draw the scene to the selected GUI
        """
        for obstacle in self.scene.obstacles:
            self.draw_obstacle(obstacle)
        for robot in self.scene.robots:
            self.draw_robot(robot)
        for robot in self.scene.robots:
            mini_robot_end = self.robot_lut[robot][2]
            if type(robot) is RobotPolygon:
                item = mini_robot_end.polygon
            elif type(robot) is RobotDisc:
                item = mini_robot_end.disc
            elif type(robot) is RobotRod:
                item = mini_robot_end.line
            self.gui.redraw_item(item)

    def clear_scene(self):
        """
        Clear (only) the DiscoPygal scene objects from the GUI
        """
        for obstacle in self.scene.obstacles:
            if obstacle in self.obstacle_lut:
                self.clear_obstacle(obstacle)
        for robot in self.scene.robots:
            if robot in self.robot_lut:
                self.clear_robot(robot)
        self.obstacle_lut.clear()
        self.robot_lut.clear()


    def select_entity(self, entity):
        """
        """
        if isinstance(entity, Obstacle):
            self.clear_obstacle(entity)
            self.draw_obstacle(entity, color_select=True)
        elif isinstance(entity, Robot):
            self.clear_robot(entity)
            self.draw_robot(entity, color_select=True)

    def deselect_entity(self, entity):
        """
        """
        if isinstance(entity, Obstacle):
            self.clear_obstacle(entity)
            self.draw_obstacle(entity, color_select=False)
        elif isinstance(entity, Robot):
            self.clear_robot(entity)
            self.draw_robot(entity, color_select=False)

    def draw_obstacle(self, obstacle, color_select=False):
        """
        Draw a single obstacle to the scene
        You can affect its color by having the data of the obstacle as a dict,
        and having "color" value (with a string confining to gui.gui.color).

        :param obstacle: obstacle to draw
        :type obstacle: :class:`Obstacle`
        :param color_select: if true override color to select color
        :type color_select: :class:`bool`
        """
        # Select color
        clr = DEFAULT_OBSTACLE_COLOR
        line_clr = QtCore.Qt.black
        if type(obstacle.data) is dict and 'color' in obstacle.data and len(obstacle.data['color'].strip()) > 0:
            clr = color.str_to_color(obstacle.data['color'])
        if color_select:
            clr = DEFAULT_SELECT_COLOR
            line_clr = DEFAULT_SELECT_LINE_COLOR


        if type(obstacle) is ObstaclePolygon:
            poly = conversions.Polygon_2_to_array_of_points(obstacle.poly)
            poly_gui = self.gui.add_polygon(poly, fill_color=clr, line_color=line_clr)
            self.obstacle_lut[obstacle] = poly_gui

        if type(obstacle) is ObstacleDisc:
            radius = conversions.FT_to_float(obstacle.radius)
            x, y = conversions.Point_2_to_xy(obstacle.location)
            disc_gui = self.gui.add_disc(radius, x, y, fill_color=clr, line_color=line_clr)
            self.obstacle_lut[obstacle] = disc_gui

    def draw_robot(self, robot, color_select=False):
        """
        Draw a single robot to the scene
        You can affect its color by having the data of the robot as a dict,
        and having "color" value (with a string confining to gui.gui.color).

        :param obstacle: robot to draw
        :type obstacle: :class:`Robot`
        :param color_select: if true override color to select color
        :type color_select: :class:`bool`
        """
        # Select color
        clr = DEFAULT_ROBOT_COLOR
        line_clr = QtCore.Qt.black
        if type(robot.data) is dict and 'color' in robot.data and len(robot.data['color'].strip()) > 0:
            clr = color.str_to_color(robot.data['color'])
        if color_select:
            clr = DEFAULT_SELECT_COLOR
            line_clr = DEFAULT_SELECT_LINE_COLOR

        if type(robot) is RobotPolygon:
            poly = conversions.Polygon_2_to_array_of_points(robot.poly)
            x1, y1 = conversions.Point_2_to_xy(robot.start)
            x2, y2 = conversions.Point_2_to_xy(robot.end)
            # Shift the robot to start and end locations
            poly_first = [(x+x1, y+y1) for x,y in poly]
            poly_second = [(x+x2, y+y2) for x,y in poly]
            mini_poly = [(0.5*x +x2, 0.5*y+y2) for x,y in poly]
            # Actually draw robots
            poly_second_gui = self.gui.add_polygon(poly_second, fill_color=color.make_transparent(clr), line_color=QtCore.Qt.transparent)
            poly_third_gui = self.gui.add_polygon(mini_poly, fill_color=color.make_transparent(clr, alpha=60), line_color=QtCore.Qt.transparent)
            poly_first_gui = self.gui.add_polygon(
                poly_first, fill_color=clr, line_color=line_clr,
                pos=QtCore.QPointF(robot.start.x().to_double(), robot.start.y().to_double())) # Set initial pos for animation
            path_gui = self.gui.add_segment(x1, y1, x2, y2, line_color=clr, opacity=0.2)
            self.robot_lut[robot] = poly_first_gui, poly_second_gui, poly_third_gui, path_gui

        if type(robot) is RobotDisc:
            radius = conversions.FT_to_float(robot.radius)
            x1, y1 = conversions.Point_2_to_xy(robot.start)
            x2, y2 = conversions.Point_2_to_xy(robot.end)
            disc_second_gui = self.gui.add_disc(radius, x2, y2, fill_color=color.make_transparent(clr), line_color=QtCore.Qt.transparent)
            disc_third_gui = self.gui.add_disc(radius * 0.5, x2, y2, fill_color=color.make_transparent(clr, alpha=60), line_color=QtCore.Qt.transparent)
            disc_first_gui = self.gui.add_disc(radius, x1, y1, fill_color=clr, line_color=line_clr)
            path_gui = self.gui.add_segment(x1, y1, x2, y2, line_color=clr, opacity=0.2)
            self.robot_lut[robot] = disc_first_gui, disc_second_gui, disc_third_gui, path_gui

        if type(robot) is RobotRod:
            length = conversions.FT_to_float(robot.length)
            x1, y1 = conversions.Point_2_to_xy(robot.start[0])
            x2, y2 = conversions.Point_2_to_xy(robot.end[0])
            theta1 = conversions.FT_to_float(robot.start[1])
            theta2 = conversions.FT_to_float(robot.end[1])
            rod_second_gui = self.gui.add_segment_angle(x2, y2, length, theta2, line_color=color.make_transparent(clr))
            rod_third_gui = self.gui.add_segment_angle(x2, y2, length * 0.5, theta2, line_color=color.make_transparent(clr, alpha=60))
            rod_first_gui = self.gui.add_segment_angle(x1, y1, length, theta1, line_color=clr)
            path_gui = self.gui.add_segment(x1, y1, x2, y2, line_color=clr, opacity=0.2)
            self.robot_lut[robot] = rod_first_gui, rod_second_gui, rod_third_gui, path_gui

    def clear_obstacle(self, obstacle):
        if type(obstacle) is ObstaclePolygon:
            self.gui.scene.removeItem(self.obstacle_lut[obstacle].polygon)
        if type(obstacle) is ObstacleDisc:
            self.gui.scene.removeItem(self.obstacle_lut[obstacle].disc)
        # self.obstacle_lut.pop(obstacle)

    def clear_robot(self, robot):
        if type(robot) is RobotPolygon:
            poly_first_gui, poly_second_gui, poly_third_gui, path_gui = self.robot_lut[robot]
            self.gui.scene.removeItem(poly_first_gui.polygon)
            self.gui.scene.removeItem(poly_second_gui.polygon)
            self.gui.scene.removeItem(poly_third_gui.polygon)
            self.gui.scene.removeItem(path_gui.line)
        if type(robot) is RobotDisc:
            disc_first_gui, disc_second_gui, disc_third_gui, path_gui = self.robot_lut[robot]
            self.gui.scene.removeItem(disc_first_gui.disc)
            self.gui.scene.removeItem(disc_second_gui.disc)
            self.gui.scene.removeItem(disc_third_gui.disc)
            self.gui.scene.removeItem(path_gui.line)
        if type(robot) is RobotRod:
            rod_first_gui, rod_second_gui, rod_third_gui, path_gui = self.robot_lut[robot]
            self.gui.scene.removeItem(rod_first_gui.line)
            self.gui.scene.removeItem(rod_second_gui.line)
            self.gui.scene.removeItem(rod_third_gui.line)
            self.gui.scene.removeItem(path_gui.line)
        # self.robot_lut.pop(robot)
