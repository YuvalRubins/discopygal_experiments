import abc

from ..SamplingSolver import SamplingSolver
from .tensor_roadmap import TensorRoadmap


class TensorSolver(SamplingSolver):
    """
    Base solver class for solvers that use a tensor roadmap - constructs a two-dimensional roadmap for each robot and searches on the tensor product of these roadmaps.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.tensor_roadmap = None

    @abc.abstractmethod
    def build_robot_roadmap(self, robot):
        """
        Creates a two-dimensional roadmap for the given robot

        :param robot: The robot o build a roadmap for
        :type robot: :class:`~discopygal.solvers_infra.Robot`

        :return: The roadmap
        :rtype: :class:`~discopygal.solvers_infra.tensor_solver.tensor_roadmap.Roadmap`
        """
        raise NotImplementedError()

    @abc.abstractmethod
    def search_tensor_roadmap(self):
        """
        Search method the explore the tensor roadmap a find a solution path on it
        """
        raise NotImplementedError()

    def build_roadmap(self):
        roadmaps = {}
        for i, robot in enumerate(self.scene.robots):
            self.log('generating roadmap #{}...'.format(i+1))
            roadmaps[robot] = self.build_robot_roadmap(robot)

        # Construct the tensor roadmap
        self.tensor_roadmap = TensorRoadmap(roadmaps, self.scene, self.nearest_neighbors_class, self.metric, self.sampler)

        # Add the start vertex to the RRT
        self.tensor_roadmap.T.add_point(self.start)
        return self.tensor_roadmap.T

    def search_path_on_roadmap(self):
        self.search_tensor_roadmap()
        return super().search_path_on_roadmap()
