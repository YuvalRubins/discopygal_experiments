import heapq

from discopygal.bindings import Point_2
from discopygal.solvers_infra import PathCollection, PathPoint, Path
from discopygal.geometry_utils.conversions import Point_d_to_Point_2_list
from discopygal.solvers.prm import PRM

class PRM2(PRM):
    """
    PRM where the weight of each edge is the bigger distance between the two pairs of points
    (Only Two robots)
    """
    def build_roadmap(self):
        if len(self.scene.robots) != 2:
            raise Exception("Scene must have exactly two robots")
        roadmap = super().build_roadmap()
        for edge in roadmap.edges:
            start, end = edge
            start1, start2 = Point_d_to_Point_2_list(start)
            end1, end2 = Point_d_to_Point_2_list(end)
            roadmap.graph[start][end]['weight'] = max(
                self.metric.dist(start1, end1).to_double(),
                self.metric.dist(start2, end2).to_double()
            )

        return roadmap


class PRM3(PRM):
    """
    PRM where trying to minimize the longer path among the robots
    (Only Two robots)
    """
    def build_roadmap(self):
        if len(self.scene.robots) != 2:
            raise Exception("Scene must have exactly two robots")
        roadmap = super().build_roadmap()
        for edge in roadmap.edges:
            start, end = edge
            start1, start2 = Point_d_to_Point_2_list(start)
            end1, end2 = Point_d_to_Point_2_list(end)
            roadmap.graph[start][end]['weight1'] = self.metric.dist(start1, end1).to_double()
            roadmap.graph[start][end]['weight2'] = self.metric.dist(start2, end2).to_double()

        return roadmap

    def search_path_on_roadmap(self):
        # Find the path with the minimized maximum sum of weights
        min_path = self.min_max_sum_path(self.roadmap, self.start, self.end)

        self.log('Successfully found a path')
        path_collection = PathCollection()
        for i, robot in enumerate(self.scene.robots):
            points = []
            for point in min_path:
                points.append(PathPoint(Point_2(point[2*i], point[2*i+1])))
            path = Path(points)
            path_collection.add_robot_path(robot, path)
            self.log(f'Path length of robot {i}: {path.calculate_length(self.metric)}')

        return path_collection

    @staticmethod
    def min_max_sum_path(roadmap, source, dest):
        # Initialize distances with infinity
        distances = {node: (float('inf'), float('inf')) for node in roadmap.points}
        distances[source] = (0, 0)  # (S1, S2)

        # Priority queue to store nodes with their distances
        pq = [(0, source)]
        # Previous node dictionary to store the path
        prev_node = {source: None}

        while pq:
            # Pop the node with the smallest distance from the priority queue
            min_dist, node = heapq.heappop(pq)

            # Extract S1, S2 from the distance tuple
            S1, S2 = distances[node]

            # Check if destination reached
            if node == dest:
                break

            # Iterate over neighbors of the current node
            for neighbor, edge_data in roadmap.graph[node].items():
                # Calculate new sums
                new_S1 = S1 + edge_data['weight1']
                new_S2 = S2 + edge_data['weight2']

                # Update distances if the new path has smaller maximum sum
                new_max_sum = max(new_S1, new_S2)
                if new_max_sum < max(distances[neighbor]):
                    distances[neighbor] = (new_S1, new_S2)
                    heapq.heappush(pq, (new_max_sum, neighbor))
                    # Update the previous node
                    prev_node[neighbor] = node

        # Reconstruct the path
        path = []
        node = dest
        while node is not None:
            path.insert(0, node)
            node = prev_node[node]

        return path
