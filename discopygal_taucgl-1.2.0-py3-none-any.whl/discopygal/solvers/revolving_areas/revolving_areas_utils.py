from typing import List, Tuple, Optional, Set, Dict

from discopygal.bindings import Point_2, Polygon_2, Point_d, Segment_2, FT
from discopygal.geometry_utils import conversions

import RA

RA_Point_2 = RA.Ker.Point_2
RA_Segment_2 = RA.Ker.Segment_2
RA_Polygon_2 = RA.Pol.Polygon_2
RA_Swapping_area = RA.Swapping_area
RA_Segment_arc = RA.Segment_arc
RA_Circular_arc = RA.Circular_arc
RA_Intersection_arc = RA.Intersection_arc
RA_Path_arc = RA.Path_arc
RA_Generalized_arc = RA.Generalized_arc
RA_Modify_path = RA.Modify_path

from .geometry_utils import segment_point_distance


MAX_DISTANCE = 0.5


def to_tuple_Point_2(p):
    return (p.x().to_double(), p.y().to_double())


def to_RA_Point_2(p):
    return RA_Point_2(*to_tuple_Point_2(p))


def to_Point_2(p):
    return Point_2(*to_tuple_Point_2(p))


def Polygon_2_to_RA_Polygon_2(poly: Polygon_2):
    return RA_Polygon_2([to_RA_Point_2(p) for p in poly.vertices()])


def print_obstacles(obstacles: List[Polygon_2]):
    print(
        "Obstacles:",
        [list(map(to_tuple_Point_2, poly.vertices())) for poly in obstacles],
    )


def get_swapping_areas(
    obstacles: List[Polygon_2], starts: List[Point_2], targets: List[Point_2]
) -> Tuple[List[RA.Swapping_area], List[RA.Swapping_area]]:
    assert len(starts) == len(
        targets
    ), "Number of starts does not match number of targets."

    print_obstacles(obstacles)
    RA_obstacles = [Polygon_2_to_RA_Polygon_2(poly) for poly in obstacles]
    RA_Swapping_area.init(RA_obstacles)

    print("Starts:", list(map(to_tuple_Point_2, starts)))
    print("Targets:", list(map(to_tuple_Point_2, targets)))
    RA_starts = [to_RA_Point_2(p) for p in starts]
    RA_targets = [to_RA_Point_2(p) for p in targets]

    swapping_areas_num = len(RA_starts)
    starts_swapping_areas = [
        RA_Swapping_area(i, True, RA_starts, RA_targets, False)
        for i in range(swapping_areas_num)
    ]
    targets_swapping_areas = [
        RA_Swapping_area(i, False, RA_starts, RA_targets, False)
        for i in range(swapping_areas_num)
    ]

    return starts_swapping_areas, targets_swapping_areas


def paths_to_grouped_robots_paths(
    paths: List[List[Point_d]],
) -> Tuple[List[List[List[Point_2]]], List[List[RA.Path_arc]]]:
    grouped_robot_paths = []
    RA_grouped_robots_paths = []
    total_size = 0
    for path in paths:
        assert path[0].dimension() % 2 == 0
        group_size = path[0].dimension() // 2
        splitted_path: List[List[Point_2]] = [list() for _ in range(group_size)]
        for point in path:
            point_list = conversions.Point_d_to_Point_2_list(point)
            for i, point2 in enumerate(point_list):
                splitted_path[i].append(point2)

        grouped_robot_paths.append(splitted_path)

        RA_robots_paths_group = []
        for i, robot_path in enumerate(splitted_path):
            robot_index = total_size + i
            RA_robot_path = RA_Path_arc(robot_index)
            for p1, p2 in zip(robot_path, robot_path[1:]):
                # NOTE: Maybe we want to skip if distance is less than `EPSILON`.
                if p1 == p2:
                    print("Skipping trivial segment...")
                    continue
                RA_p1 = to_RA_Point_2(p1)
                RA_p2 = to_RA_Point_2(p2)
                RA_seg = RA_Segment_2(RA_p1, RA_p2)
                RA_sa = RA_Segment_arc(RA_seg, robot_index)
                RA_robot_path.push_back(RA_sa)
            RA_robots_paths_group.append(RA_robot_path)

        RA_grouped_robots_paths.append(RA_robots_paths_group)
        total_size += group_size

    return grouped_robot_paths, RA_grouped_robots_paths


def add_configuration(
    edge_path: List[List[Optional[Point_2]]],
    edge_path_idx: int,
    robot_idx: int,
    position: Point_2,
    retracted_robots: Set[RA.Swapping_area],
    ignored_robots_indices: Set[int],
    robots_num: int,
    other_robot_idx: int = -1,
    other_position: Optional[Point_2] = None,
):
    assert edge_path_idx <= len(
        edge_path
    ), f"Can only extend path by 1 at a time {len(edge_path) = }, {edge_path_idx = }."
    if edge_path_idx == len(edge_path):
        edge_path.append([None for _ in range(robots_num)])

    edge_point = edge_path[edge_path_idx]
    assert edge_point[robot_idx] is None, "Position for main robot is already written."
    edge_point[robot_idx] = position

    for RA_swapping_area in retracted_robots:
        retracted_robot_idx = RA_swapping_area.robotIndex
        if retracted_robot_idx in ignored_robots_indices:
            continue

        retracted_robot_position = to_Point_2(
            RA_swapping_area.retractionPoint(to_RA_Point_2(position))
        )
        assert (
            edge_point[retracted_robot_idx] is None
            or edge_point[retracted_robot_idx] == retracted_robot_position
        ), f"Position for retracted robot is already written {edge_point[retracted_robot_idx] = }, {retracted_robot_position = }, {retracted_robot_idx = }"
        edge_point[retracted_robot_idx] = retracted_robot_position

    if other_robot_idx != -1:
        assert (
            edge_point[other_robot_idx] is None
            or edge_point[other_robot_idx] == other_position
        ), f"Position for other robot is already written {edge_point[other_robot_idx] = }, {other_position = }, {other_robot_idx = }"
        edge_point[other_robot_idx] = other_position


def update_edge_path(
    edge_path: List[List[Optional[Point_2]]],
    edge_path_idx: int,
    robot_idx: int,
    arc: RA.Generalized_arc,
    ignored_robots_indices: Set[int],
    robots_num: int,
):
    """
    Returns updated edge path index.
    """
    if isinstance(arc, RA_Intersection_arc):
        other_robot_idx = arc.swappingArea.robotIndex
        if other_robot_idx in ignored_robots_indices:
            return edge_path_idx

        RA_intersection = to_RA_Point_2(arc.intersection)
        intersection = to_Point_2(arc.intersection)

        other_robot_original_location = arc.swappingArea.robotPosition
        other_robot_retraction_location = to_RA_Point_2(
            arc.swappingArea.retractionPoint(RA_intersection)
        )
        segment = (
            (other_robot_original_location, other_robot_retraction_location)
            if arc.isEntrance
            else (other_robot_retraction_location, other_robot_original_location)
        )
        RA_segment = RA_Segment_arc(RA_Segment_2(*segment), other_robot_idx)
        for RA_point in RA_segment.PointsOnArc(MAX_DISTANCE):
            add_configuration(
                edge_path=edge_path,
                edge_path_idx=edge_path_idx,
                robot_idx=robot_idx,
                position=intersection,
                retracted_robots=arc.retractedRobots,
                ignored_robots_indices=ignored_robots_indices,
                robots_num=robots_num,
                other_robot_idx=other_robot_idx,
                other_position=to_Point_2(RA_point),
            )
            edge_path_idx += 1

    elif isinstance(arc, RA_Segment_arc) or isinstance(arc, RA_Circular_arc):
        for RA_point in arc.PointsOnArc(MAX_DISTANCE):
            add_configuration(
                edge_path=edge_path,
                edge_path_idx=edge_path_idx,
                robot_idx=robot_idx,
                position=to_Point_2(RA_point),
                retracted_robots=arc.retractedRobots,
                ignored_robots_indices=ignored_robots_indices,
                robots_num=robots_num,
            )
            edge_path_idx += 1

    return edge_path_idx


def finalize_edge_path(
    edge_path: List[List[Optional[Point_2]]], last_known_positions: Dict[int, Point_2]
) -> List[Point_d]:
    rv: List[Point_d] = []
    for point_list in edge_path:
        for i in range(len(point_list)):
            if point_list[i] is None:
                point_list[i] = last_known_positions[i]
            # Update last known position of the robots.
            last_known_positions[i] = point_list[i]
        rv.append(conversions.Point_2_list_to_Point_d(point_list))
    return rv


def print_RA_robot_path(RA_robot_path: RA.Path_arc):
    path = []
    for arc in RA_robot_path.arcs:
        path.append((to_tuple_Point_2(arc.Source()), to_tuple_Point_2(arc.Target())))

    print("Path:", path)


def combine_paths_with_revolving_areas(
    robots_paths_group: List[List[Point_2]],
    RA_robots_paths_group: List[RA.Path_arc],
    starts_swapping_areas: List[RA.Swapping_area],
    targets_swapping_areas: List[RA.Swapping_area],
) -> List[Point_d]:
    assert len(robots_paths_group) == len(RA_robots_paths_group)
    assert len(starts_swapping_areas) == len(targets_swapping_areas)
    RA_robots_new_paths_group = []
    for RA_robot_path in RA_robots_paths_group:
        robot_idx = RA_robot_path.robotIndex
        start = to_Point_2(RA_robot_path.arcs[0].Source())
        target = to_Point_2(RA_robot_path.arcs[-1].Target())
        assert start == to_Point_2(
            starts_swapping_areas[robot_idx].robotPosition
        ), f"Path start does not match start swapping area for robot {robot_idx}"
        assert target == to_Point_2(
            targets_swapping_areas[robot_idx].robotPosition
        ), f"Path target does not match target swapping area for robot {robot_idx}"

        print(f"Modifying path for robot {robot_idx}")
        print_RA_robot_path(RA_robot_path)

        RA_new_path = RA_Modify_path(
            RA_robot_path, starts_swapping_areas, targets_swapping_areas
        ).NewPath()
        RA_robots_new_paths_group.append(RA_new_path)

    group_size = len(robots_paths_group)
    robots_num = len(starts_swapping_areas)
    new_paths_indices = [0] * group_size
    original_paths_len = len(robots_paths_group[0])
    ignored_robots_indices = {RA_path.robotIndex for RA_path in RA_robots_paths_group}
    # Assuming the group robots are continuous.
    arbitrary_robot_index = RA_robots_paths_group[0].robotIndex
    last_known_positions = {
        i: to_Point_2(
            targets_swapping_areas[i].robotPosition
            if (i not in ignored_robots_indices and i < arbitrary_robot_index)
            else starts_swapping_areas[i].robotPosition
        )
        for i in range(robots_num)
    }

    print(f"The following robots move together: {ignored_robots_indices}")
    rv: List[Point_d] = []
    for edge_idx in range(original_paths_len - 1):
        edge_path: List[List[Optional[Point_2]]] = []
        edge_paths_indices = [0] * group_size
        for robot_path_idx in range(group_size):
            segment_src = robots_paths_group[robot_path_idx][edge_idx]
            segment_dst = robots_paths_group[robot_path_idx][edge_idx + 1]
            if segment_src == segment_dst:
                continue
            original_segment = Segment_2(segment_src, segment_dst)
            new_path_idx = new_paths_indices[robot_path_idx]
            edge_path_idx = edge_paths_indices[robot_path_idx]
            RA_new_path = RA_robots_new_paths_group[robot_path_idx]
            robot_idx = RA_new_path.robotIndex
            while new_path_idx < len(RA_new_path.arcs):
                current_arc = RA_new_path.arcs[new_path_idx]
                if not (isinstance(current_arc, RA_Intersection_arc)):
                    RA_points_on_arc = current_arc.PointsOnArc(MAX_DISTANCE)
                    is_valid_distance = True
                    for RA_point_on_arc in RA_points_on_arc:
                        point_on_arc = to_Point_2(RA_point_on_arc)
                        if segment_point_distance(original_segment, point_on_arc) > 2:
                            is_valid_distance = False
                            break
                    if not is_valid_distance:
                        break

                edge_path_idx = update_edge_path(
                    edge_path,
                    edge_path_idx,
                    robot_idx,
                    current_arc,
                    ignored_robots_indices,
                    robots_num,
                )

                new_path_idx += 1
            new_paths_indices[robot_path_idx] = new_path_idx
            edge_paths_indices[robot_path_idx] = edge_path_idx
        rv.extend(finalize_edge_path(edge_path, last_known_positions))

    for i, new_path_idx in enumerate(new_paths_indices):
        assert new_path_idx == len(
            RA_robots_new_paths_group[i].arcs
        ), f"Path was not completed: {i = }, {new_path_idx = }, {len(RA_robots_new_paths_group[i].arcs) = }"

    return rv
