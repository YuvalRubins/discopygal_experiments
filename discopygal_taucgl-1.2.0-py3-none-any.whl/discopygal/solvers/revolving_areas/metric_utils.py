import math
from typing import List
import sklearn.metrics
from tqdm import tqdm

from discopygal.geometry_utils import conversions
from discopygal.bindings import Point_d, Point_2, FT
from discopygal.solvers_infra.metrics import Metric, MetricNotImplemented


def l2_dist(u: Point_2, v: Point_2):
    x_diff = (u.x() - v.x()).to_double()
    y_diff = (u.y() - v.y()).to_double()

    return math.sqrt(x_diff**2 + y_diff**2)


def l2_len(path: List[Point_2]):
    path_len = 0
    for src, dst in zip(path, path[1:]):
        path_len += l2_dist(src, dst)

    return path_len


def makespan(du: List[Point_2], dv: List[Point_2]):
    assert len(du) == len(
        dv
    ), f"du and dv are not of the same dimension: {len(du) = }, {len(dv) = }."

    return max(l2_dist(u, v) for u, v in zip(du, dv))


def makespan_d(du: Point_d, dv: Point_d):
    return makespan(
        conversions.Point_d_to_Point_2_list(du), conversions.Point_d_to_Point_2_list(dv)
    )


def path_makespan(dpath: List[List[Point_2]]):
    path_makespan = 0
    for src, dst in zip(dpath, dpath[1:]):
        path_makespan += makespan(src, dst)

    return path_makespan


def path_makespan_d(dpath: List[Point_d], verbose=False):
    path_makespan = 0
    for i in tqdm(range(len(dpath) - 1), "Calculating makespan", disable=not verbose):
        path_makespan += makespan_d(dpath[i], dpath[i + 1])

    return path_makespan


class Metric_Linf(Metric):
    @staticmethod
    def dist(p, q):
        if type(p) is Point_2 and type(q) is Point_2:
            x_diff = abs((p.x() - q.x()).to_double())
            y_diff = abs((p.y() - q.y()).to_double())
            return FT(max(x_diff, y_diff))
        elif type(p) is Point_d and type(q) is Point_d:
            assert p.dimension() == q.dimension(), "p,q should be of the same dimension"
            dist = 0
            for i in range(p.dimension()):
                curr_dist = abs((p[i] - q[i]))
                dist = max(curr_dist, dist)
            return FT(dist)
        else:
            raise MetricNotImplemented("p,q should be Point_2 or Point_d")

    @staticmethod
    def CGALPY_impl():
        raise MetricNotImplemented("CGAL")

    @staticmethod
    def sklearn_impl():
        return sklearn.metrics.DistanceMetric.get_metric("chebyshev")
