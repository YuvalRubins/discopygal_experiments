from enum import Enum


class PathCombinerMode(Enum):
    SEQUENTIAL = "sequential"
    REVOLVING_AREAS = "revolving"
    PRM = "prm"
    REFINEMENT = "refinement"
    OBSTACLES2 = "obstacles2"
    PAIRS = "pairs"
